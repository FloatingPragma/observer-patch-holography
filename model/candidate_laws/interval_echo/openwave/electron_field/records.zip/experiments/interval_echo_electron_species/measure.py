"""Energy-resolved transfer and species-reader scope on the four-face charged state."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys

import numpy as np
from scipy.linalg import eigh

HERE = Path(__file__).resolve().parent
COLLECTIVE = HERE.parent / "interval_echo_collective_spin"
sys.path.insert(0, str(COLLECTIVE))
from search import JoinedSpace, fan, vacuum_code


def krylov_determinant(h):
    """A nonzero modular determinant is an exact certificate of cyclicity."""
    prime = 65521
    scaled = np.rint(2 * h).astype(np.int64)
    np.testing.assert_array_equal(scaled, 2 * h)
    n = len(h)
    for seed in range(8):
        start = np.random.default_rng(seed).integers(0, prime, n, dtype=np.int64)
        columns = np.empty((n, n), dtype=np.int64)
        columns[:, 0] = start
        for i in range(1, n):
            columns[:, i] = scaled @ columns[:, i - 1] % prime
        determinant = 1
        for col in range(n):
            index = np.flatnonzero(columns[col:, col])
            if not len(index):
                determinant = 0
                break
            pivot = col + index[0]
            if pivot != col:
                columns[[col, pivot]] = columns[[pivot, col]]
                determinant = -determinant
            diagonal = int(columns[col, col])
            determinant = determinant * diagonal % prime
            coefficients = columns[col + 1:, col] * pow(diagonal, -1, prime) % prime
            columns[col + 1:, col:] = (columns[col + 1:, col:] - coefficients[:, None] * columns[col, col:]) % prime
        if determinant:
            return {"prime": prime, "seed": seed, "integer_seed_vector": start.tolist(),
                    "columns": n, "determinant_residue": determinant}
    raise ArithmeticError("No simple-spectrum certificate on the declared seed range")


def logical_range(operators):
    effect = np.einsum("nia,nib->ab", operators.conj(), operators)
    return np.linalg.eigvalsh(effect).tolist()


def sector(field, heads, degrees, ports, sign):
    space = JoinedSpace(field, (heads, heads), sign)
    h = space.hamiltonian([6, *degrees[0], 6, *degrees[1]])
    cyclicity = krylov_determinant(h)
    vacuum, doublet = vacuum_code(field, heads)
    source = np.zeros((len(h), 2))
    dest = np.zeros_like(source)
    source[space.portal[0]] = np.einsum("ia,j->ija", doublet, vacuum)
    dest[space.portal[1]] = np.einsum("i,ja->ija", vacuum, doublet)
    levels, modes = eigh(h)
    kernels = np.einsum("an,nb->nab", dest.T @ modes, modes.T @ source)
    native_exposure = 30.8125

    def accepted(exposure):
        return np.einsum("n,nab->ab", np.exp(-1j * levels * exposure), kernels)

    arrival = accepted(native_exposure)
    vec = kernels.reshape(len(h), 4)
    choi_after_energy_read = vec.T @ vec / 2
    partial = choi_after_energy_read.reshape(2, 2, 2, 2).transpose(0, 3, 2, 1).reshape(4, 4)
    assert np.linalg.eigvalsh(partial)[0] > -1e-12
    assert max(abs(np.linalg.det(kernels))) < 1e-15
    singular = np.linalg.svd(arrival, compute_uv=False)
    coherent_negativity = float(np.prod(singular) / 2)
    assert coherent_negativity > 0.05

    def physical_transfer(seconds_per_native_time):
        # SI energy equals native eigenvalue * hbar / seconds_per_native_time.
        angular_frequencies = levels / seconds_per_native_time
        duration = native_exposure * seconds_per_native_time
        return np.einsum("n,nab->ab", np.exp(-1j * angular_frequencies * duration), kernels)

    scale_ratio = 3.0
    matrix_residual = float(np.max(abs(physical_transfer(1.0) - physical_transfer(scale_ratio))))
    assert matrix_residual < 1e-12

    home = int(ports["left"][0]) // 12
    away = int(ports["right"][0]) // 12
    assert home != away
    addresses = [*ports["left"], *ports["right"]]
    cell_counts = set()
    for x, _ in space.basis:
        material_cell = int(addresses[x]) // 12
        counts = (12 + sign * int(material_cell == home), 12 + sign * int(material_cell == away))
        assert 2 not in counts
        cell_counts.add(counts)

    return {
        "sign": sign,
        "heads_each_side": list(heads),
        "dimension": len(h),
        "cyclicity_of_twice_free_hamiltonian": cyclicity,
        "parked_ring_spectrum": np.linalg.eigvalsh(field.ring_laplacian(field.words[heads])).round(12).tolist(),
        "finite_guide_ground_energy_native": float(levels[0]),
        "minimum_spacing_free_spectrum_native": float(np.min(np.diff(levels))),
        "head_and_charge_matched_joint_arrival": {
            "native_exposure": native_exposure,
            "coherent_probability_range": logical_range(arrival[None]),
            "energy_measured_outcome_ignored_probability_range": logical_range(kernels),
            "coherent_subnormalized_choi_negativity": coherent_negativity,
            "energy_measured_subnormalized_choi_partial_transpose_levels": np.linalg.eigvalsh(partial).tolist(),
            "max_abs_single_energy_transfer_determinant": float(max(abs(np.linalg.det(kernels)))),
        },
        "colour_and_weak_pair_service": {
            "distinct_absolute_cell_load_counts_left_right": sorted(cell_counts),
            "tested_sharp_configurations": len(space.basis),
            "configurations_eligible_for_home_or_away_two_load_service": 0,
        },
        "scale_test": {
            "illustrative_seconds_per_native_time": [1.0, scale_ratio],
            "trial_energy_units_in_hbar_per_second": [1.0, 1.0 / scale_ratio],
            "max_abs_complete_accepted_amplitude_difference": matrix_residual,
        },
    }


def run():
    witness = json.loads((COLLECTIVE / "results.json").read_text())["headline"]["best_worst_qubit_success"]
    field = fan(4)
    heads = tuple(witness["release"]["head_sectors"][0])
    assert witness["release"]["best_worst_time"] == 30.8125
    degrees = [sum(i in pair for pair in field.edges) for i in range(6)]
    conjugate = tuple(d - h for d, h in zip(degrees, heads))
    sources = [Path(__file__), HERE / "PROTOCOL.md", COLLECTIVE / "search.py", COLLECTIVE / "results.json",
               HERE.parent / "interval_echo_electron_spin/winding.py"]
    return {
        "physical_ports": witness["actual_ports"],
        "sectors": [sector(field, state, witness["degrees"], witness["actual_ports"], sign)
                    for sign, state in ((1, heads), (-1, conjugate))],
        "sha256": {str(p.relative_to(HERE.parent)): sha256(p.read_bytes()).hexdigest() for p in sources},
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    path = parser.parse_args().output
    result = run()
    with path.open("x") as f:
        json.dump(result, f, indent=2, allow_nan=False)
        f.write("\n")
