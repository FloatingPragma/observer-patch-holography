"""Exact spectral multiplicities and magnetic measurements for the free charge–flux cloud."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import eigsh

HERE = Path(__file__).resolve().parent
CLOUD = HERE.parent / "interval_echo_electron_flux_binding"
sys.path.insert(0, str(CLOUD))
from search import Patch, charged_sector
from model.executable_model.carrier import icosahedron_from_coordinates, isomorphism

PRIME = 65521


def recurrence(sequence):
    """Berlekamp–Massey over a prime field, returning coefficients in lag order."""
    n = len(sequence)
    length = 0
    previous = np.zeros(n + 1, dtype=np.int64)
    previous[0] = 1
    current = previous.copy()
    shift, last_discrepancy = 1, 1
    for j in range(n):
        correction = int((sequence[j] + current[1:length + 1] @ sequence[j - length:j][::-1]) % PRIME)
        if correction == 0:
            shift += 1
            continue
        old = current.copy()
        factor = correction * pow(last_discrepancy, -1, PRIME) % PRIME
        current[shift:] = (current[shift:] - factor * previous[:n + 1 - shift]) % PRIME
        if 2 * length <= j:
            length = j + 1 - length
            previous = old
            last_discrepancy = correction
            shift = 1
        else:
            shift += 1
    return current[:length + 1]


def gcd_degree(a, b):
    """Euclidean polynomial gcd degree modulo PRIME, descending coefficient order."""
    def without_leading_zeros(poly):
        first = np.flatnonzero(poly)
        return poly[first[0]:] if len(first) else poly[:0]
    a, b = without_leading_zeros(a), without_leading_zeros(b)
    while len(b):
        remainder = a.copy()
        leading_inverse = pow(int(b[0]), -1, PRIME)
        steps = len(remainder) - len(b) + 1
        for i in range(max(0, steps)):
            factor = int(remainder[i]) * leading_inverse % PRIME
            if factor:
                window = remainder[i:i + len(b)]
                window[:] = (window - factor * b) % PRIME
        a, b = b, without_leading_zeros(remainder)
    return len(a) - 1


def exact_spectrum(hamiltonian):
    n = hamiltonian.shape[0]
    v = np.random.default_rng(8741).integers(0, PRIME, n, dtype=np.int64)
    u = np.random.default_rng(411).integers(0, PRIME, n, dtype=np.int64)
    power = v.copy()
    moments = np.empty(2 * n, dtype=np.int64)
    for k in range(2 * n):
        moments[k] = u @ power % PRIME
        power = (hamiltonian @ power) % PRIME
    denominator = recurrence(moments)
    assert len(denominator) == n + 1 and denominator[0] == 1
    # Horner verifies directly that F(2H)v = 0 modulo p. The polynomial of the
    # scalar resolvent numerator comes from its first n coefficients at infinity.
    value = v.copy()
    for coefficient in denominator[1:]:
        value = (hamiltonian @ value + coefficient * v) % PRIME
    assert not np.any(value)
    numerator = np.convolve(denominator[:n], moments[:n])[:n] % PRIME
    gcd = gcd_degree(denominator, numerator)
    assert gcd == 0
    digest = lambda a: sha256(np.ascontiguousarray(a, dtype="<i8").tobytes()).hexdigest()
    return {"prime": PRIME, "source_seed": 8741, "read_seed": 411,
            "twice_H_dimension": n, "denominator_degree": n, "gcd_degree": gcd,
            "F_of_twice_H_applied_to_source_residual_nonzero_entries_mod_p": int(np.count_nonzero(value)),
            "moments_sha256_i64_le": digest(moments), "denominator_sha256_i64_le": digest(denominator),
            "numerator_sha256_i64_le": digest(numerator)}


def spectrum(h, start):
    levels, vectors = eigsh(h, k=4, which="SA", v0=start, tol=1e-12, maxiter=30000)
    order = np.argsort(levels)
    levels, vectors = levels[order], vectors[:, order]
    residual = np.max(np.linalg.norm(h @ vectors - vectors * levels, axis=0))
    assert residual < 1e-9
    return levels, vectors, float(residual)


def examine(patch, sign, xyz):
    twice_h, states, positions = charged_sector(patch, sign)
    h = (0.5 * twice_h).tocsr()
    start = np.random.default_rng(98031).normal(size=len(states))
    levels, vectors, residual = spectrum(h, start)
    state = vectors[:, 1]
    occupancy = np.bincount(positions, weights=state**2, minlength=12)
    coo = h.tocoo()
    # Matrix [row, column] belongs to the hop column-position -> row-position.
    a, b = positions[coo.col], positions[coo.row]
    moving = a != b
    assert np.all(coo.data[moving] == -4)
    area = 0.5 * sign * np.cross(xyz[a], xyz[b])
    quantum = 1.0 / 32

    def phase_h(phases, scale):
        return sparse.coo_matrix((coo.data * np.exp(1j * phases * scale), (coo.row, coo.col)), shape=h.shape).tocsr()

    magnetic = []
    for axis in range(3):
        direction = area[:, axis]
        current = sparse.coo_matrix((coo.data * direction, (coo.row, coo.col)), shape=h.shape).tocsr()
        assert (current + current.T).nnz == 0
        action = current @ state
        twist_levels, twist_modes, finite_residual = spectrum(phase_h(direction, quantum), start)
        reverse_levels, _, reverse_residual = spectrum(phase_h(direction, -quantum), start)
        np.testing.assert_allclose(twist_levels, reverse_levels, atol=2e-11, rtol=0)
        overlap = abs(np.vdot(state, twist_modes[:, 1]))**2
        assert overlap > 0.95
        magnetic.append({"axis": "xyz"[axis], "zero_field_slope_abs": float(abs(state @ action)),
                         "magnetic_transition_strength": float(action @ action),
                         "positive_strength_excited_energy": float(twist_levels[1]),
                         "negative_strength_excited_energy": float(reverse_levels[1]),
                         "first_excited_energy_shift": float(twist_levels[1] - levels[1]),
                         "same_branch_overlap_squared": float(overlap),
                         "positive_strength_charge_probability_at_port_zero": float(np.sum(abs(twist_modes[positions == 0, 1])**2)),
                         "max_eigenpair_residual": max(finite_residual, reverse_residual)})

    edge_expectations = []
    for low, high in patch.edges:
        forward = (a == low) & (b == high)
        backward = (a == high) & (b == low)
        edge_weight = sign * (forward.astype(int) - backward.astype(int))
        current = sparse.coo_matrix((coo.data * edge_weight, (coo.row, coo.col)), shape=h.shape).tocsr()
        assert (current + current.T).nnz == 0
        edge_expectations.append(abs(state @ (current @ state)))

    # A pure gradient is an exact diagonal unitary conjugation of the full H.
    scalar = np.linspace(-0.5, 0.5, 12)
    phases = sign * (scalar[b] - scalar[a])
    transformed = state * np.exp(1j * quantum * sign * scalar[positions])
    resid_gradient = np.linalg.norm(phase_h(phases, quantum) @ transformed - levels[1] * transformed)
    assert resid_gradient < 1e-9

    step = 1e-4
    perturb = sparse.diags(step * (positions == 0))
    e_plus, _, _ = spectrum(h + perturb, start)
    e_minus, _, _ = spectrum(h - perturb, start)
    estimated = (e_plus[1] - e_minus[1]) / (2 * step)
    assert abs(estimated - occupancy[0]) < 1e-7
    return {"sign": sign, "dimension": len(states), "exact_spectrum": exact_spectrum(twice_h),
            "lowest_four_levels_native": levels.tolist(), "nearest_partner_gap": float(min(np.diff(levels[:3]))),
            "zero_field_eigenpair_max_residual": residual,
            "zero_field_charge_port_probabilities": occupancy.tolist(), "uniform_field_strength_native": quantum,
            "cartesian_field_axes": magnetic, "max_abs_stationary_link_current_over_30": float(max(edge_expectations)),
            "pure_gradient_eigenpair_residual": float(resid_gradient),
            "scalar_port_zero_spectral_slope_and_occupation": [float(estimated), float(occupancy[0])]}


def run():
    patch = Patch()
    pts, edges = icosahedron_from_coordinates()
    xyz = pts[isomorphism(patch.edges, edges)].astype(float)
    xyz /= np.linalg.norm(xyz[0])
    np.testing.assert_allclose(np.linalg.norm(xyz, axis=1), np.ones(12), atol=1e-12)
    inputs = [Path(__file__), HERE / "CLOUD_PROTOCOL.md", CLOUD / "search.py", CLOUD / "soft_cloud.json"]
    return {"port_coordinates_unit_radius": xyz.tolist(),
            "sectors": [examine(patch, sign, xyz) for sign in (-1, 1)],
            "sha256": {str(p.relative_to(HERE.parent)): sha256(p.read_bytes()).hexdigest() for p in inputs}}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    path = parser.parse_args().output
    result = run()
    with path.open("x") as f:
        json.dump(result, f, indent=2, allow_nan=False)
        f.write("\n")
