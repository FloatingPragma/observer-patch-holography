# Can the mobile orbital state carry a single resting energy?

The four-face charge experiment can transfer an arbitrary two-state orbital input coherently. On its selected 14–24 gateway, **all 160 free energies are simple for each sign of the load**. The two orbital modes at energy 1 with the charge parked lose their equal energy when all material and ring contacts open. The measured orbital information resides across several energy levels. [Original charge and orbital preparation](../interval_echo_collective_spin/README.md) · [Protocol](PROTOCOL.md) · [Calculation](measure.py) · [Results](results.json)

## A resolved energy measurement on the same excitation

Prepare either orbital state, or a coherent superposition, at port 14. Read whether the signed load reaches port 24 with the source rings in their vacuum and the destination rings carrying the orbital state. The clock and contacts match the original free transfer. The ranges below cover every normalized pure orbital input. Charge conjugation gives the same ranges.

| Preparation and read at time 30.8125 | Joint arrival probability | Unnormalized entanglement negativity with a reference |
| --- | --- | --- |
| Original coherent free flight | 12.0866–14.2314% | 0.0655761 |
| Resolve the free energy before flight and pool every outcome | 4.6563–5.3274% | Exactly zero |

Diagonalize the real symmetric finite generator in the signed Gauss sector. If the outcome of a sharp energy measurement is level $i$, its accepted transfer is the outer product of the projections of its eigenvector onto the two output and two input modes. Each such map has rank at most one. Any mixture over measured levels consequently gives a measure-and-prepare channel, including upon successful joint arrival. This calculation specifies a hypothetical energy-resolving instrument. The readout that established coherent transfer did not measure the energy. The finite charged ground is at 3.548011 native units above the neutral guide ground, with the fixed exterior compensator excluded. Giving that level an energy in keV would also require identification of its physical clock. [Energy and launch-weight measurement](../interval_echo_collective_spin/binding.json)

The simple spectrum has an exact certificate. Form $M=2H$, whose entries are integers. For the stored seed vector $v$, the determinants of $[v,Mv,\ldots,M^{159}v]$ modulo the prime 65521 are 8641 for the excess and 59498 for the vacancy. Invertibility modulo a prime implies invertibility over the reals. Real symmetry gives an orthonormal eigenbasis, and powers of $M$ applied to $v$ span at most one vector per distinct energy. Full rank therefore certifies exactly 160 distinct energies in each of these two finite sectors. Every unitary internal symmetry commuting with this free Hamiltonian acts by phases in that basis. A continuous non-Abelian internal multiplet at a single energy would require a different sector or a limiting degeneracy.

## Magnetic and species readings

On this same prepared excitation a half-quantum external material-link twist on 14–15 changes the joint arrival range to **0.1274–6.2458%** and shifts a free level by as much as 0.581347 native units. Applying the twist to the bridge 14–24 alone preserves the free spectrum and the arrival probabilities. At zero twist the energy slope vanishes on **every free level for each of the 19 links**. The derivative of the Hermitian generator is $i$ times a real antisymmetric matrix. The expectation in every real eigenvector is zero, and simplicity of every level rules out first-order splitting of a degenerate pair. The finite-response test resolves orbital interference. A spin-selective dipole interaction in a physical magnetic field would require an independently identified coupling. [Magnetic protocol](TWIST_PROTOCOL.md) · [All link responses](twist.json) · [Calculation](twist.py)

The comparison colour and weak currents have a 66-dimensional two-load input space on one twelve-port cell. In the mobile excess preparation the absolute counts on the two cells are (13,12) or (12,13). The vacancy gives (11,12) or (12,11). The literal two-load source space has zero overlap in every sharp configuration. Treating a dark response from that instrument as evidence of colour neutrality would also accept every other state outside its input domain. The written-field source needs a sensitive colour control and a weak-current response on its own prepared sector. [Earlier guarded current and its input](../../reverse-engineering-reality/model/candidate_laws/interval_echo/CURRENTS.md)

For a conversion $\tau$ seconds per native time, the physical energy is $\hbar E/\tau$. At laboratory waiting time $\tau t$, the phase is $Et$. Changing $\tau$ by a factor of three preserves the complete matched arrival matrix to within $1.7\times10^{-14}$ on the two tested signs while giving physical energies one third as large. The scale identity holds algebraically for every observable and exposure of the finite generator with the correspondingly reinterpreted time coordinate. A separately measured and physically identified reference transition on the same model would fix the scale. The laboratory electron calibration and the model have disjoint input data. [Scale ancestry and independent laboratory reconstruction](../interval_echo_scale_audit/README.md)

## The freely correlated flux cloud on one cell

A separate candidate is the lowest excited vacancy or excess on a fully written cell. Its ring energy correlates with the location of the charge. With all 30 material links and all 20 face exchanges open, both complete charge sectors on the selected fixed background have **simple spectra at every energy**. The vacancy sector has 5,790 distinct levels and the excess has 1,954. The first excited levels are 4.620847 and 5.730242 native units. Their nearest other free levels differ by 0.099392 and 0.189534, respectively. Each state has zero linear magnetic slope under every material-link twist. The fixed background need not relate the two signs by charge conjugation. A larger medium with different symmetries could have a different spectrum. [Preparation and correlation](../interval_echo_electron_flux_binding/soft_cloud.json) · [Magnetic protocol](CLOUD_PROTOCOL.md) · [Calculation and exact modular check](cloud.py) · [Numerical and algebraic records](cloud.json)

For a uniform external field in three independent directions, the phase of each hop is its sign times the signed projected area. The dimensionless field magnitude was 1/32 in both directions on each axis. The excited energies shift by $1.23\times10^{-5}$ to $3.64\times10^{-5}$ native units for the vacancy and by $8.26\times10^{-6}$ to $3.86\times10^{-5}$ for the excess. Opposite fields give equal spectra, and all perturbed states retain at least 99.896% squared overlap with the same zero-field branch. A pure-gradient phase preserves the energy. A scalar perturbation at port zero gives a linear energy slope equal to the independently read charge occupation there, 0.064440 for the vacancy and 0.065549 for the excess. The orbital response is measurable. The branches have no resting doublet or first-order Zeeman splitting in this instrument.

The exact spectrum test uses $M=2H$ with integer entries. In the field of residues modulo 65521, the scalar resolvent $u^T(zI-M)^{-1}v$ has an unreduced numerator and denominator computed from 2N moments, for dimension $N$. The replay checks $F(M)v=0$ directly for the candidate denominator $F$, and checks that its numerator has no common factor with $F$. The reduced denominator consequently has degree $N$. The Krylov columns of $v$ span the entire space modulo the prime and hence over the reals. Real symmetry of $M$ implies exactly $N$ distinct free energies.

## Replay

From the workspace root, run into fresh output paths. The computations share the original four-face source definition and use NumPy and SciPy.

~~~sh
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 reverse-engineering-reality/.venv/bin/python -B -W error experiments/interval_echo_electron_species/measure.py --output /tmp/echo_species_measure.json
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 reverse-engineering-reality/.venv/bin/python -B -W error experiments/interval_echo_electron_species/twist.py --output /tmp/echo_species_twist.json
cmp experiments/interval_echo_electron_species/results.json /tmp/echo_species_measure.json
cmp experiments/interval_echo_electron_species/twist.json /tmp/echo_species_twist.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 reverse-engineering-reality/.venv/bin/python -B -W error experiments/interval_echo_electron_species/cloud.py --output /tmp/echo_species_cloud.json
cmp experiments/interval_echo_electron_species/cloud.json /tmp/echo_species_cloud.json
~~~
