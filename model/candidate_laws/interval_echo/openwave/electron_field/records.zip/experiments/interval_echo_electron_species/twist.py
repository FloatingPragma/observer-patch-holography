"""Test the material-link magnetic probe on every free eigenstate of the selected guide."""

import argparse
from hashlib import sha256
import json
from pathlib import Path

import numpy as np
from scipy.linalg import eigh

from measure import COLLECTIVE, HERE, JoinedSpace, fan, vacuum_code


def sector(field, heads, degrees, addresses, sign, certificate):
    space = JoinedSpace(field, (heads, heads), sign)
    h = space.hamiltonian(degrees)
    assert certificate["sign"] == sign and certificate["heads_each_side"] == list(heads)
    assert certificate["cyclicity_of_twice_free_hamiltonian"]["determinant_residue"] != 0
    levels, vectors = eigh(h)
    vacuum, orbital = vacuum_code(field, heads)
    src = np.zeros((len(h), 2))
    dst = np.zeros_like(src)
    src[space.portal[0]] = np.einsum("ia,j->ija", orbital, vacuum)
    dst[space.portal[1]] = np.einsum("i,ja->ija", vacuum, orbital)
    baseline = np.array(certificate["head_and_charge_matched_joint_arrival"]["coherent_probability_range"])
    time = 30.8125
    response = []
    for a, b in space.edges:
        direction = np.zeros_like(h, dtype=np.int64)
        for column, state in enumerate(space.basis):
            other = space.material_step(state, (a, b))
            if state != other:
                row = space.ids[other]
                assert h[row, column] == -4
                direction[row, column] = sign if state[0] == a else -sign
        np.testing.assert_array_equal(direction, -direction.T)
        current = h * direction
        np.testing.assert_array_equal(current, -current.T)
        # The derivative is i times this real antisymmetric current. A real
        # eigenvector has zero expectation by antisymmetry, at every simple level.
        linear = float(np.max(abs(np.einsum("ia,ij,ja->a", vectors, current, vectors))))
        assert linear < 1e-12
        half_flux = np.where(direction == 0, h, -h)
        energies, modes = eigh(half_flux)
        amp = (dst.T @ modes) @ (np.exp(-1j * time * energies)[:, None] * (modes.T @ src))
        prob = np.linalg.eigvalsh(amp.conj().T @ amp)
        change = float(np.max(abs(energies - levels)))
        if (a, b) == (0, 6):
            assert change < 1e-12
            np.testing.assert_allclose(prob, baseline, atol=1e-12, rtol=0)
        response.append({"physical_edge": [addresses[a], addresses[b]],
                         "max_abs_linear_current_over_all_160_levels": linear,
                         "half_quantum_max_abs_level_shift": change,
                         "half_quantum_joint_arrival_probability_range": prob.tolist()})
    return {"sign": sign, "zero_twist_joint_arrival_range": baseline.tolist(), "links": response}


def run():
    certificate_path = HERE / "results.json"
    receipt = json.loads(certificate_path.read_text())
    best = json.loads((COLLECTIVE / "results.json").read_text())["headline"]["best_worst_qubit_success"]
    addresses = [*best["actual_ports"]["left"], *best["actual_ports"]["right"]]
    degrees = [6, *best["degrees"][0], 6, *best["degrees"][1]]
    field = fan(4)
    return {"sectors": [sector(field, tuple(c["heads_each_side"]), degrees, addresses, c["sign"], c)
                        for c in receipt["sectors"]],
            "sha256": {p.name: sha256(p.read_bytes()).hexdigest()
                       for p in [Path(__file__), HERE / "TWIST_PROTOCOL.md", certificate_path]}}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    path = parser.parse_args().output
    result = run()
    with path.open("x") as f:
        json.dump(result, f, indent=2, allow_nan=False)
        f.write("\n")
