"""Exact finite-guide formation energies and a rest-mass identifiability test."""

import argparse
from itertools import product
import hashlib
import json
from pathlib import Path
import sys

import networkx as nx
import numpy as np
from scipy.linalg import eigh, eigvalsh, expm

HERE = Path(__file__).resolve().parent
LOOPS = HERE.parent/"interval_echo_gauge_loops"
sys.path[:0] = [str(LOOPS),str(HERE.parent/"interval_echo_field_transfer"),str(HERE.parent/"interval_echo_current")]
from contact import Instrument
from geometry import edge, segments, support
from model.executable_model import federation


class Guide:
    def __init__(self, fixture, board, J):
        self.board, self.J = board,J
        self.edges = sorted(set().union(*(support(r) for r in fixture["rings"])))
        self.graph = nx.Graph(self.edges)
        self.vertices = sorted(self.graph)
        self.vid = {v:i for i,v in enumerate(self.vertices)}
        self.eid = {e:i for i,e in enumerate(self.edges)}
        ref = {(a,b):c for a,b,c in fixture["neutral_reference_links_and_lower_heads"]}
        reference = np.array([ref[e] for e in self.edges],int)
        self.ref_word = sum(1<<j for j,r in enumerate(reference) if r)
        self.anchor = fixture["source_seam"][0]
        self.compensators = {q:fixture["signed_reservoir_arms"][f"source,{q}"][2] for q in (1,-1)}
        self.rings = []
        for r in fixture["rings"]:
            mask = sum(1<<self.eid[e] for e in support(r))
            oriented = sum(1<<self.eid[edge(a,b)] for a,b in segments(r) if a<b)
            self.rings.append((mask,oriented))
        d = np.zeros((len(self.vertices),len(self.edges)),int)
        for i,(a,b) in enumerate(self.edges):
            d[self.vid[a],i],d[self.vid[b],i] = 1,-1
        self.incidence,self.ref_div = d,d@reference
        tree = [self.eid[edge(a,b)] for a,b in nx.bfs_edges(self.graph,self.vertices[0])]
        chords = sorted(set(range(len(self.edges)))-set(tree))
        self.tree,self.chords = tree,chords
        self.chord_values = np.array(list(product((0,1),repeat=len(chords))),int).T
        self.inverse = np.rint(np.linalg.inv(d[1:,tree])).astype(int)
        np.testing.assert_array_equal(self.inverse@d[1:,tree],np.eye(len(tree),dtype=int))

    def sector(self,q,inst):
        """Solve the tree fluxes for every assignment of chords and every mobile position."""
        basis = []
        for x in self.vertices if q else [self.anchor]:
            target = self.ref_div.copy()
            target[self.vid[x]] += q
            target[self.vid[self.anchor]] -= q  # fixed dressed injection string
            tree_heads = self.inverse@(target[1:,None]-self.incidence[1:,self.chords]@self.chord_values)
            for k in np.flatnonzero(np.all((tree_heads==0)|(tree_heads==1),axis=0)):
                heads = np.zeros(len(self.edges),int)
                heads[self.tree],heads[self.chords] = tree_heads[:,k],self.chord_values[:,k]
                np.testing.assert_array_equal(self.incidence@heads,target)
                word = sum(1<<j for j,v in enumerate(heads) if v)
                basis.append((x,word))
        index = {p:i for i,p in enumerate(basis)}
        h = np.zeros((len(basis),len(basis)))
        for i,(x,w) in enumerate(basis):
            for mask,direction in self.rings:
                if (w&mask) in (direction,direction^mask):
                    h[index[x,w^mask],i] -= self.J
            if q==0:
                continue
            h[i,i] += 8*(6-self.board.degree[x])*((1+q)**2-1)
            for y in self.graph[x]:
                a,b = edge(x,y)
                bit = 1<<self.eid[a,b]
                coin = int(bool(w&bit))
                pair = (1+q,1) if x==a else (1,1+q)
                ket = np.kron(inst.basis[:,coin],np.eye(9)[:,inst.pairs.index(pair)])
                column = (inst.h8/8)@ket-8*ket  # subtract uniform written vacuum on that link
                next_ket = np.kron(inst.basis[:,1-coin],np.eye(9)[:,inst.pairs.index(pair[::-1])])
                staying,jumping = (int(round(v@column)) for v in (ket,next_ket))
                np.testing.assert_allclose(column,staying*ket+jumping*next_ket,atol=1e-13)
                h[i,i] += staying
                if jumping:
                    h[index[y,w^bit],i] += jumping
        np.testing.assert_array_equal(h,h.T)
        connections = nx.from_numpy_array(h-np.diag(np.diag(h)))
        ids = sorted(nx.node_connected_component(connections,index[self.anchor,self.ref_word]))
        return [basis[i] for i in ids],h[np.ix_(ids,ids)],len(basis)

    def compare(self,inst):
        _,empty,_ = self.sector(0,inst)
        vacuum = eigvalsh(empty)[0]
        cases = {}
        for q in (1,-1):
            basis,h,total = self.sector(q,inst)
            indices = [self.vid[x] for x,_ in basis]
            mate = self.compensators[q]
            reservoir_cost = 8*(6-self.board.degree[mate])*((1-q)**2-1)
            energies,vectors = eigh(h)
            rest_candidate = energies[0]-vacuum
            density = np.bincount(indices,weights=vectors[:,0]**2,minlength=len(self.vertices))
            initial = np.eye(1,len(h),basis.index((self.anchor,self.ref_word))).ravel()
            # K is two on the source-plus-compensator experiment and zero on the empty apparatus.
            mu = 1.25
            t = 1.7
            shifted = h+2*mu*np.eye(len(h))
            native = expm(-1j*t*h)@initial
            test = expm(-1j*t*shifted)@initial
            np.testing.assert_allclose(test,np.exp(-2j*mu*t)*native,rtol=0,atol=2e-12)
            diff = float(np.max(abs(abs(test)**2-abs(native)**2)))
            cases[str(q)] = {"compatible_dimension":total,"source_connected_dimension":len(basis),
                "lowest_mobile_energy_minus_neutral_field_with_fixed_reservoir_subtracted":float(rest_candidate),
                "fixed_compensator_degree_reference_cost":int(reservoir_cost),
                "lowest_source_plus_compensator_energy_minus_neutral_field":float(rest_candidate+reservoir_cost),
                "lowest_state_position_participation_number":float(1/np.sum(density**2)),
                "mu":mu,"mu_K_shift_pair_formation_energy":2*mu,"mu_K_probability_residual":diff}
        return {"ports":len(self.vertices),"active_links":len(self.edges),"neutral_component_ground_energy":float(vacuum),
                "source_anchor":self.anchor,"signed_sectors":cases}


def blank_mode_test():
    data = json.loads((HERE.parent/"compact_fermion_repair"/"results.json").read_text())["dark_transport"]
    rows = []
    for level,entry in enumerate(data["federations"]):
        b = federation(level)
        graph = nx.Graph((i//12,j//12) for i,j in b.external)
        adj = nx.to_numpy_array(graph,nodelist=list(range(b.cells)))
        np.testing.assert_array_equal(adj.sum(axis=1),3)
        kinetic = -data["J"]*adj
        uniform = np.ones(b.cells)/np.sqrt(b.cells)
        for q in (1,-1):
            energy = entry["native_and_modified_sectors"][str(q)]["native_mode_energy"]
            h = energy*np.eye(b.cells)+kinetic
            bottom = energy-3*data["J"]
            np.testing.assert_allclose(h@uniform,bottom*uniform,atol=1e-13)
            np.testing.assert_allclose(eigvalsh(h)[0],bottom,atol=1e-12)
            rows.append({"cells":b.cells,"q":q,"native_cell_level":energy,"uniform_band_bottom":bottom,
                         "band_bottom_with_reference_load_one":bottom-16*q})
    return rows


def run():
    path = LOOPS/"results.json"
    field = json.loads(path.read_text())
    inst = Instrument()
    rows = []
    for level,board in enumerate(field["boards"]):
        # Use the saved home-zero guides and turn on all native matter contacts within each active strip.
        for f in board["fixtures"][:3]:
            guide = Guide(f,federation(level),field["loop_hopping"])
            rows.append({"cells":board["cells"],"loops":len(f["rings"]),**guide.compare(inst)})
    return {"candidate_commit":field["candidate_revision"],"gauge_receipt_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
            "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"written_gauge_guides":rows,
            "distinct_blank_collective_mode":blank_mode_test()}


if __name__=="__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,required=True)
    destination = parser.parse_args().output
    data = json.dumps(run(),indent=2,allow_nan=False)+"\n"
    with destination.open("x",encoding="utf-8") as out:
        out.write(data)
