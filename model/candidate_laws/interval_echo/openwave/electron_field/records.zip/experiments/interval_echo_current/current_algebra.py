"""Identify uniform pointer-additive charges and test the isolated field sector."""

from pathlib import Path
import sys
from functools import cache

import numpy as np
import sympy as sp

EXPERIMENTS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(EXPERIMENTS / "electron_identity"))
from operators import candidate, cell, exact_seam
from model.candidate_laws.interval_echo import currents
from model.executable_model import federation


def classify(h8, echo_support):
    law = candidate.native_law
    labels = [None, *law.LABELS]
    # All three port populations and all eleven memory populations are free coefficients.
    features = np.array([[*np.bincount(pair, minlength=3), *np.eye(11, dtype=int)[m]]
                         for m in range(11) for pair in law.SRC])
    odd = np.r_[[-1, 0, 1], np.zeros(11, int)]
    even = np.r_[[1, 0, 1], [2 * int(mark is not None and abs(mark[1]) == 2) for mark in labels]]
    basis = np.stack((np.r_[np.ones(3, int), np.zeros(11, int)],
                      np.r_[np.zeros(3, int), np.ones(11, int)], odd, even), axis=1)
    rank_rows = {}
    for name, support in (("free", h8 != 0), ("echo", echo_support),
                          ("both", (h8 != 0) | echo_support)):
        i, j = np.where(np.triu(support, 1))
        constraints = np.unique(features[i] - features[j], axis=0)
        rank = sp.Matrix(constraints).rank()
        rank_rows[name] = {"transition_pairs": len(i), "rank": rank, "nullity": 14-rank}
        np.testing.assert_array_equal(constraints @ basis, 0)
    assert rank_rows["both"]["nullity"] == sp.Matrix(basis).rank() == 4

    # Uniform material is a reducing sector even with arbitrary coherent memories.
    uniform = []
    for load in range(3):
        columns = np.arange(11) * 9 + law.SRC.index((load, load))
        other = np.setdiff1d(np.arange(99), columns)
        np.testing.assert_array_equal(h8[np.ix_(other, columns)], 0)
        uniform.append({"load": load, "memory_columns": len(columns), "free_leakage": 0})
    return {"constraints": rank_rows, "signed_generator": odd.tolist(),
            "even_generator": even.tolist(), "uniform_material_invariance": uniform}


def gateway_proof():
    local = cell()
    adjacency = sp.Matrix((np.diag(local.degree)-local.laplacian().toarray()).astype(int))
    root = sp.sqrt(5)
    eye = sp.eye(12)
    numerator = (adjacency-5*eye) * (adjacency+eye) * (adjacency+root*eye)
    projector = (numerator / ((root-5)*(root+1)*2*root)).applyfunc(sp.simplify)
    assert (projector*projector-projector).applyfunc(sp.simplify) == sp.zeros(12)
    assert (adjacency*projector-root*projector).applyfunc(sp.simplify) == sp.zeros(12)
    _, _, _, _, bands, *_ = currents._service(local, False, 1.)
    np.testing.assert_allclose(np.array(projector, dtype=float), bands[0] @ bands[0].T, atol=1e-12)
    @cache
    def gram(ports):
        return sp.simplify(projector.extract(ports,ports).det())

    layouts = {}
    for level in range(3):
        board = federation(level)
        counts = np.zeros(board.n, int)
        np.add.at(counts, np.asarray(board.external).ravel(), 1)
        np.testing.assert_array_equal(counts, board.degree-5)
        entries = {}
        incident = [[] for _ in range(board.cells)]
        for edge, (a,b) in enumerate(board.external):
            incident[a//12].append((edge,a%12))
            incident[b//12].append((edge,b%12))
        unfixed_ports = set()
        for home in range(board.cells):
            start = 12*home
            assert {tuple(sorted((a-start,b-start))) for a,b in board.seams
                    if start <= a < start+12 and start <= b < start+12} == set(local.seams)
            gates = tuple(np.flatnonzero(counts[start:start+12]).tolist())
            assert len(gates) == 3 and counts[start:start+12].max() == 1
            if gates not in entries:
                kernel = projector.extract(gates,gates).nullspace()
                entries[gates] = {"determinant": str(gram(gates)), "cells": 0,
                                  "unfixed_ports": [p for i,p in enumerate(gates)
                                                     if any(v[i] != 0 for v in kernel)]}
            entries[gates]["cells"] += 1
            unfixed_ports.update(start+i for i in entries[gates]["unfixed_ports"])
        # On the empty background the two endpoint residuals on a bond are opposites.
        # Remove whole independent sets in rounds, propagating zeros to the other end.
        unresolved = set(range(len(board.external)))
        removed = []
        while unresolved:
            fixed = set()
            for edges in incident:
                live = sorted((port,i) for i,port in edges if i in unresolved)
                if live and gram(tuple(port for port,i in live)).is_positive:
                    fixed.update(i for port,i in live)
            if not fixed:
                raise ArithmeticError("Unresolved gateway residual on the empty background")
            removed.append(len(fixed))
            unresolved -= fixed
        double_unfixed = sum(a in unfixed_ports and b in unfixed_ports for a,b in board.external)
        layouts[board.cells] = {"gateway_types": [{"ports": list(k), **v} for k,v in sorted(entries.items())],
                                "intercell_bonds": len(board.external), "empty_background_elimination": removed,
                                "filled_background_bonds_outside_first_derivative_exclusion": double_unfixed}
    return {"native_colour_projector": "sqrt(5) eigenspace of the cell adjacency", "boards": layouts}
