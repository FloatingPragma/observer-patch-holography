"""Exact local tests and register rotation tests for the electron search."""

from pathlib import Path
import sys

import numpy as np
from scipy.spatial.transform import Rotation

MODEL = Path(__file__).resolve().parents[2] / "reverse-engineering-reality"
sys.path.insert(0, str(MODEL))

from model.candidate_laws.interval_echo import candidate
from model.candidate_laws.interval_echo.openwave.row_30_memory.experiment import exact_collar
from model.executable_model import cell, rotations
from model.executable_model.carrier import icosahedron_from_coordinates, isomorphism
from model.executable_model import laws


def exact_seam():
    law = candidate.native_law
    x = law._write_pattern()
    g = np.rint(2 * sum(v * scale for v, scale in zip(law.generator_parts(), (1, candidate.KAPPA)))).astype(int)
    q = 2 * np.eye(90, dtype=int) - x @ x.T
    h8 = np.zeros((99, 99), dtype=int)
    h8[:9, :9] = 2 * (x.T @ g[9:, 9:] @ x)
    h8[9:, 9:] = q @ g[9:, 9:] @ q
    np.testing.assert_array_equal(x.T @ g[9:, 9:] @ q, 0)
    native, _ = exact_collar()
    np.testing.assert_allclose(h8 / 8, native, atol=1e-13)
    labels = [None, *law.LABELS]
    # The off-diagonal echo blocks contain X/sqrt(2), the marked block Q/2.
    echo_support = np.block([[np.zeros((9, 9), dtype=int), x.T], [x, q]]) != 0
    np.testing.assert_array_equal(echo_support, abs(law.echo()) > 1e-12)
    reverse = np.array([labels.index(None if mark is None else (1-mark[0], -mark[1]))*9
                        + law.SRC.index((b, a)) for mark in labels for a, b in law.SRC])
    np.testing.assert_array_equal(h8, h8[np.ix_(reverse, reverse)])
    np.testing.assert_allclose(law.echo(), law.echo()[np.ix_(reverse, reverse)], atol=1e-14)
    return h8, echo_support


def local_invariants(h8):
    law = candidate.native_law
    labels = [None, *law.LABELS]
    magnitudes = np.repeat([-1, *(abs(d) for _, d in law.LABELS)], 9)
    np.testing.assert_array_equal((magnitudes[:, None] - magnitudes) * h8, 0)
    indices = np.flatnonzero(magnitudes == 1)
    heads_a = np.array([labels[i//9][0] for i in indices])
    charges = np.array([law.SRC[i % 9] for i in indices]) - np.c_[heads_a, 1-heads_a]
    block = h8[np.ix_(indices, indices)]
    for charge in charges.T:
        np.testing.assert_array_equal((charge[:, None]-charge) * block, 0)
    for load in (0, 1, 2):
        src = np.eye(99)[:, law.SRC.index((load, 0))]
        occupied = law.echo() @ src
        np.testing.assert_allclose(law.echo().T @ ((magnitudes == load) * occupied), src, atol=1e-14)
    for sign, inputs in [(1, [(1, 1), (2, 1), (1, 2)]), (-1, [(1, 1), (0, 1), (1, 0)])]:
        embeds = []
        for coin in (0, 1):
            for pair in inputs:
                v = np.zeros(99, dtype=int)
                for d in (-1, 1):
                    v[labels.index((coin, d))*9 + law.SRC.index(pair)] = 1
                embeds.append(v)
        basis = np.column_stack(embeds)
        active = np.zeros(6, dtype=int)
        active[[2, 4] if sign == 1 else [1, 5]] = 1
        expected8 = 64*np.eye(6, dtype=int) - 32*np.outer(active, active)
        np.testing.assert_array_equal(h8 @ basis, basis @ expected8)
    return {"absolute_written_contrast_and_blank_flag_commute": True,
            "gauss_columns_all_endpoint_loads_both_coins_and_signs": len(indices),
            "max_local_gauss_commutator_entry": 0, "native_excess_and_vacancy_hops_verified": True}


def half_turn_pairs():
    identity = np.arange(12)
    group = [np.asarray(p) for p in rotations()]
    halves = [p for p in group if np.any(p != identity) and np.array_equal(p[p], identity)]
    return [(a, b) for i, a in enumerate(halves) for b in halves[i+1:] if np.array_equal(a[b], b[a])]


def register_rotations():
    c = cell()
    group = [np.asarray(p) for p in rotations()]
    directed = [(a, b) for edge in c.seams for a, b in (edge, edge[::-1])]
    actions = {tuple(p): np.array([directed.index((p[a], p[b])) for a, b in directed]) for p in group}
    for a in group:
        for b in group:
            np.testing.assert_array_equal(actions[tuple(a[b])], actions[tuple(a)][actions[tuple(b)]])
    candidates = {}
    for name in laws.names():
        law = laws.load(name)
        chart = np.asarray(isomorphism(c.seams, law.LABELLING))
        inverse_chart = np.argsort(chart)
        h = law.generator(c)
        h = h.toarray() if hasattr(h, "toarray") else np.asarray(h)
        for p in group:
            u = law.represent(chart[p[inverse_chart]], c)
            np.testing.assert_allclose(u @ h @ u.T, h, atol=1e-11)
        for a, b in half_turn_pairs():
            u = law.represent(chart[a[inverse_chart]], c)
            v = law.represent(chart[b[inverse_chart]], c)
            np.testing.assert_array_equal(u @ v @ u.T @ v.T, np.eye(len(h)))
        candidates[name] = {"registered_sector_dimension": len(h), "orthogonal_half_turn_commutator": 1}
    return {"geometric_rotations": len(group), "composition_checks": len(group)**2,
            "orthogonal_half_turn_pairs": len(half_turn_pairs()), "registered_candidates": candidates,
            "one_cell_full_interval_echo_dimension": str(3**12 * 11**30),
            "one_cell_all_blank_load_preparations": 3**12}


def marked_spinor_control():
    """An explicitly imposed spin lift on one-mark locations, tested against a native write."""
    geometry, edges = icosahedron_from_coordinates()
    points = geometry[isomorphism(cell().seams, edges)]
    seams = cell().seams
    axes = np.array([points[a]+points[b] for a, b in seams])
    axes /= np.linalg.norm(axes, axis=1)[:, None]
    pauli = np.array([[[0, 1], [1, 0]], [[0, -1j], [1j, 0]], [[1, 0], [0, -1]]])
    spinors = np.array([np.linalg.eigh(np.einsum("i,ijk->jk", axis, pauli))[1][:, -1] for axis in axes])
    encoding = spinors.conj() / np.sqrt(15)
    np.testing.assert_allclose(encoding.conj().T @ encoding, np.eye(2), atol=1e-12)
    lifts = {}
    for p in rotations():
        r = np.linalg.lstsq(points, points[list(p)], rcond=None)[0].T
        quat = Rotation.from_matrix(r).as_quat()
        spin = quat[3]*np.eye(2) - 1j*np.einsum("i,ijk->jk", quat[:3], pauli)
        dest = [seams.index(tuple(sorted((p[a], p[b])))) for a, b in seams]
        phases = np.array([np.vdot(spinors[j], spin @ k) for j, k in zip(dest, spinors)])
        lift = np.zeros((30, 30), complex)
        lift[dest, np.arange(30)] = phases
        np.testing.assert_allclose(abs(phases), 1, atol=1e-12)
        np.testing.assert_allclose(lift @ encoding, encoding @ spin, atol=1e-12)
        lifts[tuple(p)] = lift
    for a, b in half_turn_pairs():
        u, v = lifts[tuple(a)], lifts[tuple(b)]
        loop = u @ v @ u.conj().T @ v.conj().T
        np.testing.assert_allclose(loop, -np.eye(30), atol=1e-12)
    # The same loop fixes the unique sharp blank vacuum. An addressed echo maps that
    # vacuum to a symmetric, zero-contrast mark at e with norm one.
    law = candidate.native_law
    written = law.echo()[:, law.SRC.index((0, 0))]
    expected = np.zeros(99)
    for coin in (0, 1):
        expected[(1+law.LABELS.index((coin, 0)))*9] = 1/np.sqrt(2)
    np.testing.assert_allclose(written, expected, atol=1e-14)
    return {"mark_locations": len(seams), "encoded_spinor_dimension": 2,
            "supplied_lift_commutator": -1, "blank_vacuum_commutator": 1,
            "write_before_vs_after_loop_state_distance": float(2*np.linalg.norm(written)),
            "echo_trace": int(round(np.trace(law.echo())))}
