"""Reconstruct the laboratory electron energy from three cyclotron ratios and Rb photon recoil."""

import argparse
import hashlib
import json
from itertools import product
from pathlib import Path


H = 6.62607015e-34       # exact J s
C = 299792458            # exact m / s
J_PER_EV = 1.602176634e-19

# Values and standard uncertainties are explained and sourced in LABORATORY.md.
INPUTS = {
    "frequency_C6_over_e": (0.00027436518589, 5.8e-13),
    "frequency_Rb2_over_C3H7": (0.990799127824, 1.74e-10),
    "frequency_Rb2_over_C3H8": (1.013992022591, 2.66e-10),
    "h_over_mass_neutral_Rb_m2_per_s": (4.5913592729e-9, 5.7e-18),
}
CHEMISTRY = {
    "total_carbon_ionization_eV": (0, 2000),
    "first_two_Rb_ionizations_eV": (0, 100),
    "C3H7_ionic_chemical_offset_eV": (-100, 100),
    "C3H8_ionic_chemical_offset_eV": (-100, 100),
}


def reconstruct(r_carbon, r7, r8, recoil, i_carbon, i_rb, offset7, offset8):
    neutral_rb = H * C**2 / (recoil * J_PER_EV)
    s = (8 * r7 - 7 * r8) / 2
    electron = (s * (neutral_rb + i_rb) + 3*i_carbon - 8*offset7 + 7*offset8) / (18/r_carbon + 17 + 2*s)

    # Reconstruct the eliminated quantities and verify the three original measured ratios.
    rb_ion = neutral_rb - 2*electron + i_rb
    carbon = 6*electron/r_carbon + 6*electron - i_carbon
    hydrogen = (r7*rb_ion/2 - 3*carbon + electron - offset7) / 7
    recover = (
        6*electron / (carbon - 6*electron + i_carbon),
        2*(3*carbon + 7*hydrogen - electron + offset7) / rb_ion,
        2*(3*carbon + 8*hydrogen - electron + offset8) / rb_ion,
    )
    assert max(abs(a-b) for a,b in zip(recover, (r_carbon, r7, r8))) < 2e-15
    return electron / 1000


def run():
    centre = [value for value, _ in INPUTS.values()]
    mid_chemistry = [(a+b)/2 for a,b in CHEMISTRY.values()]
    # Add a second scatter allowance to the Rb ratio uncertainties. This intentionally
    # covers both interpretations of the scatter adjustment described in the experiment.
    uncertainties = [
        u*(2.2 if name in ("frequency_Rb2_over_C3H7", "frequency_Rb2_over_C3H8") else 1)
        for name, (_,u) in INPUTS.items()
    ]
    limits = [(v-3*u, v+3*u) for v,u in zip(centre, uncertainties)]
    corners = [reconstruct(*values) for values in product(*limits, *CHEMISTRY.values())]
    lo, hi = min(corners), max(corners)
    assert f"{lo:.3f}" == f"{hi:.3f}"
    return {
        "meaning": "Reconstruction of the real laboratory electron from published measurements.",
        "sources": {
            "Farnham_trap": "https://doi.org/10.1103/PhysRevLett.75.3598",
            "single_Farnham_input_transcription_equation_31": "https://physics.nist.gov/cuu/pdf/CODATA_RMP2000.pdf",
            "Rainville_trap_table_I": "https://doi.org/10.1023/A:1011922529114",
            "Bouchendira_recoil": "https://arxiv.org/abs/1012.3627",
            "SI_definitions": "https://www.bipm.org/en/measurement-units/",
        },
        "measurements_value_and_standard_uncertainty": INPUTS, "chemistry_boxes_eV": CHEMISTRY,
        "Rb_ratios_extra_scatter_factor": 2.2, "measurement_box_sigma": 3, "corners": len(corners),
        "midpoint_inputs_electron_energy_keV": reconstruct(*centre, *mid_chemistry),
        "all_corner_range_keV": [lo, hi], "rounded_lab_energy_keV": f"{lo:.3f}",
        "sha256_script": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    with parser.parse_args().output.open("x", encoding="utf-8") as out:
        out.write(json.dumps(run(), indent=2, allow_nan=False) + "\n")
