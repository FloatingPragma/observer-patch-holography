"""Quantum information and localized geometric turns at one charged end of a neutral pair."""
import argparse
from hashlib import sha256
import importlib.util
import json
from pathlib import Path

import numpy as np
from scipy import sparse
from scipy.linalg import eigvalsh
from scipy.sparse.linalg import eigsh

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
spec = importlib.util.spec_from_file_location("neutral_pair_fixture", PARENT / "measure.py")
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)


def stationary_code(patch):
    degree = fixture.federation(0).degree[:12]
    group = fixture.stabilizer(degree)
    generator = next(g for g in group if tuple(g) != tuple(range(12)))
    rotate = fixture.head_rotation(patch, generator)
    seed = fixture.invariant_words(patch, generator)[0]
    doubled, states, ids = fixture.pair_hamiltonian(patch, seed, degree)
    group_action = np.array([ids[generator[p], generator[m], rotate(w)] for p, m, w in states])
    triples = np.array(fixture.cycles(group_action))
    orbit = np.arange(len(triples))
    phase = np.exp(2j * np.pi * np.arange(3) / 3) / np.sqrt(3)
    q = sparse.coo_matrix((np.tile(phase, len(orbit)), (triples.ravel(), np.repeat(orbit, 3))),
                          shape=(len(states), len(orbit))).tocsr()
    projected = q.conj().T @ (0.5 * doubled @ q)
    values, vectors = eigsh(projected, k=4, which="SA", tol=1e-12,
                            v0=np.random.default_rng(393).normal(size=len(orbit)))
    i = int(np.argmin(values))
    positive = q @ vectors[:, i]
    positive *= np.exp(-1j * np.angle(positive[0]))
    code = np.column_stack((positive, positive.conj()))
    np.testing.assert_allclose(code.conj().T @ code, np.eye(2), atol=1e-12)
    residual = np.max(np.linalg.norm(doubled @ code / 2 - values[i] * code, axis=0))
    assert residual < 1e-9
    return states, code, float(values[i]), float(residual)


def accepted_read(words, amplitude, mask):
    local, il = np.unique(words & mask, return_inverse=True)
    outside, ix = np.unique(words & ~mask, return_inverse=True)
    assert len(set(zip(il, ix))) == len(words)
    wave = np.zeros((2, len(local), len(outside)), dtype=np.complex128)
    wave[:, il, ix] = amplitude.T / np.sqrt(2)
    flat = wave.reshape(len(local) * 2, len(outside))
    density = flat @ flat.conj().T
    partial = density.reshape(2, len(local), 2, len(local)).transpose(2, 1, 0, 3).reshape(density.shape)
    negativity = float(-np.minimum(eigvalsh(partial), 0).sum())
    weight = float(np.trace(density).real)
    # Dephasing the field leaves only 2x2 positive blocks, one per classical outcome.
    diag_control = min(eigvalsh(density[np.ix_([i, len(local) + i], [i, len(local) + i])])[0]
                       for i in range(len(local)))
    assert diag_control > -1e-12
    return {"local_words": len(local), "outside_words": len(outside),
            "herald_weight": weight, "unconditional_reference_negativity": max(0.0, negativity),
            "conditional_reference_negativity": negativity / weight,
            "max_number_local_words_at_fixed_outside": int(np.bincount(ix).max())}


def local_operator(patch, vertex):
    neighbors = set(patch.cell.neighbours[vertex])
    edges = [e for e in patch.edges if set(e) <= {vertex, *neighbors}]
    rim = set(tuple(sorted(e)) for e in edges if vertex not in e)
    rotations = [g for g in fixture.rotations() if g[vertex] == vertex and
                 all(tuple(sorted((n, g[n]))) in rim for n in neighbors)]
    assert len(rotations) == 2 and len(edges) == 10 and len(rim) == 5
    g = min(rotations)
    fullmask = sum(patch.bit[e] for e in edges)
    star = sum(patch.bit[e] for e in edges if vertex in e)
    def acted(word):
        result = word & ~fullmask
        for a, b in edges:
            h = a if word & patch.bit[a, b] else b
            ga, gb = g[a], g[b]
            if g[h] == min(ga, gb):
                result |= patch.bit[tuple(sorted((ga, gb)))]
        return result
    return star, fullmask, acted


def fivestep(words, amplitudes, action):
    allowed = set(map(int, words))
    survives = []
    for w in words:
        here = int(w)
        good = []
        for _ in range(5):
            here = action(here)
            good.append(here in allowed)
        assert here == int(w)
        # Invariance of local incoming head counts around a five-cycle under one
        # generator gives invariance under every power.
        assert not good[0] or all(good)
        survives.append(all(good))
    surviving = amplitudes[np.array(survives)]
    gram = surviving.conj().T @ surviving
    weight = float(np.trace(gram).real / 2)
    return {"sharp_words_passing_every_Gauss_check": sum(survives),
            "five_step_pass_probability_per_input_range": eigvalsh(gram).tolist(),
            "input_averaged_absolute_pass_probability": weight}


def run():
    patch = fixture.Patch()
    states, code, energy, residual = stationary_code(patch)
    positions = np.array([s[:2] for s in states])
    all_words = np.array([w for _, _, w in states], dtype=np.int64)
    distance = sparse.csgraph.shortest_path(patch.cell.adjacency(), unweighted=True, directed=False)
    results = []
    for local, local_sign in ((0, 1), (1, -1)):
        records = []
        for v in range(12):
            star, fan, action = local_operator(patch, v)
            for u in np.flatnonzero(distance[v] >= 2):
                accepted = (positions[:, local] == v) & (positions[:, 1 - local] == u)
                if not accepted.any():
                    records.append({"local_port": v, "distant_port": int(u), "sharp_states": 0})
                    continue
                words, wave = all_words[accepted], code[accepted]
                probabilities = eigvalsh(wave.conj().T @ wave)
                herald = float(np.mean(probabilities))
                assert herald > 0
                bare = accepted_read(words, wave, 0)
                star_read = accepted_read(words, wave, star)
                assert star_read["max_number_local_words_at_fixed_outside"] == 1
                assert max(x["conditional_reference_negativity"] for x in (bare, star_read)) < 1e-10
                fan_read = accepted_read(words, wave, fan)
                # Keeping the entire accepted field gives one coherent Kraus matrix.
                complete_conditional = float(np.sqrt(np.prod(probabilities)) / (2 * herald))
                steps = fivestep(words, wave, action)
                records.append({"local_port": v, "distant_port": int(u), "distance": int(distance[v,u]),
                                "sharp_states": len(words), "herald_probability_range": probabilities.tolist(),
                                "mean_herald_probability": herald,
                                "material_only": bare, "incident_star": star_read, "five_face_fan": fan_read,
                                "all_heads_conditional_negativity": complete_conditional, "local_fan_turn": steps})
        active = [s for s in records if s["sharp_states"]]
        assert sum(x["mean_herald_probability"] for x in active) > 0.52
        positive = [s for s in active if s["five_face_fan"]["conditional_reference_negativity"] > 1e-9]
        extremum = lambda rs, k: max(rs, key=lambda s:s["five_face_fan"][k])
        results.append({"local_sign": local_sign, "pairs_in_grid": len(records), "nonempty_heralds": len(active),
                        "pairs_with_conditional_fan_negativity_above_1e_minus_9": len(positive),
                        "sum_herald_probability": sum(x["mean_herald_probability"] for x in active),
                        "sum_accepted_fan_reference_negativity_for_resolved_pairs":
                            sum(x["five_face_fan"]["unconditional_reference_negativity"] for x in active),
                        "max_herald_weighted_fan_negativity_record": extremum(active,"unconditional_reference_negativity"),
                        "max_conditional_fan_negativity_record": extremum(active,"conditional_reference_negativity"),
                        "sum_FullTurn_pass_probability": sum(x["local_fan_turn"]["input_averaged_absolute_pass_probability"] for x in active),
                        "records": records})
    return {"energy": energy, "max_eigenpair_residual": residual, "connected_states": len(states), "local_end_reads": results,
            "sha256": {str(p.relative_to(PARENT)): sha256(p.read_bytes()).hexdigest()
                       for p in (Path(__file__), HERE / "DESIGN.md", PARENT / "measure.py", PARENT / "results.json")}}


if __name__ == "__main__":
    arg = argparse.ArgumentParser(description=__doc__)
    arg.add_argument("--output", type=Path, required=True)
    file = arg.parse_args().output
    result = run()
    with file.open("x") as f:
        json.dump(result, f, indent=2, allow_nan=False)
        f.write("\n")
