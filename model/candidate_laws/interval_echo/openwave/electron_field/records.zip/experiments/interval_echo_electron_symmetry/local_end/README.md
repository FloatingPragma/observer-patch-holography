# What one separated end retains of the orbital doublet

Prepare an arbitrary qubit in the lowest orbital doublet of the mobile excess–vacancy fixture. Its freely stationary energy is 12.456170 native units. Resolve the material positions of both signs and keep the trials in which they lie at least two port links apart. This selects 52.5715% on the equal mixture of logical inputs. The material sign can be chosen independently as the local observed end. [Pair fixture](../README.md) · [Local read and turn protocol](DESIGN.md) · [Calculation](measure.py) · [All input and rejected outcomes](results.json)

The material registers by themselves convey only classical position information. The written charge constraints fix the two distinct signed positions for each complete sharp field word. If the material positions are fixed and only the five spokes meeting the occupied port are kept, a fixed outside field fixes the spoke word uniquely. A difference of two allowed orientations would have zero divergence on a tree, hence no edge could change. Tracing out those outside records leaves a classical mixture of definite spoke states for every logical input. The resulting local channel is exactly entanglement-breaking.

Keeping the five additional edges around the rim gives the receiver five complete triangular faces. Independent field cycles then retain measurable quantum coherence with a reference entangled with the prepared orbital qubit.

| Local sign | Geometrically eligible port pairs | Pairs with source weight | Pairs with local reference negativity above $10^{-9}$ | Negativity conditional on separation, retaining both location flags |
| --- | ---: | ---: | ---: | ---: |
| Excess | 72 | 54 | 42 | 0.145018 |
| Vacancy | 72 | 54 | 39 | 0.040088 |

Negativity is the sum of absolute negative eigenvalues of the partially transposed joint reference/field density matrix. Its maximum is 0.5 for a normalized maximally entangled logical qubit. The last column sums the unnormalized values and divides by the total herald weight; every resolved endpoint pair remains a distinct classical flag. In the strongest conditional excess read the local port is 5 and the vacancy is at 2. The herald has weight 0.58083%, its local five-face negativity is 0.420211 and the entire accepted field gives 0.499541. The strongest conditional vacancy read on ports 5 and 2 has weight 0.03824% and negativity 0.202256. These maxima were selected from all locations. Dephasing the local sharp head words erases the recovered reference entanglement without changing either endpoint occupation distribution. The reduced-state calculation assumes access to all observables on the included field links.

For an independent spin test hold both material positions and every exterior head fixed. Rotate only the ten internal fan links around the occupied port by the 72° native geometric relabelling. The charged positions stay fixed. At the first turn **zero of 9,654 eligible sharp configurations** retain the same conserved head-count vector, separately for each choice of local sign. At each of the five rim vertices the local incoming-head count would have to remain constant around the rim to preserve the Gauss sector. Even in the unconstrained word space, five turns simply restore the original word with unit positive amplitude. A freely rotating, independently addressable spin on one end requires a different physical action. The shared orbital qubit genuinely reaches the near-end field, and this particular end-local geometric rotation fails on the entire separated input sector.

## Replay

Run from the workspace root with a fresh output path.

~~~sh
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 reverse-engineering-reality/.venv/bin/python -B -W error experiments/interval_echo_electron_symmetry/local_end/measure.py --output /tmp/echo_local_end.json
cmp experiments/interval_echo_electron_symmetry/local_end/results.json /tmp/echo_local_end.json
~~~
