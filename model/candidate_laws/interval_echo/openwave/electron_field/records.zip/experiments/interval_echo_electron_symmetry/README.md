# What can protect an internal doublet on a written cell?

On the 420 native cells of the 20-, 80- and 320-cell federations, **no proper nonidentity cell rotation preserves a single mobile charge's fixed Gauss sector** with the exterior held fixed. This result covers every integer head preparation, including ones outside the previously searched correlated-flux components. It concerns geometric permutations of the physical ports, the one-load degree reference and all 30 internal links. Other emergent actions or interactions involving multiple cells require separate tests. [Protocol](DESIGN.md) · [Enumerator and paired control](measure.py) · [All cell patterns and results](results.json)

| Federation | Cells with only the identity rotation | Cells with a threefold proper rotation |
| --- | ---: | ---: |
| 20 cells | 8 | 12 |
| 80 cells | 24 | 56 |
| 320 cells | 104 | 216 |

The free signed-load energy contains the port term $8(6-d)$, where $d$ is the full board degree. Check all sixty proper rotations of the native icosahedron against every local degree vector. There are ten distinct labelled vectors across the three boards. Each permitted nonidentity rotation acts on the twelve ports as four cycles of length three. It fixes no possible address for a parked local compensator. The census permits every local orientation that preserves the degrees, even if a particular exterior apparatus imposes additional restrictions. [Physical cell rotations](../../reverse-engineering-reality/model/executable_model/symmetry.py) · [Federation geometry](../../reverse-engineering-reality/model/executable_model/carrier.py)

There is a stronger restriction on all choices of prewritten heads. Let $h_v$ count heads at vertex $v$ on the 30 internal seams, and let $q=+1$ for an excess or $-1$ for a vacancy at $x$. A material hop changes its incident head and the load together. A face flip changes one incoming and one outgoing head at each of its vertices. The conserved integer vector is $b_v=h_v-q\,1[v=x]$, and $\sum_v b_v=30-q$. This equals 29 or 31. A threefold invariant integer vector is constant on each of the four three-port orbits, so its sum is a multiple of three. The proper rotation therefore takes any definite single-charge background to a different conserved sector. Three rotated sources can share spectra and be prepared coherently. Their sectors do not interconvert during the specified free evolution on the isolated cell. A degeneracy among those copies cannot on its own establish an internal spin carried by the localized load.

## A fixture with two freely moving opposite signs

On cell 0 of the 20-cell board, all ten seam orbits under the threefold rotation allow two choices of invariant head direction, giving 1,024 rotation-invariant neutral sharp words. Choose the numerically smallest in the established seam-bit order. Prepare an adjacent excess and vacancy by reversing the head on the first seam. The total mobile deviation is zero, so the conserved head vector sums to 30. Both signs visit all 12 ports, and the chosen sharp pair and both its rotated images belong to one connected 17,352-state component. All 30 interior contact terms and 20 face terms of the same positive-Laplacian law are active. This neutral preparation is a finite candidate instrument for comparing the two mobile ends and for asking whether a rotation localized to one end can be realized. The cell alone gives at most three port steps of separation.

The three spatial rotation characters have dimension 5,784 each. The two nonreal characters are complex conjugates, and the real free Hamiltonian pairs their spectra exactly. Their lowest two energies are 12.456170 and 12.469435 in native units. The trivial-character ground is at 11.413952. Three successive physical turns return exactly the identity on every sharp state. The two angular characters form an ordinary orbital pair under the proper geometric rotation.

A follow-up read prepares the two real standing modes of the lowest conjugate pair, using the sharp source to fix the phase convention. Reading only the two material positions distinguishes the modes by **0.137648 total variation**. In either traveling character the two loads are one, two, or three port steps apart with probabilities **47.43%, 46.99%, and 5.59%**. An intrinsic half-spin comparison would need a physical rotation acting on one independently mobile excitation, with its partner and reference held fixed. The simultaneous whole-cell rotation measured here moves both ends and their surrounding fields. [Complete spectrum and spatial reads](results.json)

## Replay

Run from the workspace root, with a fresh output path.

~~~sh
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 reverse-engineering-reality/.venv/bin/python -B -W error experiments/interval_echo_electron_symmetry/measure.py --output /tmp/echo_electron_symmetry.json
cmp experiments/interval_echo_electron_symmetry/results.json /tmp/echo_electron_symmetry.json
~~~
