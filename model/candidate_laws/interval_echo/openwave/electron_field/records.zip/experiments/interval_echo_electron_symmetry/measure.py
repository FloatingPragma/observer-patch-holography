"""Census cell rotation subgroups, and resolve the C3-compensated mobile pair control."""
import argparse
from collections import Counter, defaultdict
from hashlib import sha256
import json
from pathlib import Path
import sys

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import eigsh

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1] / "reverse-engineering-reality"
sys.path.insert(0, str(REPO))
from model.executable_model import rotations, federation
from model.candidate_laws.interval_echo.openwave.electron_field.flux_string.search import Patch


def cycles(perm):
    left = set(range(len(perm)))
    result = []
    while left:
        orbit = []
        point = min(left)
        while point in left:
            orbit.append(point)
            left.remove(point)
            point = perm[point]
        assert point == orbit[0]
        result.append(orbit)
    return result


def stabilizer(degree):
    return [r for r in rotations() if all(degree[i] == degree[j] for i, j in enumerate(r))]


def census():
    patterns, boards = {}, []
    for level in range(3):
        board = federation(level)
        counts, by_pattern = Counter(), defaultdict(list)
        for cell_id, degree in enumerate(board.degree.reshape(-1, 12)):
            degree = tuple(map(int, degree))
            if degree not in patterns:
                group = stabilizer(degree)
                patterns[degree] = {"degree": degree, "group": group,
                                    "proper_port_cycles": [cycles(g) for g in group]}
            group = patterns[degree]["group"]
            counts[len(group)] += 1
            by_pattern[degree].append(cell_id)
            for g in group:
                if tuple(g) != tuple(range(12)):
                    assert sorted(map(len, cycles(g))) == [3] * 4
        boards.append({"cells": board.cells, "degree_stabilizer_counts": dict(counts),
                       "degree_patterns": [{"degree": k, "cells": ids} for k, ids in sorted(by_pattern.items())]})
    return {"boards": boards, "native_patterns": [patterns[k] for k in sorted(patterns)],
            "fixed_single_charge_background_sum": {"excess": 29, "vacancy": 31}, "invariant_sum_mod_three": 0}


def head_rotation(patch, generator):
    target, mask = [], 0
    for i, (a, b) in enumerate(patch.edges):
        ga, gb = generator[a], generator[b]
        bit = patch.bit[tuple(sorted((ga, gb)))]
        target.append(bit)
        if ga > gb:
            mask |= bit
    # Lookup tables permute 30 arrow bits. A relabelled oriented seam whose
    # endpoints reverse order changes the encoding of its head.
    table = []
    for offset in range(0, 30, 8):
        values = []
        for word in range(256):
            values.append(sum(target[offset + j] for j in range(min(8, 30 - offset)) if word & (1 << j)))
        table.append(values)
    def rotate(word):
        moved = mask
        for k, values in enumerate(table):
            moved ^= values[word >> (8 * k) & 255]
        return moved
    return rotate


def invariant_words(patch, generator):
    remaining = set(patch.edges)
    choices = []
    while remaining:
        a, b = min(remaining)
        cycle = []
        for _ in range(3):
            edge = tuple(sorted((a, b)))
            remaining.remove(edge)
            cycle.append((a, b))
            a, b = generator[a], generator[b]
        assert (a, b) == cycle[0]
        choices.append(tuple(sum(patch.bit[tuple(sorted(e))] for e in cycle if e[i] == min(e)) for i in (0, 1)))
    assert len(choices) == 10
    return sorted(sum(pair[(k >> i) & 1] for i, pair in enumerate(choices)) for k in range(1 << len(choices)))


def pair_moves(patch, state):
    p, m, word = state
    for _, changed in patch.ring_moves(word):
        yield (p, m, changed), 1
    for dest, changed in patch.charge_moves(p, word, 1):
        if dest != m:
            yield (dest, m, changed), 8
    for dest, changed in patch.charge_moves(m, word, -1):
        if dest != p:
            yield (p, dest, changed), 8


def pair_hamiltonian(patch, seed, degree):
    a, b = min(patch.edges)
    head, tail = (a, b) if seed & patch.bit[a, b] else (b, a)
    source = (tail, head, seed ^ patch.bit[a, b])
    states = [source]
    ids = {source: 0}
    rows, cols, data = [], [], []
    for j, state in enumerate(states):
        p, m, word = state
        diagonal = 16 * (12 - int(degree[p]) - int(degree[m]))
        for other, weight in pair_moves(patch, state):
            if other not in ids:
                ids[other] = len(states)
                states.append(other)
            diagonal += weight
            rows.append(j)
            cols.append(ids[other])
            data.append(-weight)
        rows.append(j)
        cols.append(j)
        data.append(diagonal)
    h = sparse.coo_matrix((data, (rows, cols)), shape=(len(states), len(states))).tocsr()
    assert (h-h.T).nnz == 0
    return h, states, ids


def block_read(h, triples, character, source_id, states, distances):
    phase = np.exp(2j * np.pi * character * np.arange(3) / 3)
    r = np.arange(len(triples))
    q = sparse.coo_matrix((np.tile(phase / np.sqrt(3), len(r)), (triples.ravel(), np.repeat(r, 3))),
                          shape=(h.shape[0], len(r))).tocsr()
    block = q.conj().T @ (0.5 * h @ q)
    if character == 0:
        block = block.real
    orth = q.conj().T @ q - sparse.eye(block.shape[0])
    assert not orth.nnz or max(abs(orth.data)) < 1e-11
    rng = np.random.default_rng(393)
    levels, vectors = eigsh(block, which="SA", k=4, tol=1e-11, v0=rng.normal(size=len(r)), maxiter=40000)
    order = np.argsort(levels)
    levels, vectors = levels[order], vectors[:, order]
    error = float(max(np.linalg.norm(block @ vectors - vectors * levels, axis=0)))
    assert error < 1e-8
    full = q @ vectors
    p = np.array([s[0] for s in states])
    m = np.array([s[1] for s in states])
    lengths = distances[p, m].astype(int)
    split = None
    if character == 1:
        # Set the phase convention by the sharp source, then prepare the two
        # orthogonal real standing modes of this degenerate conjugate pair.
        lowest = full[:, 0] * np.exp(-1j * np.angle(full[source_id, 0]))
        standing = np.sqrt(2) * np.column_stack((lowest.real, lowest.imag))
        np.testing.assert_allclose(standing.T @ standing, np.eye(2), atol=1e-11)
        pm = [np.bincount(12 * p + m, weights=col**2, minlength=144) for col in standing.T]
        split = float(0.5 * sum(abs(pm[0] - pm[1])))
    return {
        "character_exponent_mod_three": character, "dimension": len(r),
        "lowest_four_levels": levels.tolist(), "residual": error,
        "localized_source_weights_on_first_four_levels": (abs(full[source_id]) ** 2).tolist(),
        "ground_charge_port_probabilities": {
            "excess": np.bincount(p, weights=abs(full[:, 0])**2, minlength=12).tolist(),
            "vacancy": np.bincount(m, weights=abs(full[:, 0])**2, minlength=12).tolist()},
        "lowest_state_port_distance_probabilities": np.bincount(lengths, weights=abs(full[:,0])**2, minlength=4).tolist(),
        "lowest_conjugate_standing_modes_joint_position_total_variation": split,
    }, block


def pair_control():
    patch = Patch()
    degree = federation(0).degree[:12]
    group = stabilizer(degree)
    gen = next(g for g in group if tuple(g) != tuple(range(12)))
    rotate = head_rotation(patch, gen)
    words = invariant_words(patch, gen)
    assert len(set(words)) == 1024 and all(rotate(w) == w for w in words)
    seed = words[0]
    beta = [0] * 12
    for a, b in patch.edges:
        beta[a if seed & patch.bit[a, b] else b] += 1
    assert [beta[j] for j in gen] == beta and sum(beta) == 30
    h, states, ids = pair_hamiltonian(patch, seed, degree)
    move = np.array([ids[gen[p], gen[m], rotate(w)] for p, m, w in states])
    assert np.array_equal(move[move[move]], np.arange(len(states)))
    assert (h[move][:,move] != h).nnz == 0
    assert not np.any(move == np.arange(len(states)))
    triples = np.array(cycles(move))
    assert triples.shape == (len(states) // 3, 3)
    sectors, blocks = {}, {}
    distances = sparse.csgraph.shortest_path(patch.cell.adjacency(), directed=False, unweighted=True)
    for char in (0, 1, 2):
        sectors[char], blocks[char] = block_read(h, triples, char, 0, states, distances)
        for arr in sectors[char]["ground_charge_port_probabilities"].values():
            np.testing.assert_allclose(np.array(arr)[list(gen)], arr, atol=1e-10)
    error = (blocks[1].conj() - blocks[2]).tocsr()
    assert max(abs(error.data), default=0) < 1e-11
    np.testing.assert_allclose(sectors[1]["lowest_four_levels"], sectors[2]["lowest_four_levels"], atol=1e-9, rtol=0)
    return {"board_cells": 20, "cell_index": 0, "proper_rotation":gen,
            "invariant_neutral_words": len(words), "selected_neutral_word": seed, "fixed_Gauss_head_vector":beta,
            "words_after_creation_in_rotated_source_order": [states[i] for i in (0, move[0], move[move[0]])],
            "connected_dimension": len(states), "full_turn_is_identity": True,
            "number_ports_visited_by_sign": [len({s[i] for s in states}) for i in (0, 1)],
            "nontrivial_conjugate_rotation_character_blocks_difference": float(max(abs(error.data), default=0)),
            "lowest_character_records": list(sectors.values())}


def run():
    sources = [Path(__file__), HERE / "DESIGN.md", REPO / "model/executable_model/carrier.py",
               REPO / "model/executable_model/symmetry.py",
               REPO / "model/candidate_laws/interval_echo/openwave/electron_field/flux_string/search.py"]
    return {"census": census(), "two_mobile_opposite_signs": pair_control(),
            "source_sha256": {str(p.relative_to(HERE.parents[1])): sha256(p.read_bytes()).hexdigest() for p in sources}}


if __name__ == "__main__":
    arg = argparse.ArgumentParser(description=__doc__)
    arg.add_argument("--output", type=Path, required=True)
    path = arg.parse_args().output
    result = run()
    with path.open("x") as f:
        json.dump(result, f, indent=2, allow_nan=False, default=lambda v: int(v))
        f.write("\n")
