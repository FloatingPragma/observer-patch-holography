"""Independent exact four-sector heat-trace comparison for the repaired ring Hamiltonian."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys

import sympy as sp

HERE = Path(__file__).resolve().parent
AUDIT = HERE.parent / "openwave_row_audit"
sys.path.insert(0, str(AUDIT))
from witness import POSITIONS, static_energy


def run():
    source = HERE.parent / "interval_echo_gauge_loops" / "results.json"
    guide = json.loads(source.read_text())["boards"][-1]["fixtures"][2]
    ref = {(a,b):value for a,b,value in guide["neutral_reference_links_and_lower_heads"]}
    t = sp.Symbol("t")
    forms = [t*(t-2), t*(t-2), t,
             t*(t-2)**2*(t-4)*((t-2)**2-2)*((t-4)**2-2)]
    rows = []
    for (p,m), expected in zip(POSITIONS, forms, strict=True):
        adjacency = sp.Matrix(static_energy(guide["rings"], ref, p, m)["adjacency"])
        lap = sp.diag(*[sum(adjacency.row(i)) for i in range(adjacency.rows)]) - adjacency
        cp = lap.charpoly(t).as_expr()
        assert sp.expand(cp-expected) == 0
        rows.append({"pair":[p,m], "field_dimension":adjacency.rows,
                     "monic_coefficients_for_twice_H":list(map(int, sp.Poly(cp,t).all_coeffs()))})
    return {"rows":rows,"spin_link_J":"1/2","input_sha256":sha256(source.read_bytes()).hexdigest(),
            "independent_solver_sha256":sha256((AUDIT/"witness.py").read_bytes()).hexdigest(),
            "script_sha256":sha256(Path(__file__).read_bytes()).hexdigest()}


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--output", type=Path, required=True)
    dest = cli.parse_args().output
    with dest.open("x", encoding="utf-8") as out:
        out.write(json.dumps(run(), indent=2, allow_nan=False)+"\n")
