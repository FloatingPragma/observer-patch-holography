"""Read signed field dispersion on a chain of physical spherical faces."""

import argparse
from collections import deque
from hashlib import sha256
import json
from pathlib import Path

import networkx as nx
import numpy as np
from scipy.linalg import eigh
from scipy.optimize import brentq

from measure import EXPERIMENTS, HERE, Instrument, Sphere, density_from_ground_cut, federation, pulse_oracle
from geometry import edge, segments, support
from release import instruments


def face_chain(sphere):
    graph = nx.Graph([(f, g) for f, links in enumerate(sphere.neighbours) for g in links])
    distances = nx.single_source_shortest_path_length(graph, 0)
    end = min(f for f in graph if distances[f] == max(distances.values()))
    chain = min(nx.all_shortest_paths(graph, 0, end))
    assert graph.subgraph(chain).number_of_edges() == len(chain) - 1
    return chain


def legal_basis(sphere, chain):
    loops = [sphere.faces[f] for f in chain]
    active = set.union(*(support(r) for r in loops))
    eligible = [r for r in sphere.triangles + list(sphere.faces) if support(r) <= active]
    assert {frozenset(support(r)) for r in eligible} == {frozenset(support(r)) for r in loops}
    bits = {e: 1 << j for j, e in enumerate(sorted(active))}
    heads = {}
    for r in loops:
        for a, b in segments(r):
            heads.setdefault(edge(a, b), int(a < b))
    start = sum(bits[e]*value for e, value in heads.items())
    masks = [sum(bits[e] for e in support(r)) for r in loops]
    direction = [sum(bits[edge(a,b)] for a,b in segments(r) if a < b) for r in loops]
    queue, seen, moves = deque([start]), {start}, set()
    while queue:
        word = queue.popleft()
        for mask, pointing in zip(masks, direction):
            if word & mask in (pointing, pointing ^ mask):
                dest = word ^ mask
                moves.add((word, dest))
                if dest not in seen:
                    seen.add(dest)
                    queue.append(dest)
    order = [start]
    for mask in masks:
        order.append(order[-1] ^ mask)
    assert set(order) == seen
    indices = {w:i for i,w in enumerate(order)}
    h = np.zeros((len(order),len(order)))
    for a,b in moves:
        i,j = indices[a], indices[b]
        assert abs(i-j) == 1
        h[i,i] += .5
        h[i,j] -= .5
    np.testing.assert_array_equal(h, h.T)
    np.testing.assert_array_equal(h @ np.ones(len(order)), 0)
    detector_heads = np.array([[bool(w & bits[sphere.detectors[f]]) for f in chain] for w in order])
    reference = np.array([heads[sphere.detectors[f]] for f in chain])
    flips = np.logical_xor(detector_heads, reference)
    np.testing.assert_array_equal(flips, np.arange(len(order))[:,None] > np.arange(len(chain)))
    return h, detector_heads, int(heads[sphere.source]), reference


def board_test(level, inst):
    sphere = Sphere(federation(level), "depth-first within shell")
    route = face_chain(sphere)
    for f in route:
        instruments(inst, sphere.source, sphere.detectors[f], sphere.arms[f])
    h, head_matrix, root_head, reference = legal_basis(sphere, route)
    size = len(h)
    eig, basis = eigh(h)
    weights = basis[0]

    def records(t):
        wave = basis @ (weights * np.exp(-1j*t*eig))
        readings = [density_from_ground_cut(size, wave, root_head, sign) @ head_matrix for sign in (1,-1)]
        # The component that clicks on the empty word yields delta_0 - Re(wave)
        # relative to the other source, multiplied by 2/size. Take complements
        # as needed for each detector orientation.
        first_minus_second = readings[0] - readings[1]
        clicked_empty_sign = 2*root_head - 1
        cumulative = -size/2 * clicked_empty_sign * (1 - 2*reference) * first_minus_second
        front = -np.diff(np.r_[1.0, cumulative, 0.0])
        np.testing.assert_allclose(front, wave.real, atol=3e-12)
        return front, readings

    modes = []
    for m in range(1,4):
        k = m*np.pi/size
        cosine = np.cos(k*(np.arange(size)+0.5))
        def read(t):
            return float(records(t)[0] @ cosine / cosine[0])
        # Use only the source/probe record to locate the oscillation zero.
        end = next(t for t in np.arange(.25, 4*size**2, .25) if read(t) <= 0)
        zero = brentq(read, end-.25, end, xtol=2e-13)
        rate = np.pi/(2*zero)
        prediction = 1 - np.cos(k)
        np.testing.assert_allclose(rate, prediction, atol=2e-13)
        obs = records(zero)[1]
        modes.append({"index":m, "spatial_phase_per_face":k, "first_record_zero":zero,
                      "recovered_angular_frequency":rate, "predicted_ring_frequency":prediction,
                      "observed_phase_speed_per_face":rate/k,
                      "positive_probe_crossings_at_zero_excess_then_vacancy":[x.tolist() for x in obs]})
    return {"cells":sphere.board.cells, "faces_on_path":route, "underlying_material_seams":
            [sphere.detectors[f] for f in route], "independent_gauss_words":len(h),
            "frequency_second_over_first":modes[1]["recovered_angular_frequency"]/modes[0]["recovered_angular_frequency"],
            "modes":modes}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    output = parser.parse_args().output
    instrument = Instrument()
    pulse_oracle(instrument)
    data = {"boards":[board_test(level,instrument) for level in (1,2)],
            "source_sha256":{str(p.relative_to(EXPERIMENTS)):sha256(p.read_bytes()).hexdigest()
                             for p in (HERE/"measure.py", Path(__file__), HERE/"WAVE_PROTOCOL.md",
                                       EXPERIMENTS/"interval_echo_vacuum_audit"/"repair"/"flight.py")}}
    content = json.dumps(data, indent=2, allow_nan=False) + "\n"
    with output.open("x", encoding="utf-8") as out:
        out.write(content)
