"""Static and transient field responses of the repaired written charge."""

import argparse
from collections import Counter, defaultdict
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import sys
from types import SimpleNamespace

import networkx as nx
import numpy as np
from scipy import sparse
from scipy.linalg import eigh
from scipy.sparse.linalg import expm_multiply
from scipy.special import logsumexp

HERE = Path(__file__).resolve().parent
EXPERIMENTS = HERE.parent
REPAIR = EXPERIMENTS / "interval_echo_vacuum_audit" / "repair"
sys.path.insert(0, str(REPAIR))
from flight import LaplacianSector, Sector, Sphere, pulse_oracle
from laplacian import Guide, Instrument, federation, graph_laplacian, local_columns, pair_hamiltonian, physical_basis
from geometry import edge, segments

ROW_AUDIT = EXPERIMENTS / "openwave_row_audit" / "run.py"
spec = spec_from_file_location("regional_audit", ROW_AUDIT)
previous = module_from_spec(spec)
spec.loader.exec_module(previous)

BETAS = (0.25, 1.0, 4.0, 16.0)
FOUR_PAIRS = ((230, 302), (398, 586), (230, 586), (398, 302))


def repaired_instrument(inst):
    embed = np.kron(inst.basis, np.eye(9))
    h = inst.h8 / 8
    written = np.rint(embed.T @ h @ embed).astype(int)
    return SimpleNamespace(basis=inst.basis, pairs=inst.pairs,
                           h8=8*(h + embed @ (graph_laplacian(written).toarray() - written) @ embed.T))


def guides(fixture, board, inst, source, coupling, independent_basis):
    guide = Guide(fixture, board, coupling)
    basis = physical_basis(guide, exhaustive=independent_basis)
    raw, _ = pair_hamiltonian(guide, basis, local_columns(inst))
    kinetics = graph_laplacian(raw)
    addresses = defaultdict(list)
    for index, (p, m, _) in enumerate(basis):
        addresses[p, m].append(index)
    heads = Counter(a if guide.ref_word & (1 << i) else b for i, (a, b) in enumerate(guide.edges))
    cell_graph = nx.Graph((a//12, b//12) for a, b in board.external)
    cell_dist = {c: nx.single_source_shortest_path_length(cell_graph, c)
                 for c in {v//12 for v in guide.vertices}}
    port_graph = nx.Graph(board.seams)
    port_dist = {v: nx.single_source_shortest_path_length(port_graph, v) for v in guide.vertices}
    rows, spectra, contact = [], {}, []
    maximum_row_sum = 0.0
    for (p, m), ids in addresses.items():
        pinned = kinetics[ids][:, ids].toarray()
        field = graph_laplacian(pinned).toarray()
        maximum_row_sum = max(maximum_row_sum, float(np.abs(field.sum(axis=1)).max()))
        levels = np.linalg.eigvalsh(field)
        np.testing.assert_allclose(levels[0], 0, atol=1e-12)
        # Degree reference 1 for both defects. Diagonals from moving out of the
        # fixed-position slice are present in one clamping convention only.
        site = 8 * (12 - board.degree[p] - board.degree[m])
        expected = 4 * (heads[p] + 1 + guide.graph.degree[m] - heads[m] + 1)
        actual = pinned - field
        if not guide.graph.has_edge(p, m):
            np.testing.assert_array_equal(actual, expected * np.eye(len(ids)))
        else:
            losses = expected - np.diag(actual)
            assert set(losses) <= {0, 8}
            contact.extend(losses.tolist())
        row = {
            "plus": p, "minus": m, "cell_distance": cell_dist[p//12][m//12], "port_distance": port_dist[p][m],
            "field_ground": float(levels[0]), "projected_ground": float(np.linalg.eigvalsh(pinned)[0] + site),
            "separable_site_price": int(expected + site),
        }
        for beta in BETAS:
            row[str(beta)] = float(-logsumexp(-beta*levels)/beta)
        if (p, m) in FOUR_PAIRS:
            spectra[p, m] = {"field_levels": levels.tolist(), **row}
        rows.append(row)

    nonlocal_rows = [r for r in rows if r["port_distance"] > 1]
    splits = [previous.regional_split(guide, set(basis), source, q) for q in (1, -1)]
    fits = {}
    for metric in ("cell_distance", "port_distance"):
        fits[metric] = {}
        for key in ("field_ground", "projected_ground", *(str(beta) for beta in BETAS)):
            fit = previous.spatial_fit(rows, metric, key, radial=False)
            fits[metric][key] = {k: fit[k] for k in (
                "observations", "rank_beyond_site_terms", "max_absolute_residual", "rms_residual",
                "attractive_coefficient", "planted_law_residual")}
    witness = None
    if all(pair in spectra for pair in FOUR_PAIRS):
        samples = [spectra[pair] for pair in FOUR_PAIRS]
        witness = {"source_pairs": samples, "alternating_sum": {
            key: sum(weight*r[key] for weight, r in zip((1, 1, -1, -1), samples))
            for key in ("field_ground", "projected_ground", *(str(beta) for beta in BETAS))}}
        for key in ("cell_distance", "port_distance"):
            assert sorted(r[key] for r in samples[:2]) == sorted(r[key] for r in samples[2:])
    return {"board_cells": board.cells, "guide_rings": len(guide.rings), "gauss_states": len(basis),
            "feasible_static_pairs": len(rows), "nonadjacent_static_pairs": len(nonlocal_rows),
            "largest_static_field_row_sum": maximum_row_sum,
            "maximum_nonadjacent_projected_energy_minus_additive_residual":
                max(abs(r["projected_ground"]-r["separable_site_price"]) for r in nonlocal_rows),
            "adjacent_contact_diagonal_reduction_counts": dict(Counter(map(int, contact))),
            "fits": fits, "four_source_witness": witness, "regional_half_pulse": splits}


def cross_cell_curl_rank(sphere):
    physical_edges = sorted(map(tuple, sphere.board.external))
    lookup = {edge(a,b): i for i, (a,b) in enumerate(physical_edges)}
    d = np.zeros((sphere.board.cells, len(physical_edges)), dtype=int)
    curl = np.zeros((len(physical_edges), sphere.n), dtype=int)
    for i, (a,b) in enumerate(physical_edges):
        d[a//12,i], d[b//12,i] = 1, -1
    for i, face in enumerate(sphere.faces):
        for a,b in segments(face):
            if a//12 != b//12:
                key = edge(a,b)
                assert key in lookup
                k = lookup[key]
                curl[k,i] = 1 if (a,b)==physical_edges[k] else -1
    np.testing.assert_array_equal(d @ curl, 0)
    np.testing.assert_array_equal(curl @ np.ones(sphere.n, dtype=int), 0)
    rank = np.linalg.matrix_rank(curl)
    assert rank == sphere.n - 1 == len(physical_edges) - np.linalg.matrix_rank(d)
    return {"external_links":len(physical_edges), "independent_divergence_free_boundary_patterns":int(rank),
            "face_stream_values_modulo_global_constant":sphere.n-1}


def density_from_ground_cut(words, evo, root_head, sign):
    """Return diagonal density after summing the transported and parked source outcomes."""
    clicked_empty = root_head == int(sign == 1)
    if clicked_empty:
        return ((abs(1 - evo)**2) + (np.arange(words) == 0)) / words
    return (abs(evo)**2 + (np.arange(words) != 0)) / words


def sphere_field(level, old):
    sphere = Sphere(federation(level), "depth-first within shell")
    native = Sector(sphere)
    native.verify_native_moves(sphere)
    sector = LaplacianSector(native)
    times = np.arange(2*sphere.n + 1, dtype=float)
    n = len(sector.words)
    root = np.eye(1, n, 0).ravel()
    ground = np.ones(n) / np.sqrt(n)
    cut = sector.hamiltonian([0])
    np.testing.assert_array_equal(cut @ root, 0)
    np.testing.assert_allclose(cut @ (ground - ground[0]*root), 0, atol=1e-14)
    evo = expm_multiply(-1j*sector.h, root, start=0, stop=times[-1], num=len(times))
    coin_source = sphere.head[sphere.source]
    readings = np.logical_xor(sector.flipped, [sphere.head[e] for e in sphere.detectors]).astype(float)
    sham = readings.mean(axis=0)
    shifts = {}
    for sign in (1, -1):
        mass = density_from_ground_cut(n, evo, coin_source, sign)
        np.testing.assert_allclose(mass.sum(axis=1), 1, rtol=0, atol=2e-11)
        shifts[sign] = mass @ readings - sham

    # An independent dense evolution of both postmeasurement states, at held times,
    # including the cut component, checks the pure-state interference term.
    direct_error = None
    if n <= 100:
        diagonalizations = [eigh(h.toarray()) for h in (sector.h, cut)]
        direct_error = 0.
        src_values = np.logical_xor(native.flipped[:,0], coin_source).astype(int)
        for t in (0, 1, 4, 16, 42, 84):
            for q in (1, -1):
                hop = src_values == int(q == 1)
                w = np.zeros(n)
                for retained, (e, v) in zip((~hop, hop), diagonalizations):
                    branch = v @ (np.exp(-1j*t*e) * (v.T @ (retained*ground)))
                    w += abs(branch)**2
                direct_error = max(direct_error, float(abs(w @ readings - sham - shifts[q][t]).max()))
        assert direct_error < 1e-12
    odd = (shifts[1] - shifts[-1]) / 2
    even = (shifts[1] + shifts[-1]) / 2
    threshold = .05/n
    records = []
    distances = nx.single_source_shortest_path_length(sphere.cells, sphere.source[0]//12)
    for f, (e, prev) in enumerate(zip(sphere.detectors, old["station_records"])):
        assert list(e) == prev["detector"]
        passing = np.flatnonzero(abs(odd[:,f]) >= threshold)
        t = int(np.argmax(abs(odd[:,f])))
        records.append({"face": f, "seam": e, "cell_steps": distances[e[0]//12],
                        "sham_positive_probe_crosses": float(sham[f]),
                        "first_odd_threshold": int(passing[0]) if len(passing) else None,
                        "time_peak_odd":t, "excess_positive_crosses_at_odd_peak":float(sham[f]+shifts[1][t,f]),
                        "vacancy_positive_crosses_at_odd_peak":float(sham[f]+shifts[-1][t,f]),
                        "signed_odd_peak":float(odd[t,f]), "max_absolute_even_response":float(abs(even[:,f]).max()),
                        "mixed_preparation_max_absolute_odd":prev["peak_absolute_positive_probe_shift"]})
    far = max(r["cell_steps"] for r in records if r["first_odd_threshold"] is not None)
    representative = max((r for r in records if r["cell_steps"]==far), key=lambda r: abs(r["signed_odd_peak"]))
    cut_control = density_from_ground_cut(n, root, coin_source, 1) @ readings - sham
    return {"cells":sphere.board.cells, "unmasked_cross_cell_faces":sphere.n, "component_states":n,
            "samples_from_zero_through_native_time":int(times[-1]), "threshold":threshold,
            "exact_cross_cell_material_transfer":0, "maximum_source_face_cut_residual":float(abs(cut_control).max()),
            "exact_transverse_boundary_space":cross_cell_curl_rank(sphere),
            "dense_two_branch_ground_check_residual":direct_error,
            "receivers_passing_odd_threshold":sum(r["first_odd_threshold"] is not None for r in records),
            "farthest_passing_receiver_cell_steps":far, "farthest_representative":representative,
            "peak_absolute_odd":float(abs(odd).max()), "peak_absolute_even":float(abs(even).max()),
            "receivers_passing_even_threshold":sum(r["max_absolute_even_response"]>=threshold for r in records),
            "records":records}


def run():
    paths = [EXPERIMENTS / "interval_echo_gauge_loops" / "results.json", REPAIR / "flight_results.json",
             REPAIR / "flight.py", REPAIR / "laplacian.py", ROW_AUDIT, HERE / "PROTOCOL.md", Path(__file__)]
    packet, flight = (json.loads(f.read_text()) for f in paths[:2])
    assert flight["candidate_revision"] == packet["candidate_revision"]
    inst = Instrument()
    source = repaired_instrument(inst)
    pulse_oracle(inst)
    static = [guides(fixture, federation(level), inst, source, packet["loop_hopping"], level == i == 0)
              for level, b in enumerate(packet["boards"]) for i, fixture in enumerate(b["fixtures"][:3])]
    grounds = [sphere_field(level, row) for level, row in zip((1,2), flight["cases"], strict=True)]
    return {"candidate_parent_revision":packet["candidate_revision"],
            "source_sha256":{str(f.relative_to(EXPERIMENTS)):sha256(f.read_bytes()).hexdigest() for f in paths},
            "static_guides":static, "coherent_ground_release":grounds}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    dest = parser.parse_args().output
    content = json.dumps(run(), indent=2, allow_nan=False) + "\n"
    with dest.open("x", encoding="utf-8") as out:
        out.write(content)
