"""Can the charge-only junction distinguish a fermion spin singlet from the scalar charge?"""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import expm_multiply

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "interval_echo_vacuum_audit" / "repair"))
from laplacian import federation
from geometry import catalog
from junction import build, motif


def fock_generator(basis, h):
    """Add two spin states per constituent with spin-independent hops and spatial hard core."""
    entries = h.tocoo()
    rows, cols, values = [], [], []
    for target, source, element in zip(entries.row, entries.col, entries.data):
        target_sites, source_sites = basis[target][0], basis[source][0]
        for label in range(4):
            spins = divmod(label, 2)
            orbitals = [2*site+s for site, s in zip(source_sites, spins)]
            parity = 1
            if target_sites != source_sites:
                leaving, = set(source_sites)-set(target_sites)
                entering, = set(target_sites)-set(source_sites)
                # Apply c†_{enter,s} c_{leave,s} in canonical orbital order.
                i = source_sites.index(leaving)
                new_orbital = 2*entering + orbitals.pop(i) % 2
                j = sum(o < new_orbital for o in orbitals)
                orbitals.insert(j, new_orbital)
                parity = (-1)**(i+j)
            assert tuple(o//2 for o in orbitals) == target_sites
            output_label = 2*(orbitals[0] % 2) + orbitals[1] % 2
            rows.append(4*target + output_label)
            cols.append(4*source + label)
            values.append(element * parity)
    matrix = sparse.csr_matrix((values, (rows, cols)), shape=(4*len(basis),)*2)
    assert (matrix - matrix.T).nnz == 0
    return matrix


def trial(board, selected, q):
    basis, _, incoming, outgoing, scalar, antisymmetric = build(board, selected, q)
    fermions = fock_generator(basis, scalar)
    unit = sparse.eye(len(basis))
    root_two = np.sqrt(2.)
    states = {
        "triplet_up_up": np.array([1., 0., 0., 0.]),
        "triplet_down_down": np.array([0., 0., 0., 1.]),
        "triplet_zero": np.array([0., 1., 1., 0.])/root_two,
        "singlet": np.array([0., 1., -1., 0.])/root_two,
    }
    probabilities = {}
    for name, spin in states.items():
        embedding = sparse.kron(unit, spin[:, None], format="csr")
        benchmark = scalar if name == "singlet" else antisymmetric
        residual = fermions @ embedding - embedding @ benchmark
        assert not residual.nnz or max(abs(residual.data)) < 1e-13
        # Both charge injections use the even field circulation, as in the earlier comparison.
        initial = embedding[:, incoming].sum(axis=1).A1/root_two
        tested = expm_multiply(-0.25j*fermions, initial)
        np.testing.assert_allclose(np.sum(abs(tested)**2), 1, atol=1e-13)
        probabilities[name] = float((abs(tested.reshape(-1, 4)[outgoing])**2).sum())
    distinguishable = (probabilities["singlet"] + probabilities["triplet_zero"]) / 2
    return {"cells": board.cells, "ring_length": len(selected[0]), "sign": q,
            "charge_configurations": len(basis), "spinful_Fock_configurations": fermions.shape[0],
            "inclusive_arrival_at_native_time_0.25": probabilities,
            "one_up_one_down_product_arrival": distinguishable,
            "independent_unpolarized_arrival": sum(probabilities.values())/4}


def run():
    rows = []
    for level in range(3):
        board = federation(level)
        triangles, faces, _, _ = catalog(board)
        for inventory in (triangles, faces):
            selected = motif(board, inventory)
            rows.extend(trial(board, selected, q) for q in (-1, 1))
    return {"assumption": "Hypothetical spin-1/2 fermions; spin-independent original charge and field hops; hard core at each physical address.",
            "original_model_has_this_spin_doublet": False, "runs": rows,
            "operator_check": "H_spin U_singlet = U_singlet H_charge; H_spin U_triplet = U_triplet H_antisymmetric in all four spin channels.",
            "inputs": {p.name: sha256(p.read_bytes()).hexdigest()
                       for p in (Path(__file__), HERE/"junction.py", HERE/"results.json")}}


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--output", type=Path, required=True)
    path = cli.parse_args().output
    record = json.dumps(run(), indent=2, allow_nan=False) + "\n"
    with path.open("x", encoding="utf-8") as out:
        out.write(record)
