"""Inclusive matter-only exchange interference with a dynamical dressed field."""

from collections import Counter, deque
from itertools import combinations

import numpy as np
from scipy.linalg import eigvalsh
from scipy.sparse import csr_matrix, diags
from scipy.sparse.csgraph import connected_components
from scipy.sparse.linalg import expm_multiply

from geometry import edge, segments
from traps import trapped


def motif(board, rings):
    """Two equal-degree arms on a common ring vertex and two isolated compensation links."""
    for ring in sorted(rings, key=lambda r: (len(r), tuple(r))):
        for centre in ring:
            for a, b in combinations(sorted(set(board.neighbours[centre]) - set(ring)), 2):
                if board.degree[a] != board.degree[b]:
                    continue
                support = set(ring) | {a, b}
                for x in sorted(set(board.neighbours[a]) - support):
                    for y in sorted(set(board.neighbours[b]) - support - {x}):
                        return tuple(ring), centre, (a, b), (x, y)
    raise ValueError("No exchange junction")


def heads(word, edges):
    return [a if word & (1 << i) else b for i, (a, b) in enumerate(edges)]


def build(board, selected, q):
    ring, centre, leaves, reserves = selected
    edges = sorted({edge(x, y) for x, y in segments(ring)} | {edge(centre, a) for a in leaves})
    ids = {e: i for i, e in enumerate(edges)}
    mask = sum(1 << ids[edge(x, y)] for x, y in segments(ring))
    clockwise = sum(1 << ids[edge(x, y)] for x, y in segments(ring) if x < y)
    arms = sum(1 << ids[edge(centre, a)] for a in leaves if (a < centre) == (q == 1))
    seeds = [(tuple(sorted(leaves)), arms | x) for x in (clockwise, mask ^ clockwise)]
    reference = Counter(heads(seeds[0][1], edges))
    for a, r in zip(leaves, reserves):
        # External injection seam head inversion supplies q to a and -q to its reserve.
        reference.update([r if q == 1 else a])

    def events(state):
        occupants, word = state
        for i, (a, b) in enumerate(edges):
            if (a in occupants) == (b in occupants):
                continue
            src, dst = (a, b) if a in occupants else (b, a)
            if (q == 1) != (heads(word, edges)[i] == src):
                continue
            other = next(v for v in occupants if v != src)
            exchange = -1 if min(src, dst) < other < max(src, dst) else 1
            yield (tuple(sorted([other, dst])), word ^ (1 << i)), 4., exchange
        if word & mask in (clockwise, mask ^ clockwise):
            yield (occupants, word ^ mask), .5, 1

    done = set(seeds)
    queue = deque(seeds)
    while queue:
        state = queue.popleft()
        for target, _, _ in events(state):
            if target not in done:
                done.add(target)
                queue.append(target)
    # Independent integer Gauss enumeration over all possible internal head words.
    vertices = sorted(set(ring) | set(leaves))
    sharp = np.arange(1<<len(edges))
    loads = np.zeros((len(sharp), len(vertices)), dtype=np.int8)
    loads[:,[vertices.index(v) for v in leaves]] = q
    for i,(x,y) in enumerate(edges):
        change = ((sharp>>i)&1) - ((seeds[0][1]>>i)&1)
        loads[:,vertices.index(x)] += change.astype(np.int8)
        loads[:,vertices.index(y)] -= change.astype(np.int8)
    allowed = np.logical_or(loads == 0, loads == q).all(axis=1)
    independent = {(tuple(vertices[j] for j in np.flatnonzero(loads[w])),int(w)) for w in sharp[allowed]}
    assert independent == done
    basis = sorted(done)
    index = {s: i for i, s in enumerate(basis)}
    row, col, weights, fermion_weights = [], [], [], []
    diagonal = []
    reflection, fermion_reflection = [], []
    a, b = leaves
    swap = lambda v: b if v == a else a if v == b else v
    for i, (s, w) in enumerate(basis):
        flux = Counter(heads(w, edges))
        flux.update([a if q == 1 else r for a, r in zip(leaves, reserves)])
        flux.subtract(reference)
        charges = Counter({v:q for v in s} | {v:-q for v in reserves})
        assert flux == charges
        # Common reference load one; the isolated compensators contribute common constants.
        onsite = 8 * sum(6-int(board.degree[v]) for v in s)
        for target, strength, sign in events((s, w)):
            row.append(i)
            col.append(index[target])
            weights.append(-strength)
            fermion_weights.append(-strength * sign)
            onsite += strength
        diagonal.append(onsite)
        rotated_word = sum(1 << ids[edge(swap(x), swap(y))]
                           for (x, y), h in zip(edges, heads(w, edges))
                           if swap(h) == min(swap(x), swap(y)))
        reflection.append(index[tuple(sorted(map(swap, s))), rotated_word])
        fermion_reflection.append(1 if swap(s[0]) < swap(s[1]) else -1)
    h = csr_matrix((weights, (row, col)), shape=(len(basis),)*2) + diags(diagonal)
    f = csr_matrix((fermion_weights, (row, col)), shape=h.shape) + diags(diagonal)
    for matrix in (h, f):
        assert (matrix - matrix.T).nnz == 0
    assert connected_components(h)[0] == 1
    reflected = np.array(reflection)
    phase = diags(fermion_reflection, dtype=float)
    assert (h - h[reflected][:, reflected]).nnz == 0
    assert (f - phase @ f[reflected][:, reflected] @ phase).nnz == 0
    incoming = np.asarray([index[s] for s in seeds])
    outgoing = np.asarray([i for i, (occ, w) in enumerate(basis) if set(occ).isdisjoint(leaves)])
    np.testing.assert_array_equal(reflected[incoming], incoming)
    np.testing.assert_array_equal(reflected[outgoing], outgoing)
    np.testing.assert_array_equal(np.asarray(fermion_reflection)[incoming], -1)
    np.testing.assert_array_equal(np.asarray(fermion_reflection)[outgoing], +1)
    return basis, edges, incoming, outgoing, h, f


def test(board, selected, sign):
    basis, edges, src, dst, h, f = build(board, selected, sign)
    initial = np.eye(len(basis))[:, src]
    # Column order consists of the two circulating words; any coherent dressing is in their span.
    out = {}
    for name, generator in [('repaired', h), ('antisymmetric_control', f)]:
        times = np.arange(33)/8
        evolved = expm_multiply(-1j*generator, initial, start=0, stop=4, num=len(times))
        np.testing.assert_allclose(np.sum(abs(evolved)**2, axis=1), 1, atol=1e-12)
        rows = []
        for t, wave in zip(times, evolved):
            collected = wave[dst]
            read = collected.conj().T @ collected
            lo, hi = eigvalsh(read)
            even = (read.sum()/2).real
            odd = ((read.trace()-read[0,1]-read[1,0])/2).real
            rows.append({"time":float(t), "even":float(even), "odd":float(odd),
                         "worst_pure_input":float(lo), "best_pure_input":float(hi)})
        if name == 'repaired':
            assert rows[2]['worst_pure_input'] > 1e-4
        else:
            assert max(r['best_pure_input'] for r in rows) < 1e-24
        # Exact leading unrestricted transfer, including both circulating input words.
        third = (generator @ generator @ generator @ initial)[dst]
        np.testing.assert_allclose((generator @ generator @ initial)[dst], 0)
        gram = third.T @ third / 36
        np.testing.assert_allclose(gram, (4096/9)*np.eye(2) if name=='repaired' else 0, atol=1e-12)
        out[name] = {"leading_t6_inclusive_probability":float(gram[0,0]), "readings": rows}
    ring, centre, leaves, reserves = selected
    return {"board_cells":board.cells,"ring":ring,"centre":centre,"arm_ports":leaves,"reserve_ports":reserves,
            "charge":sign,"edges":edges,"all_head_words_examined":1<<len(edges),"reachable_word_and_load_states":len(basis),"accepted_detector_states":len(dst),
            "results":out, "adiabatic_exchange":trapped(basis,selected,h,f)}
