"""A spin-blind three-charge comparison on an equal-input fork with a live field ring."""

import argparse
from collections import deque
from hashlib import sha256
from itertools import combinations, permutations, product
import json
from pathlib import Path

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import expm_multiply

from spin_blind import federation, catalog
from geometry import edge, segments
from junction import heads
from laplacian import Instrument, graph_laplacian


def select_fork(board, rings):
    for ring in sorted(rings, key=lambda r: (len(r), tuple(r))):
        for first_exit in ring:
            for centre in sorted(set(board.neighbours[first_exit]) - set(ring)):
                free = sorted(set(board.neighbours[centre]) - set(ring))
                for inputs in combinations(free, 3):
                    if len({board.degree[v] for v in inputs}) != 1:
                        continue
                    for second_exit in sorted(set(free) - set(inputs)):
                        core = set(ring) | {centre, second_exit, *inputs}
                        choices = [sorted(set(board.neighbours[v])-core) for v in inputs]
                        reserves = next((p for p in product(*choices) if len(set(p)) == 3), None)
                        if reserves:
                            return tuple(ring), centre, inputs, (first_exit, second_exit), reserves
    raise ValueError("No fork with three matched arms and distinct reservoir links")


def charge_graph(board, layout, q):
    ring, c, arms, exits, reserves = layout
    edges = sorted({edge(x, y) for x, y in segments(ring)} | {edge(c,v) for v in (*arms, *exits)})
    ids = {e:i for i,e in enumerate(edges)}
    mask = sum(1 << ids[edge(x,y)] for x,y in segments(ring))
    clockwise = sum(1 << ids[edge(x,y)] for x,y in segments(ring) if x < y)
    base = 0
    for x,y in [*((v,c) for v in arms), *((c,v) for v in exits)]:
        if (x < y) == (q == 1):
            base |= 1 << ids[edge(x,y)]
    seeds = [(tuple(arms), base | w) for w in (clockwise, mask ^ clockwise)]

    def moves(state):
        sites, word = state
        for i,(a,b) in enumerate(edges):
            if (a in sites) == (b in sites):
                continue
            old, new = (a,b) if a in sites else (b,a)
            head = a if word & (1<<i) else b
            if (head == old) == (q == 1):
                yield (tuple(sorted((set(sites)-{old})|{new})), word ^ (1<<i)), 4
        if word & mask in (clockwise, mask ^ clockwise):
            yield (sites, word ^ mask), 0.5

    reached = set(seeds)
    todo = deque(seeds)
    while todo:
        for target,_ in moves(todo.popleft()):
            if target not in reached:
                reached.add(target)
                todo.append(target)
    basis = sorted(reached)
    index = {s:i for i,s in enumerate(basis)}
    support = sorted(set(ring) | {c, *arms, *exits})
    original_heads = heads(seeds[0][1], edges)
    row, col, data = [], [], []
    for j,state in enumerate(basis):
        sites, word = state
        current_heads = heads(word, edges)
        assert all(current_heads.count(v)-original_heads.count(v) == q*((v in sites)-(v in arms))
                   for v in support)
        diag = 8*sum(6-int(board.degree[v]) for v in sites)
        for target, strength in moves(state):
            row.append(index[target]); col.append(j); data.append(-strength)
            diag += strength
        row.append(j); col.append(j); data.append(diag)
    h = sparse.csr_matrix((data, (row,col)), shape=(len(basis),)*2)
    assert (h - h.T).nnz == 0
    incoming = np.array([index[s] for s in seeds])
    outgoing = np.array([j for j,(sites,_) in enumerate(basis) if not set(arms).intersection(sites)])
    assert len(outgoing)
    # Verify both generators of S3 on the complete material AND head-word graph.
    for left,right in zip(arms,arms[1:]):
        swap = lambda v: right if v == left else left if v == right else v
        order = []
        for sites,word in basis:
            transformed = 0
            for (a,b),head in zip(edges,heads(word,edges)):
                link = edge(swap(a),swap(b))
                if swap(head) == link[0]:
                    transformed |= 1 << ids[link]
            order.append(index[tuple(sorted(map(swap,sites))),transformed])
        assert (h - h[order][:,order]).nnz == 0
        assert all(order[j] == j for j in (*incoming, *outgoing))
    return basis, h, incoming, outgoing


def fock_hops(basis, h, labels):
    """Build the antisymmetric Fock matrix by removing and inserting occupied orbitals."""
    index = {s:i for i,s in enumerate(labels)}
    row, col, data = [], [], []
    internal_dim = len(labels)
    entries = h.tocoo()
    for target, source, value in zip(entries.row,entries.col,entries.data):
        before, after = basis[source][0], basis[target][0]
        if before == after:
            transitions = [(i,i,1) for i in range(internal_dim)]
        else:
            src, = set(before)-set(after)
            dst, = set(after)-set(before)
            left, right = before.index(src), after.index(dst)
            transitions = []
            for i,assignment in enumerate(labels):
                updated = list(assignment)
                updated.insert(right, updated.pop(left))
                transitions.append((i, index[tuple(updated)], (-1)**(left+right)))
        for i,j,sign in transitions:
            row.append(internal_dim*target+j)
            col.append(internal_dim*source+i)
            data.append(sign*value)
    result = sparse.csr_matrix((data,(row,col)), shape=(internal_dim*len(basis),)*2)
    assert (result-result.T).nnz == 0
    return result


def trial(board, layout, q):
    basis,h,src,dst = charge_graph(board,layout,q)
    initial = np.eye(len(basis))[:,src]
    g = initial.copy()
    for step in range(5):
        np.testing.assert_array_equal(g[dst], 0)
        g = h @ g
    np.testing.assert_array_equal(g[dst].T @ g[dst], (12*4**5)**2 * np.eye(2))
    times = [0.125, 0.25, 0.5, 1.]
    scalar = []
    for t in times:
        wave = expm_multiply(-1j*t*h, initial)[dst]
        effect = wave.conj().T @ wave
        scalar.append({"time":t, "even_ring":float(effect.real.sum()/2),
                       "odd_ring":float((effect.trace()-effect[0,1]-effect[1,0]).real/2),
                       "worst_input":float(np.linalg.eigvalsh(effect)[0])})
    # Verify all spin inputs and both circulating field seeds, including possible
    # spin-field entanglement: the entire outgoing amplitude map must vanish.
    two_labels = list(product(range(2),repeat=3))
    two = fock_hops(basis,h,two_labels)
    spin_input = np.kron(initial,np.eye(8))
    spin_target = (8*dst[:,None]+np.arange(8)[None,:]).ravel()
    leakage = 0.
    for t in times:
        amplitudes = expm_multiply(-1j*t*two, spin_input)[spin_target]
        leakage = max(leakage,float(np.linalg.norm(amplitudes,2)**2))
    assert leakage < 1e-24
    # Mark one input by a scalar potential. The outgoing detector is identical,
    # but the three input histories can now be distinguished during propagation.
    detuning = np.array([8.0 * (layout[2][0] in sites) for sites, _ in basis])
    detuned = two + sparse.diags(np.repeat(detuning, 8),format="csr")
    arrivals = expm_multiply(-0.5j * detuned, spin_input)[spin_target]
    detuned_best = float(np.linalg.norm(arrivals, 2)**2)
    assert detuned_best > 1e-5
    # With three distinct internal labels, an antisymmetric internal state
    # exists. Its spatial dynamics recovers the original scalar prediction.
    three_labels = list(permutations(range(3)))
    internal = np.array([(-1)**sum(s[i] > s[j] for i,j in combinations(range(3),2))
                         for s in three_labels])/np.sqrt(6)
    embedding = sparse.kron(sparse.eye(len(basis)),internal[:,None],format="csr")
    three = fock_hops(basis,h,three_labels)
    residual = three @ embedding - embedding @ h
    assert not residual.nnz or max(abs(residual.data)) < 1e-13
    ring, centre, arms, exits, reserves = layout
    return {"cells":board.cells, "sign":q, "ring":list(ring), "centre":centre, "input_arms":arms,
            "output_arms":exits, "frozen_reserves":reserves, "charge_graph_size":len(basis),
            "inclusive_output_states":len(dst), "scalar_probabilities":scalar,
            "maximum_two_spin_Fock_probability_over_all_inputs_and_sampled_times":leakage,
            "two_spin_control_one_detuned_input_best_arrival_at_0.5":detuned_best,
            "three_flavour_antisymmetric_internal_state_reproduces_scalar_operator":True}


def run():
    inst = Instrument()
    embed = np.kron(inst.basis,np.eye(9))
    repaired = graph_laplacian(np.rint(embed.T @ (inst.h8/8) @ embed).astype(int)).toarray()
    rows = []
    for level in range(3):
        board = federation(level)
        triangles, faces, _, _ = catalog(board)
        for rings in (triangles,faces):
            layout = select_fork(board,rings)
            for q in (1,-1):
                for a,b in ((1,1),(1+q,1+q),(1,1+q),(1+q,1)):
                    for head in (0,1):
                        j = 9*head + inst.pairs.index((a,b))
                        allowed = a != b and (head == (a == 1+q)) == (q == 1)
                        expected = np.zeros(18)
                        if allowed:
                            expected[j],expected[9*(1-head)+inst.pairs.index((b,a))] = 4,-4
                        np.testing.assert_array_equal(repaired[:,j],expected)
                rows.append(trial(board,layout,q))
    return {"script_sha256":sha256(Path(__file__).read_bytes()).hexdigest(), "runs":rows}


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--output",type=Path,required=True)
    out = cli.parse_args().output
    data = json.dumps(run(),indent=2,allow_nan=False) + "\n"
    with out.open("x",encoding="utf-8") as stream:
        stream.write(data)
