"""Adiabatic sign of full two-charge, ring-field eigenstates under exchanged trap positions."""

import numpy as np
from scipy.linalg import eigh


def trace(h, occupations, path, strength, subdivisions):
    matrix = h.toarray()
    diagonal = np.diag_indices_from(matrix)
    samples, levels, gaps, tracking = [], [], [], []
    for source, target in zip(path, path[1:]):
        initial = np.isin(occupations, source).sum(axis=1)
        final = np.isin(occupations, target).sum(axis=1)
        assert np.max(abs(final-initial)) == 1
        for j in range(subdivisions):
            fraction = j / subdivisions
            run = matrix.copy()
            run[diagonal] -= strength * (initial + fraction*(final-initial))
            energy, vec = eigh(run)
            space = np.diff(energy)
            gaps.append(np.minimum(np.r_[np.inf,space],np.r_[space,np.inf]))
            samples.append(vec)
            if j == 0:
                tracking.append((vec[initial==2]**2).sum(axis=0))
                levels.append(energy)
    links = [(a*b).sum(axis=0) for a,b in zip(samples,np.roll(samples,-1,axis=0))]
    lower = np.min(gaps, axis=0) - strength/subdivisions
    # An interval of one mesh step has a perturbation bounded by strength/subdivisions.
    # Guard the sign transport on each eigenline, as well as nondegeneracy between grid points.
    resolved = lower > 2 * strength/subdivisions
    candidate = np.min(tracking, axis=0) >= .90
    signs = np.prod(np.sign(links), axis=0)
    assert np.min(np.abs(links),axis=0)[resolved].min() > .5
    return [{"index":i, "initial_trapped_energy":float(levels[0][i]),
             "min_joint_trap_occupation_at_stops":float(np.min(tracking,axis=0)[i]),
             "min_sampled_level_gap":float(np.min(gaps,axis=0)[i]),
             "gap_lower_bound":float(max(0.,lower[i])), "resolved_parallel_transport":bool(resolved[i]),
             "geometric_sign":int(signs[i]) if resolved[i] else None,
             "tracks_two_charges_at_all_stops":bool(candidate[i])}
            for i in range(len(resolved))]


def trapped(basis, selected, h, f):
    ring, o, (a,b), _ = selected
    s = ring[(ring.index(o)+1)%len(ring)]
    changed = ((a,b),(o,b),(s,b),(s,o),(s,a),(o,a),(a,b))
    stayed = ((a,b),(o,b),(s,b),(o,b),(a,b),(a,o),(a,b))
    occ = np.array([addr for addr,_ in basis])
    strength, mesh = 32., 128
    native = trace(h, occ, changed, strength, mesh)
    ordinary = trace(h, occ, stayed, strength, mesh)
    control = trace(f, occ, changed, strength, mesh)
    reference = trace(f, occ, stayed, strength, mesh)
    assert (native[0]["geometric_sign"],ordinary[0]["geometric_sign"]) == (1,1)
    assert (control[0]["geometric_sign"],reference[0]["geometric_sign"]) == (-1,1)
    return {"trap_strength":strength,"subdivisions_per_move":mesh,"exchange":changed,"reference":stayed,
            "repaired_exchange_levels":native,"repaired_reference_levels":ordinary,
            "control_lowest_exchange":control[0],"control_lowest_reference":reference[0]}
