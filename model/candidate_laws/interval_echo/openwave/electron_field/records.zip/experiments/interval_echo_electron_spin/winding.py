"""Determine what an odd circulating ring contributes to a charged material tour."""

import argparse
from collections import Counter
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import sys

import networkx as nx
import numpy as np
from scipy.linalg import eigh, expm

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / "interval_echo_vacuum_audit/repair"))
from laplacian import Instrument, graph_laplacian
from geometry import canonical, catalog, edge, segments
from model.executable_model import cell, federation


class ChargeSpace:
    def __init__(self, edges, rings, anchor, reference, sign):
        self.edges = sorted(edges)
        self.bits = {ab:1<<i for i,ab in enumerate(self.edges)}
        self.rings = [self.orient(r) for r in rings]
        self.sign = sign
        self.anchor = anchor
        self.ref = sum(self.bits[ab] for ab,v in reference.items() if ab[0]==v)

        # A direct enumeration is bounded by 2^13 on the selected actual faces.
        sources = Counter(self.heads(self.ref))
        basis = []
        for w in range(1<<len(edges)):
            diff = Counter(self.heads(w)); diff.subtract(sources)
            diff[anchor] += sign
            active = [(v,n) for v,n in diff.items() if n]
            if len(active)==1 and active[0][1]==sign:
                basis.append((active[0][0],w))
        self.basis = sorted(basis)
        self.ids = {s:i for i,s in enumerate(self.basis)}

    def heads(self, w):
        return [a if self.bits[a,b]&w else b for a,b in self.edges]

    def orient(self, r):
        mask = sum(self.bits[edge(a,b)] for a,b in segments(r))
        cw = sum(self.bits[edge(a,b)] for a,b in segments(r) if a<b)
        return mask,cw

    def material_step(self, state, e):
        x,w = state
        a,b = e
        if x not in e or ((a==x)==bool(self.bits[e]&w)) != (self.sign==1):
            return state
        target = (b if a==x else a,w^self.bits[e])
        assert target in self.ids
        return target

    def projector(self, i, parity):
        mask,cw = self.rings[i]
        mat = np.zeros((len(self.basis),)*2)
        for n,(x,w) in enumerate(self.basis):
            if w&mask in (cw,mask^cw):
                j = self.ids[x,w^mask]
                mat[n,n],mat[n,j] = .5,.5*parity
        np.testing.assert_array_equal(mat@mat,mat)
        return mat

    def hamiltonian(self, degree):
        h = np.zeros((len(self.basis),)*2)
        for n,s in enumerate(self.basis):
            h[n,n] += 8*(6-int(degree[s[0]]))
            for e in self.edges:
                t = self.material_step(s,e)
                if t!=s:
                    h[n,n] += 4
                    h[self.ids[t],n] -= 4
            for mask,cw in self.rings:
                if s[1]&mask in (cw,cw^mask):
                    h[n,n] += .5
                    h[self.ids[s[0],s[1]^mask],n] -= .5
        np.testing.assert_array_equal(h,h.T)
        return h


def check_transfers():
    inst = Instrument()
    embed = np.kron(inst.basis,np.eye(9))
    h = graph_laplacian(np.rint(embed.T@(inst.h8/8)@embed)).toarray()
    u = expm(-1j*np.pi*h/8)
    perm = np.eye(18)
    for q in (-1,1):
        for left in (False,True):
            head = int((q==1)==left)
            pair = (1+q,1) if left else (1,1+q)
            i = 9*head+inst.pairs.index(pair)
            j = 9*(1-head)+inst.pairs.index(pair[::-1])
            perm[i,i],perm[j,i] = 0,1
    np.testing.assert_allclose(u,perm,atol=1e-14)
    return float(abs(u-perm).max())


def loop_read(board, r, q):
    refs = {edge(a,b):a for a,b in segments(r)}
    device = ChargeSpace(set(refs),[r],r[0],refs,q)
    mask,_ = device.rings[0]
    prepared = [(r[0],device.ref), (r[0],device.ref^mask)]
    assert len(device.basis)==len(r)+1
    steps = [edge(a,b) for a,b in segments(r)]
    protocols = {"forward":steps,"reverse":steps[::-1],"palindrome":steps+steps[-2::-1],
                 "even_tour":2*(steps+steps[-2::-1]),"zero_winding":steps+steps[::-1]}
    readings = {}
    for key, schedule in protocols.items():
        returned = np.zeros((2,2))
        trajectories = []
        for j,s in enumerate(prepared):
            x,w = s
            moves=[]
            for act in schedule:
                new = device.material_step((x,w),act)
                if new[0]!=x:
                    moves.append((x,new[0]))
                x,w = new
            if x==r[0]:
                returned[prepared.index((x,w)),j]=1
            trajectories.append({"directed_moves":moves,"final_charge":x,"charge_returned":x==r[0]})
        by_input = {}
        for parity in (1,-1):
            v = np.array([1,parity])/np.sqrt(2)
            branch = returned@v
            response = float(v@branch)
            # Ideal Ramsey route selector. The reference arm does nothing and has the same duration.
            by_input[str(parity)] = {
                "returned_material_probability":float(branch@branch),
                "same_field_and_return_probability":float(response**2),
                "returned_field_reference_amplitude":response,
                "unconditional_bright_port_probability":float((1+response)/2)}
        if key in ("forward","reverse"):
            assert np.linalg.matrix_rank(returned)==1
        elif key == "palindrome":
            np.testing.assert_array_equal(returned,[[0,1],[1,0]])
        else:
            np.testing.assert_array_equal(returned,np.eye(2))
        readings[key] = {"return_operator":returned.tolist(),"incoming_word_paths":trajectories,
                         "field_superposition_readings":by_input}
    return {"cells":board.cells,"sign":q,"loop":r,"compatible_charge_words":len(device.basis),"protocols":readings}


def nested():
    board = cell()
    inner = board.faces()[0]
    patch = [f for f in board.faces() if set(f)&set(inner)]
    edge_counts = Counter(edge(a,b) for f in patch for a,b in segments(f))
    perimeter = nx.Graph([ab for ab,c in edge_counts.items() if c==1])
    outer, = nx.cycle_basis(perimeter)
    outer = canonical(outer)
    assert set(outer).isdisjoint(inner)
    assert nx.is_connected(perimeter) and set(dict(perimeter.degree).values())=={2}

    reading = loop_read(board,outer,1)
    outer_swap = np.array(reading["protocols"]["palindrome"]["return_operator"])
    # Explicit physical words on the entire cell, with intervening seams written and fixed.
    # Both boundary words and both inner words have the same integer divergence.
    anchor = outer[0]
    compensation = min(set(board.neighbours[anchor]) - set(inner) - set(outer))
    feeder = edge(anchor,compensation)
    def complete_word(outer_reverse,inner_reverse):
        words = {e:e[0] for e in board.seams}
        for r, flip in ((outer,outer_reverse),(inner,inner_reverse)):
            for a,b in segments(r):
                words[edge(a,b)] = b if flip else a
        words[feeder] = anchor
        return tuple(words[e] for e in board.seams)
    bits = list(product((0,1),repeat=2))
    basis = [complete_word(*word) for word in bits]
    assert len(set(basis))==4 and len({tuple(sorted(Counter(w).items())) for w in basis})==1
    mapped = np.zeros((4,4))
    baseline = dict(zip(board.seams,basis[0]))
    baseline[feeder] = compensation
    reference = Counter(baseline.values())
    steps = [edge(x,y) for x,y in segments(outer)]
    for j,(outword,inword) in enumerate(bits):
        head = dict(zip(board.seams,basis[j]))
        position = anchor
        for x,y in steps+steps[-2::-1]:
            if position in (x,y) and head[x,y] == position:
                position = y if position == x else x
                head[x,y] = position
            difference = Counter(head.values())
            difference.subtract(reference)
            assert difference == Counter({position:1,compensation:-1})
        assert position == anchor
        final = tuple(head[e] for e in board.seams)
        assert final == complete_word(1-outword,inword)
        mapped[basis.index(final),j] = 1.
    np.testing.assert_array_equal(mapped,np.kron(outer_swap,np.eye(2)))
    by = []
    for outer_parity,inner_parity in product((1,-1), repeat=2):
        state = np.kron([1,outer_parity],[1,inner_parity])/2
        by.append({"outer_parity":outer_parity,"inner_parity":inner_parity,"winding_amplitude":float(state@mapped@state)})
    return {"inner":inner,"outer":outer,"enclosed_faces":len(patch),"fixed_compensator":compensation,"fixed_other_links":len(board.seams)-len(inner)-len(outer),
            "on_outer_path_only":reading, "independent_product_state_readings":by}


def joined_triangles(board):
    faces = board.faces()
    by = {}
    for a,b in board.external:
        for f in (r for r in faces if a in r):
            for g in (r for r in faces if b in r):
                sym = tuple(len({board.degree[v] for v in ring if v!=portal})==1
                            for ring,portal in ((f,a),(g,b)))
                if sym in ((True,True),(False,False)) and sym not in by:
                    by[sym] = (a,b,f,g)
        if len(by)==2: break
    assert len(by)==2
    return list(by.items())


def release(board, fixture, sym, q):
    a,b,f,g = fixture
    bridge = edge(a,b)
    ref = {edge(x,y):x for r in (f,g) for x,y in segments(r)}
    ref[bridge] = a if q==1 else b
    space = ChargeSpace(set(ref),[f,g],a,ref,q)
    h = space.hamiltonian(board.degree)
    ev, modes = eigh(h)
    regions = np.array([x in g for x,w in space.basis])
    present = np.diag(regions.astype(float))
    aodd, aeven = space.projector(0,-1),space.projector(0,1)
    bodd = space.projector(1,-1)
    np.testing.assert_array_equal(present@bodd,bodd@present)
    np.testing.assert_array_equal(aeven@bodd,bodd@aeven)
    reads = {}
    for parity in (-1,1):
        v = np.zeros(len(space.basis))
        for u,w in product((0,1),repeat=2):
            word = space.ref ^ (u*space.rings[0][0]) ^ (w*space.rings[1][0])
            v[space.ids[a,word]] = parity**u/2
        observations = []
        for t in np.arange(129)/8:
            state = modes@(np.exp(-1j*t*ev)*(modes.T@v))
            def p(op):
                return float(np.vdot(op@state,op@state).real)
            observations.append({"time":float(t), "charge_at_destination":p(present),
                                 "charge_at_destination_and_odd_left":p(present@aodd),
                                 "charge_at_destination_and_odd_right":p(present@bodd),
                                 "charge_at_destination_even_left_odd_right":p(present@aeven@bodd)})
        reads[str(parity)]=observations
        if sym==(True,True):
            assert max(r["charge_at_destination"] for r in observations)>.10
            assert max(r["charge_at_destination_and_odd_right"] for r in observations)<1e-25
            if parity==-1:
                np.testing.assert_allclose([r["charge_at_destination_and_odd_left"] for r in observations],
                                           [r["charge_at_destination"] for r in observations],atol=1e-13)
    if sym==(True,True):
        for ring,portal in ((f,a),(g,b)):
            l,r = sorted(set(ring)-{portal})
            def reflect(x): return r if x==l else l if x==r else x
            perm = []
            for x,w in space.basis:
                new = sum(space.bits[edge(reflect(i),reflect(j))]
                          for (i,j),head in zip(space.edges,space.heads(w))
                          if reflect(head)==min(reflect(i),reflect(j)))
                perm.append(space.ids[reflect(x),new])
            np.testing.assert_array_equal(h,h[np.ix_(perm,perm)])
            involution = np.eye(len(h))[perm]
            if ring == f:
                np.testing.assert_array_equal(present@aodd,present@(np.eye(len(h))-involution)/2)
            else:
                # Only an arrived charge precisely at the portal permits B to circulate.
                at_portal = np.diag(np.array([x==b for x,w in space.basis],float))
                np.testing.assert_array_equal(present@bodd,at_portal@(np.eye(len(h))-involution)/2)
            for parity in (-1,1):
                v = np.zeros(len(space.basis))
                for u,w in product((0,1),repeat=2):
                    word = space.ref ^ (u*space.rings[0][0]) ^ (w*space.rings[1][0])
                    v[space.ids[a,word]] = parity**u/2
                np.testing.assert_array_equal(involution@v,(parity if ring==f else 1)*v)
    def parity_state(position, parity_a, parity_b):
        v = np.zeros(len(space.basis))
        seed = space.ref if position==a else space.ref ^ space.bits[bridge]
        for u,w in product((0,1),repeat=2):
            word = seed ^ (u*space.rings[0][0]) ^ (w*space.rings[1][0])
            v[space.ids[position,word]] = parity_a**u*parity_b**w/2
        return v
    incoming = np.stack([parity_state(a,parity,1) for parity in (1,-1)],axis=1)
    outgoing = np.stack([parity_state(b,1,parity) for parity in (1,-1)],axis=1)
    transfers = []
    for t in np.arange(129)/8:
        matrix = (outgoing.T@modes * np.exp(-1j*t*ev)) @ (modes.T@incoming)
        singular = np.linalg.svd(matrix,compute_uv=False)
        weight = float(np.sum(abs(matrix)**2))
        record = {"time":float(t),"coherent_input_output_real":matrix.real.tolist(),
                  "coherent_input_output_imag":matrix.imag.tolist(),
                  "worst_input_joint_success":float(singular.min()**2),
                  "mean_joint_success":weight/2,
                  "parity_transfer_fidelity_with_phase_alignment":
                      float((abs(matrix[0,0])+abs(matrix[1,1]))**2/(2*weight)) if weight>1e-24 else None}
        transfers.append(record)
        for j, parity in enumerate((1,-1)):
            np.testing.assert_allclose(abs(matrix[1,j])**2,
                                       reads[str(parity)][len(transfers)-1]["charge_at_destination_even_left_odd_right"],
                                       rtol=0,atol=1e-12)
    return {"board_cells":board.cells,"sign":q,"triangles":[f,g],"gateway":[a,b],"reflective_arms":sym,
            "heralded_ring_qubit_transfer":transfers,
            "dimension":len(h),"local_spectra_and_charge_records":reads}


def run():
    microscopic = check_transfers()
    records, transfers = [],[]
    for level in range(3):
        board = federation(level)
        triangles,rings,*_ = catalog(board)
        for r in (triangles[0],min(rings,key=lambda x:(len(x),x))):
            records.extend(loop_read(board,r,q) for q in (-1,1))
        for sym, fixture in joined_triangles(board):
            transfers.extend(release(board,fixture,sym,q) for q in (-1,1))
    return {"signed_full_contact_error":microscopic,"single_ring":records,"nested":nested(),
            "free_field_and_charge_release":transfers,"sha256":{
                str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest() for p in
                (HERE/"winding.py",ROOT/"interval_echo_vacuum_audit/repair/laplacian.py",
                 ROOT/"interval_echo_vacuum_audit/repair/results.json", ROOT/"interval_echo_gauge_loops/geometry.py")}}


if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--output",required=True,type=Path)
    output=cli.parse_args().output
    result=run()
    with output.open("x",encoding="utf-8") as f:
        json.dump(result,f,indent=2,allow_nan=False)
        f.write("\n")
