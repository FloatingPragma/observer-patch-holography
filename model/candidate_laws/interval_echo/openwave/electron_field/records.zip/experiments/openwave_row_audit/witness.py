"""Independent, integer Gauss-law enumeration for four static source pairs."""

from collections import Counter
import json
from itertools import product
from pathlib import Path

import networkx as nx
import numpy as np

HERE = Path(__file__).resolve().parent
POSITIONS = [(230, 302), (398, 586), (230, 586), (398, 302)]


def static_energy(rings, reference, plus, minus):
    directions = [[(a, b) for a, b in zip(r, r[1:] + r[:1])] for r in rings]
    edges = sorted({tuple(sorted((a, b))) for loop in directions for a, b in loop})
    graph = nx.Graph(edges)
    root = min(graph)
    tree = list(nx.bfs_edges(graph, root, sort_neighbors=sorted))
    chords = sorted(set(edges) - {tuple(sorted(edge)) for edge in tree})
    desired = Counter({plus: 1, minus: -1})
    for a, b in edges:
        desired[a] += reference[a, b]
        desired[b] -= reference[a, b]
    words = []
    for coins in product((0, 1), repeat=len(chords)):
        values = dict(zip(chords, coins))
        residual = desired.copy()
        for (a, b), bit in values.items():
            residual[a] -= bit
            residual[b] += bit
        for parent, child in reversed(tree):
            a, b = sorted((parent, child))
            value = residual[child] if child == a else -residual[child]
            if value not in (0, 1):
                break
            values[a, b] = value
            residual[parent] += residual[child]
        else:
            assert residual[root] == 0
            words.append(tuple(values[e] for e in edges))
    slots = {word: i for i, word in enumerate(words)}
    adjacency = np.zeros((len(words), len(words)), int)
    for i, word in enumerate(words):
        for loop in directions:
            sites = [edges.index(tuple(sorted(edge))) for edge in loop]
            signs = {word[k] == (a < b) for (a, b), k in zip(loop, sites)}
            if len(signs) == 1:
                flipped = list(word)
                for k in sites:
                    flipped[k] ^= 1
                adjacency[i, slots[tuple(flipped)]] = 1
    np.testing.assert_array_equal(adjacency, adjacency.T)
    energy = np.linalg.eigvalsh(-0.5 * adjacency)[0]
    return {"ports": [plus, minus], "dimension": len(words), "adjacency": adjacency.tolist(),
            "energy": float(energy)}


def main():
    source = json.loads((HERE.parent / "interval_echo_gauge_loops/results.json").read_text())
    fixture = source["boards"][-1]["fixtures"][2]
    reference = {(a, b): v for a, b, v in fixture["neutral_reference_links_and_lower_heads"]}
    results = [static_energy(fixture["rings"], reference, p, m) for p, m in POSITIONS]
    data = json.loads((HERE / "results.json").read_text())["guides"][-1]["static_sources"]
    rows = {(r["plus"], r["minus"]): r for r in data["static_pair_energies"]}
    distances = []
    for r in results:
        stored = rows[tuple(r["ports"])]
        assert r["dimension"] == stored["dimension"]
        np.testing.assert_allclose(r["energy"] - data["neutral_ground"], stored["ring_energy"], atol=1e-12)
        distances.append((stored["cell_distance"], stored["port_distance"]))
    assert sorted(distances[:2]) == sorted(distances[2:])
    difference = sum(r["energy"]*sign for sign, r in zip((1, 1, -1, -1), results))
    np.testing.assert_allclose(difference, (np.sqrt(5)-1)/4, atol=1e-12)
    print(json.dumps({"static_configurations": results, "graph_distances": distances,
                      "four_source_energy_difference": difference}, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
