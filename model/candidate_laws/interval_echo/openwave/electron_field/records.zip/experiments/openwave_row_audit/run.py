"""Regional charge reads and static Coulomb comparisons on archived flux guides."""

import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sys

import networkx as nx
import numpy as np
from scipy.linalg import expm

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "interval_echo_pair_threshold"))
from threshold import Guide, Instrument, federation, local_columns, pair_hamiltonian, physical_basis


def regional_flux(guide, word, cell):
    """Sum oriented heads on crossing links, without consulting the load registers."""
    result = 0
    for i, (a, b) in enumerate(guide.edges):
        crossing = int(a // 12 == cell) - int(b // 12 == cell)
        value = ((word >> i) & 1) - ((guide.ref_word >> i) & 1)
        result += crossing * value
    return result


def regional_split(guide, basis, instrument, q):
    pulse = expm(-1j * np.pi * instrument.h8 / 128)
    for p, m, word in sorted(basis):
        src, mate = (p, m) if q == 1 else (m, p)
        for dest in sorted(guide.graph[src]):
            if len({src // 12, mate // 12, dest // 12}) != 3:
                continue
            a, b = sorted((src, dest))
            link = 1 << guide.eid[a, b]
            coin = int(bool(word & link))
            pair = (1 + q, 1) if src == a else (1, 1 + q)
            local = np.kron(instrument.basis[:, coin], np.eye(9)[:, instrument.pairs.index(pair)])
            alternate = np.kron(instrument.basis[:, 1-coin], np.eye(9)[:, instrument.pairs.index(pair[::-1])])
            state = pulse @ local
            jumped = float(abs(alternate @ state)**2)
            if jumped < 1e-12:
                continue
            stayed = float(abs(local @ state)**2)
            np.testing.assert_allclose([stayed, jumped], [0.5, 0.5], atol=1e-12)
            outcomes = []
            for position, next_word, prob in [(src, word, stayed), (dest, word ^ link, jumped)]:
                plus, minus = (position, mate) if q == 1 else (mate, position)
                assert (plus, minus, next_word) in basis
                loads = [int(plus // 12 == cell) - int(minus // 12 == cell)
                         for cell in (src // 12, dest // 12)]
                fluxes = [regional_flux(guide, next_word, cell) for cell in (src // 12, dest // 12)]
                assert fluxes == loads and sorted(map(abs, loads)) == [0, 1]
                outcomes.append({"probability": prob, "regional_flux": fluxes, "regional_load": loads})
            # The control is a head-independent exchange of the two port loads.
            # On the transferred branch the nonzero charge is now in the wrong cell for this head word.
            assert outcomes[0]["regional_flux"] != outcomes[1]["regional_load"]
            return {"sign": q, "source": src, "receiving_port": dest, "compensator": mate,
                    "initial_head_word": word, "outcomes": outcomes,
                    "head_independent_exchange_probability_of_flux_mismatch": 0.5}
    raise ValueError("No eligible three-cell split")


def spatial_fit(observations, distance, reading, radial):
    """Eliminate both endpoint self-energies by allowing an independent constant per site and sign."""
    selected = [r for r in observations if r["cell_distance"] >= 2]
    positions_p = sorted({r["plus"] for r in selected})
    positions_m = sorted({r["minus"] for r in selected})
    radii = sorted({r[distance] for r in selected})
    size = len(positions_p) + len(positions_m)
    columns = len(radii) if radial else 1
    design = np.zeros((len(selected), size + columns))
    for i, row in enumerate(selected):
        design[i, positions_p.index(row["plus"])] = 1
        design[i, len(positions_p) + positions_m.index(row["minus"])] = 1
        if radial:
            design[i, size + radii.index(row[distance])] = 1
        else:
            design[i, size] = -1 / row[distance]
    values = np.array([r[reading] for r in selected])
    coefficients, _, rank, _ = np.linalg.lstsq(design, values, rcond=1e-12)
    residuals = values - design @ coefficients
    worst = int(np.argmax(np.abs(residuals)))
    observable_shape = int(rank - np.linalg.matrix_rank(design[:, :size], tol=1e-10))
    answer = {"observations": len(values), "radii": radii, "rank_beyond_site_terms": observable_shape,
              "residual_degrees_of_freedom": len(values) - int(rank),
              "max_absolute_residual": float(abs(residuals[worst])),
              "rms_residual": float(np.linalg.norm(residuals) / np.sqrt(len(values))),
              "worst_residual": {"plus": selected[worst]["plus"], "minus": selected[worst]["minus"],
                                 "distance": selected[worst][distance], "energy": float(values[worst]),
                                 "fitted_energy": float(values[worst] - residuals[worst])}}
    if not radial:
        answer["attractive_coefficient"] = float(coefficients[-1]) if observable_shape else None
        planted = np.array([0.013*r["plus"] - 0.007*r["minus"] - 0.6/r[distance] for r in selected])
        planted_coeff = np.linalg.lstsq(design, planted, rcond=1e-12)[0]
        planted_error = float(np.max(abs(planted - design @ planted_coeff)))
        assert planted_error < 1e-10
        if observable_shape:
            assert abs(planted_coeff[-1] - 0.6) < 1e-10
        answer["planted_law_residual"] = planted_error
    return answer


def static_pairs(guide, basis, instrument):
    source_groups = defaultdict(list)
    for i, (p, m, _) in enumerate(basis):
        source_groups[p, m].append(i)
    h, _ = pair_hamiltonian(guide, basis, local_columns(instrument))
    _, h0, _ = guide.sector(0, instrument)
    vacuum_energy = np.linalg.eigvalsh(h0)[0]
    cells = nx.Graph((a // 12, b // 12) for a, b in guide.board.external)
    ports = nx.Graph(guide.board.seams)
    cell_distance = {c: nx.single_source_shortest_path_length(cells, c) for c in {v // 12 for v in guide.vertices}}
    port_distance = {v: nx.single_source_shortest_path_length(ports, v) for v in guide.vertices}
    rows = []
    for (plus, minus), ids in sorted(source_groups.items()):
        block = h[ids][:, ids].toarray()
        energy = np.linalg.eigvalsh(block)[0]
        # Static source contact terms are entirely diagonal at fixed distinct positions.
        field = block.copy()
        np.fill_diagonal(field, 0)
        field_energy = np.linalg.eigvalsh(field)[0]
        rows.append({"plus": plus, "minus": minus, "dimension": len(ids),
                     "cell_distance": cell_distance[plus // 12][minus // 12], "port_distance": port_distance[plus][minus],
                     "ring_energy": float(field_energy - vacuum_energy),
                     "clamped_energy": float(energy - vacuum_energy)})
    fits = {}
    for metric in ("cell_distance", "port_distance"):
        fits[metric] = {energy: {kind: spatial_fit(rows, metric, energy, kind == "radial")
                                 for kind in ("inverse_distance", "radial")}
                        for energy in ("ring_energy", "clamped_energy")}
    return {"pairs": len(rows), "neutral_ground": float(vacuum_energy), "fits": fits, "static_pair_energies": rows}


def run():
    source = HERE.parent / "interval_echo_gauge_loops" / "results.json"
    packet = json.loads(source.read_text())
    instrument = Instrument()
    guides = []
    for level, board_data in enumerate(packet["boards"]):
        board = federation(level)
        for index, fixture in enumerate(board_data["fixtures"][:3]):
            guide = Guide(fixture, board, packet["loop_hopping"])
            basis = physical_basis(guide, exhaustive=(level == index == 0))
            state_set = set(basis)
            guides.append({"cells": board.cells, "loops": len(guide.rings), "dimension": len(basis),
                           "regional_splits": [regional_split(guide, state_set, instrument, q) for q in (1, -1)],
                           "static_sources": static_pairs(guide, basis, instrument)})
    return {"candidate_commit": packet["candidate_revision"],
            "geometry_source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
            "guides": guides}


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--output", required=True, type=Path)
    args = cli.parse_args()
    results = run()
    with args.output.open("x") as out:
        json.dump(results, out, separators=(",", ":"), allow_nan=False)
        out.write("\n")
