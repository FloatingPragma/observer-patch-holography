"""Native signed-source intervention, independent detector trials and field-only controls."""

from collections import Counter

import numpy as np
from scipy.sparse.linalg import expm_multiply
import networkx as nx

from geometry import edge
from oracle import local_matrices


def instruments(instrument,source,detector,arms):
    """Check all physical source, evacuation and detector paths locally on the established Kraus instrument."""
    tables = local_matrices(instrument)
    reference={}
    def set_near_head(a,b,near):
        e=edge(a,b)
        assert e not in reference
        reference[e]=int(near if a<b else not near)
    for (label,sign),(v,r,m) in arms.items():
        if label=="outlet":
            set_near_head(v,r,sign==1)
        else:
            set_near_head(r,v,sign==1)
            set_near_head(r,m,sign==-1)
    def move(load,delta,a,b,q):
        assert load[a]==q and load[b]==0
        current=reference[edge(a,b)]+delta[edge(a,b)]
        assert ((current==1) if a<b else (current==0))==(q==1)
        load[a]-=q
        load[b]+=q
        delta[edge(a,b)]+= -q if a<b else q
    def balance(load,delta):
        observed = Counter()
        for (a,b),c in delta.items():
            assert reference[a,b]+c in (0,1)
            observed[a]+=c
            observed[b]-=c
        assert observed==load
    for q in (-1,0,1):
        for start_coin in (0,1):
            reference[source]=start_coin
            src_load,src_flux = Counter(),Counter()
            if q:
                a,b=source
                v,r,m=arms["source",q]
                assert a==v and m is not None
                src_load[r],src_load[m]=q,-q
                src_flux[edge(r,m)]=q if r<m else -q
                balance(src_load,src_flux)
                move(src_load,src_flux,r,a,q)
                balance(src_load,src_flux)
                hopped=abs(tables[q][1][1-start_coin,start_coin])>.5
                assert hopped==(start_coin==int(q==1))
                if hopped:
                    move(src_load,src_flux,a,b,q)
                    move(src_load,src_flux,b,arms["outlet",q][1],q)
                else:
                    move(src_load,src_flux,a,r,q)
            balance(src_load,src_flux)
            assert all(v//12==source[0]//12 for v,n in src_load.items() if n)
            assert not any(src_load[v] for v in source+detector)
            for p in (-1,1):
                a,b=detector
                v,r,m=arms["probe",p]
                assert a==v and m is not None
                for coin in (0,1):
                    reference[detector]=coin
                    load,flux=src_load.copy(),src_flux.copy()
                    load[r],load[m]=p,-p
                    flux[edge(r,m)]=p if r<m else -p
                    balance(load,flux)
                    move(load,flux,r,a,p)
                    effect=instrument.detector(p)[coin,coin].real
                    if effect>.5:
                        move(load,flux,a,b,p)
                    assert abs(effect-int(coin==int(p==1)))<1e-13
                    balance(load,flux)


def flight(sector,times,cut=()):
    h=sector.h if not cut else sector.hamiltonian(cut)
    sharp=np.zeros(len(sector.words))
    sharp[0]=1
    wave=expm_multiply(-1j*h,sharp,start=times[0],stop=times[-1],num=len(times))
    weight=abs(wave)**2
    np.testing.assert_allclose(weight.sum(axis=1),1,rtol=0,atol=2e-11)
    return weight@sector.flipped


def direct_trials(sphere,sector,instrument,f,g,times):
    """Forward and reciprocal native interventions from every state of the stationary mixture.

    Evolve each two-time source outcome with its actual microscopic Hamiltonian (a flipped
    private source head disables only that face). The receiver reads all terminal probabilities.
    """
    from scipy.linalg import eigh
    full=sector.h.toarray()
    roots=(sphere.source,sphere.detectors[g])
    def run(src,dest,src_edge,dest_edge,arms):
        instruments(instrument,src_edge,dest_edge,arms)
        reset=sector.hamiltonian([src]).toarray()
        basis=[]
        for h in (full,reset):
            e,v=eigh(h)
            basis.append((e,v))
        source_coin=np.logical_xor(sphere.head[src_edge],sector.flipped[:,src]).astype(int)
        final_coin=np.logical_xor(sphere.head[dest_edge],sector.flipped[:,dest]).astype(int)
        native=local_matrices(instrument)
        results=[]
        for t in times:
            probs=[abs((v*np.exp(-1j*t*e))@v.T)**2 for e,v in basis]
            crossings=[]
            for q in (-1,0,1):
                clicked=(np.array([abs(native[q][1][1-c,c])**2 for c in source_coin]) if q else
                         np.zeros(len(source_coin)))
                mass=(probs[0]@(1-clicked)+probs[1]@clicked)/len(source_coin)
                np.testing.assert_allclose(mass.sum(),1,atol=1e-12)
                row = [float(mass@np.diag(instrument.detector(p)).real[final_coin]) for p in (1,-1)]
                crossings.append(row)
            results.append(crossings)
        return np.array(results)
    forward=run(f,g,*roots,sphere.arms[g])
    new=sphere.reverse_station(g)
    assert new is not None
    backward=run(g,f,*new)
    np.testing.assert_allclose(forward-forward[:,1:2],backward-backward[:,1:2],atol=1e-12,rtol=0)
    return forward,backward


def measure(sphere,sector,instrument):
    times=np.arange(2*sphere.n+1,dtype=float)
    signal=flight(sector,times)
    count=len(sector.words)
    sham=[]
    direction=[]
    stations=[]
    distances=nx.single_source_shortest_path_length(sphere.cells,sphere.source[0]//12)
    for i,d in enumerate(sphere.detectors):
        instruments(instrument,sphere.source,d,sphere.arms[i])
        c=sphere.head[d]
        baseline=float(np.mean(np.logical_xor(c,sector.flipped[:,i])))
        sign=(1-2*sphere.head[sphere.source])*(1-2*c)
        shifts=sign*signal[:,i]/count
        # Opposite probe readings are complementary; this detector matrix was checked in all 99 states.
        assert max(abs(shifts))>1e-14
        passing=np.flatnonzero(signal[:,i]>=.05)
        best=int(np.argmax(signal[:,i]))
        row={"face":i,"detector":d,"cell_distance":distances[d[0]//12],"face_distance":sphere.graph_distance[i],
             "minimum_loop_flips":len(sphere.closure[i]),"earliest_probability_power":2*len(sphere.closure[i]),
             "neutral_positive_probe":baseline,"positive_source_shift_sign":sign,
             "first_sample_with_five_percent_of_bound":int(passing[0]) if len(passing) else None,
             "peak_sample_time":best,"peak_absolute_positive_probe_shift":float(abs(shifts[best])),
             "excess_positive_probe_at_peak":float(baseline+shifts[best]),
             "vacancy_positive_probe_at_peak":float(baseline-shifts[best]),"reservoir_ports":{
                 f"{label},{q}":list(arm) for (label,q),arm in sphere.arms[i].items()}}
        held=sorted({0,4,8,16,32,sphere.n,2*sphere.n})
        row["held_time_excess_positive_probe"]=[[int(t),float(baseline+shifts[t])] for t in held]
        stations.append(row)
        direction.append(sign)
        sham.append(baseline)

    # Fixed graph selections, independent of the field readings. The two fronts have incomparable
    # ancestor sets and lie in different cells. Freezing one mandatory face makes its entire
    # downstream cone unavailable; the other front can still propagate.
    pairs=[(i,j) for i in range(1,sphere.n) for j in range(i+1,sphere.n)
           if i not in sphere.closure[j] and j not in sphere.closure[i]
           and sphere.detectors[i][0]//12!=sphere.detectors[j][0]//12]
    i,j=min(pairs,key=lambda pair:(max(len(sphere.closure[p]) for p in pair),sum(len(sphere.closure[p]) for p in pair),pair))
    cuts=[]
    for cut,other in ((i,j),(j,i)):
        result=flight(sector,times,[cut])
        downstream=[f for f in range(sphere.n) if cut in sphere.closure[f]]
        zero=float(np.max(abs(result[:,downstream])))
        assert zero<1e-13 and np.max(result[:,other])>.05
        cuts.append({"disabled_face":cut,"disabled_front_cell":sphere.detectors[cut][0]//12,
                     "other_front_face":other,"other_front_cell":sphere.detectors[other][0]//12,
                     "faces_in_cut_cone":len(downstream),"max_cut_cone_shift":zero/count,
                     "other_front_peak_absolute_shift":float(np.max(result[:,other])/count)})
    rootcut=flight(sector,np.array([0.,4.]),[0])
    native=flight(sector,np.array([0.,4.]),list(range(sphere.n)))
    assert np.max(abs(rootcut))==0
    assert np.max(abs(native))==0
    # Every loop has integer zero divergence. The integral of the signal flux through the
    # boundary of EVERY cell must vanish during the field-only wait. Link flips are XORs of
    # incident face occupations; comparable faces cannot be in reversed ordering.
    by_edge={}
    from geometry import segments,edge
    for f,r in enumerate(sphere.faces):
        for a,b in segments(r):
            e=edge(a,b)
            if a//12!=b//12:
                by_edge.setdefault(e,[]).append(f)
    fluxes=[]
    boundary=np.zeros((len(times),sphere.board.cells))
    for (a,b),(left,right) in sorted(by_edge.items()):
        assert left<right and left in sphere.closure[right]
        # E in the empty configuration is 0 relative to the background; in the evolving sharp
        # component it is (1-2c0) times the difference of comparable face predicates.
        flux=(1-2*sphere.head[sphere.source])*(1-2*sphere.head[a,b])*(signal[:,left]-signal[:,right])/count
        boundary[:,a//12]+=flux
        boundary[:,b//12]-=flux
        fluxes.append(float(max(abs(flux))))
    residual=float(np.max(abs(boundary)))
    assert residual<1e-12
    reciprocal=None
    if count<=100:
        # Mid-network station; actual native apparatus must exist at both ends.
        options=sorted((g for g in range(1,sphere.n) if sphere.reverse_station(g) is not None),
                       key=lambda g:(abs(sphere.graph_distance[g]-max(sphere.graph_distance)//2),g))
        g=options[0]
        held=[0.,4.,16.,32.,float(sphere.n)]
        fw,bw=direct_trials(sphere,sector,instrument,0,g,held)
        analytic=np.array([sham[g]+direction[g]*signal[int(t),g]/count for t in held])
        np.testing.assert_allclose(fw[:,2,0],analytic,atol=1e-12,rtol=0)
        reciprocal={"face":g,"held_times":held,"forward_all_readings":fw.tolist(),"reciprocal_all_readings":bw.tolist(),
                    "source_order":[-1,0,1],"probe_order":[1,-1],"signed_reciprocal_residual":
                    float(np.max(abs((fw-fw[:,1:2])-(bw-bw[:,1:2]))))}
    absolute=signal/count
    far=max(x["cell_distance"] for x in stations)
    farthest=min((x for x in stations if x["cell_distance"]==far),key=lambda x:x["face"])
    early=int(np.argmax(np.max(absolute[:,1:],axis=1)))
    return {"times_sampled":{"start":0,"stop":int(times[-1]),"step":1},
            "source":sphere.source,"state_count":count,"field_matrix_nonzeros":int(sector.h.nnz),
            "upper_bound_on_absolute_shift":1/count,"all_cell_boundary_flux_residual":residual,
            "largest_external_seam_flux_shift":max(fluxes),"maximum_material_transport_outside_source_cell_before_probe":0,
            "source_closed_shift":0,"all_cross_face_terms_cut_shift":float(np.max(abs(native))),"root_face_disabled_max_shift":float(np.max(rootcut)),
            "faces_reaching_sample_threshold":sum(x["first_sample_with_five_percent_of_bound"] is not None for x in stations),
            "max_cell_distance":far,"representative_farthest_face":farthest["face"],
            "maximum_above_threshold_cell_distance":max(r["cell_distance"] for r in stations if r["first_sample_with_five_percent_of_bound"] is not None),
            "largest_observed_remote_probe_shift":float(np.max(absolute[early,1:])),"time_of_largest_remote_shift":early,
            "selective_cuts":cuts,"independent_source_detector_swap":reciprocal,"station_records":stations}
