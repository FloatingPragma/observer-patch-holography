"""Whole-sphere stationary flux sectors with every cross-cell face enabled."""

from collections import Counter

import networkx as nx
import numpy as np
from scipy import sparse

from geometry import catalog, edge, segments, stations, support


class Sphere:
    def __init__(self, board, order):
        self.board = board
        self.triangles, rings, self.cells, self.inventory = catalog(board)
        overlaps = nx.Graph()
        overlaps.add_nodes_from(range(len(rings)))
        edges = [support(r) for r in rings]
        for i, left in enumerate(edges):
            for j in range(i):
                shared = left & edges[j]
                if shared:
                    direction = {((a,b) in segments(rings[i])) == ((a,b) in segments(rings[j])) for a,b in shared}
                    assert len(direction) == 1
                    overlaps.add_edge(i,j,reverse=direction.pop())
        # Give neighbouring spherical faces opposite traversal on every shared seam.
        reverse = {0:False}
        for i,j in nx.bfs_edges(overlaps,0):
            reverse[j] = reverse[i] ^ overlaps[i][j]["reverse"]
        assert all((reverse[i]^reverse[j])==v["reverse"] for i,j,v in overlaps.edges(data=True))
        dist = nx.single_source_shortest_path_length(overlaps,0)
        if order == "address within shell":
            sequence = sorted(overlaps,key=lambda i:(dist[i],i))
        elif order == "depth-first within shell":
            sequence = []
            for k in range(max(dist.values())+1):
                shell = overlaps.subgraph(i for i in overlaps if dist[i]==k)
                for component in sorted(nx.connected_components(shell), key=min):
                    sequence.extend(nx.dfs_preorder_nodes(shell.subgraph(component),min(component),sort_neighbors=sorted))
        else:
            raise ValueError(order)
        rank = {i:k for k,i in enumerate(sequence)}
        self.faces = [tuple(reversed(rings[i])) if reverse[i] else rings[i] for i in sequence]
        self.neighbours = [sorted(rank[j] for j in overlaps[i]) for i in sequence]
        self.graph_distance = [dist[i] for i in sequence]
        self.parents = [[j for j in ns if j<i] for i,ns in enumerate(self.neighbours)]
        assert all(self.parents[i] for i in range(1,len(self.faces)))
        self.closure = []
        for i,parents in enumerate(self.parents):
            self.closure.append(set.union({i},*(self.closure[j] for j in parents)))

        self.head = {}
        frequency = Counter(e for r in self.faces for e in support(r))
        for r in self.faces:
            for a,b in segments(r):
                self.head.setdefault(edge(a,b),int(a<b))
        self.core = {v for e in self.head for v in e}
        assert all(n in (1,2) for n in frequency.values())
        assert all(e in self.head for e in board.seams if set(e)<=self.core)
        assert all(not set(t)<=self.core for t in self.triangles)
        private = [sorted(e for e in support(r) if frequency[e]==1) for r in self.faces]
        assert min(map(len,private))>=2   # a flipped source edge blocks its face throughout flight
        self.source = private[0][0]
        self.detectors = []
        self.arms = []
        for options in private:
            for dest in options:
                if self.source[0]//12 == dest[0]//12:
                    continue
                reserve = stations(board,self.faces,self.source,dest)
                if reserve is not None:
                    self.detectors.append(dest)
                    self.arms.append(reserve)
                    break
            else:
                raise ValueError("Face has no independent registered detector.")
        # Outside the core a single vertex potential orients all links. Any triangle has
        # an external vertex of strictly highest potential, so its two heads cannot circulate.
        # Reservoir ports are isolated during flight. These are all outside the core.
        self.isolated_triangle_counts=[]
        for arms in self.arms:
            parked = {x for v,r,m in arms.values() for x in (r,m) if x is not None}
            assert not self.core & parked
            assert not any(parked & set(face) for face in self.faces)
            self.isolated_triangle_counts.append(sum(bool(parked&set(t)) for t in self.triangles))
        self.n = len(self.faces)

    def exterior_check(self):
        def potential(v):
            return 0 if v in self.core else v+1
        for t in self.triangles:
            high = max(t,key=potential)
            assert high not in self.core
            assert all(potential(v)<potential(high) and edge(high,v) not in self.head for v in t if v!=high)
        return {"triangle_flux_blocked_by_fixed_exterior_heads":len(self.triangles),
                "chords_between_core_vertices_outside_face_catalog":0,
                "triangles_touching_isolated_local_reservoirs_min_max":
                [min(self.isolated_triangle_counts),max(self.isolated_triangle_counts)],
                "unmasked_cross_cell_faces":self.n,"core_ports":len(self.core),"face_seams":len(self.head)}

    def reverse_station(self,dest_face):
        src,dest = self.detectors[dest_face],self.source
        arms = stations(self.board,self.faces,src,dest)
        return None if arms is None else (src,dest,arms)


class Sector:
    """Reachable binary loop flips are exactly the downward-closed subsets of the face order."""
    def __init__(self,sphere):
        n = sphere.n
        prev = [sum(1<<j for j in ps) for ps in sphere.parents]
        following = [sum(1<<j for j in sphere.neighbours[i] if i<j) for i in range(n)]
        words=[]
        def expand(i,w):
            if i==n:
                words.append(w)
            else:
                expand(i+1,w)
                if prev[i]&w==prev[i]:
                    expand(i+1,w|(1<<i))
        expand(0,0)
        self.words = words
        self.flipped = np.array([[bool(w&(1<<i)) for i in range(n)] for w in words])
        ids = {w:i for i,w in enumerate(words)}
        src,dst,face_tag=[],[],[]
        for j,w in enumerate(words):
            for i in range(n):
                if not w&(1<<i) and prev[i]&w==prev[i]:
                    k = ids[w|(1<<i)]
                    assert (words[k]&following[i])==0
                    src.extend((j,k))
                    dst.extend((k,j))
                    face_tag.extend((i,i))
        self.src,self.dst,self.face_tag = map(np.asarray,(src,dst,face_tag))
        self.h = self.hamiltonian()
        assert self.flipped[:,0].sum()==len(words)-1 and words[0]==0

    def hamiltonian(self,cut=()):
        take = ~np.isin(self.face_tag,cut)
        return sparse.csr_matrix((-0.5*np.ones(np.count_nonzero(take)),(self.src[take],self.dst[take])),shape=(len(self.words),)*2)

    def verify_native_moves(self,sphere):
        """Independently apply circulation selection to packed physical seam words, including blocked faces."""
        bit = {e:1<<i for i,e in enumerate(sorted(sphere.head))}
        base = sum(bit[e]*x for e,x in sphere.head.items())
        masks = [sum(bit[e] for e in support(r)) for r in sphere.faces]
        forward = [sum(bit[edge(a,b)] for a,b in segments(r) if a<b) for r in sphere.faces]
        for r in sphere.faces:
            d=Counter()
            for a,b in segments(r):
                d[a]+=1
                d[b]-=1
            assert all(x==0 for x in d.values())
        idx={w:i for i,w in enumerate(self.words)}
        for i,w in enumerate(self.words):
            word=base
            for j in np.flatnonzero(self.flipped[i]):
                word ^= masks[j]
            targets = [idx[w^(1<<j)] for j,(m,f) in enumerate(zip(masks,forward)) if word&m in (f,m^f)]
            assert sorted(targets)==self.h.indices[self.h.indptr[i]:self.h.indptr[i+1]].tolist()
            # When the signed emitter moves, exactly its private edge reverses in the core.
            # Check the flux word produced by that intervention, including every blocked face.
            moved = word^bit[sphere.source]
            targets_after = [idx[w^(1<<j)] for j,(m,f) in enumerate(zip(masks,forward)) if moved&m in (f,m^f)]
            assert sorted(targets_after)==sorted(k for k in targets if self.words[k]^w!=1)
        return int(self.h.nnz)
