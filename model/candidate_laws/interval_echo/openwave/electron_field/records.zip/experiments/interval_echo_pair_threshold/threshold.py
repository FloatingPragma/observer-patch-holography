"""Two mobile, oppositely charged loads above the identical written neutral field."""
import argparse
import hashlib
import json
from itertools import permutations
from pathlib import Path
import sys

import networkx as nx
import numpy as np
from scipy import sparse
from scipy.linalg import eigh
from scipy.sparse.csgraph import connected_components
from scipy.sparse.linalg import eigsh, expm_multiply

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "interval_echo_rest_mass"))
from run import Guide, Instrument, federation
from current_algebra import candidate, exact_seam


def lowest(h):
    """Return the normalized bottom mode of a real symmetric sparse matrix."""
    if h.shape[0] <= 180:
        values, modes = eigh(h.toarray(), subset_by_index=[0, 0])
    else:
        values, modes = eigsh(h, k=1, which="SA", v0=np.ones(h.shape[0]), tol=1e-12)
    energy, state = float(values[0]), modes[:, 0]
    residual = float(np.linalg.norm(h @ state - energy * state))
    assert residual < 2e-8
    return energy, state


def local_columns(inst):
    """Every even-|d|=1 head/load input, including adjacent opposite defects."""
    embed = np.kron(inst.basis, np.eye(9))
    relative = inst.h8 / 8 - 8 * np.eye(99)
    reduced = np.rint(embed.T @ relative @ embed).astype(int)
    np.testing.assert_allclose(relative @ embed, embed @ reduced, atol=2e-13)
    transitions = {}
    for coin in (0, 1):
        for pair_index, pair in enumerate(inst.pairs):
            col = reduced[:, 9*coin + pair_index]
            outputs = []
            for i in np.flatnonzero(col):
                next_coin, next_pair_index = divmod(int(i), 9)
                next_pair = inst.pairs[next_pair_index]
                assert sum(pair) == sum(next_pair)
                assert pair[0]-coin == next_pair[0]-next_coin
                outputs.append((next_coin, next_pair, int(col[i])))
            transitions[(coin, tuple(pair))] = outputs
    assert all(transitions[c, (2, 0)] == transitions[c, (0, 2)] == [] for c in (0, 1))
    return transitions


def physical_basis(guide, exhaustive):
    """Solve Gauss at every vertex for a +1,-1 pair. No frozen charge remains."""
    base = guide.ref_div[1:, None] - guide.incidence[1:, guide.chords] @ guide.chord_values
    basis = []
    for plus, minus in permutations(guide.vertices, 2):
        rho = np.zeros(len(guide.vertices), int)
        rho[guide.vid[plus]], rho[guide.vid[minus]] = 1, -1
        tree = guide.inverse @ (base + rho[1:, None])
        for j in np.flatnonzero(np.all((tree == 0) | (tree == 1), axis=0)):
            heads = np.zeros(len(guide.edges), int)
            heads[guide.tree], heads[guide.chords] = tree[:, j], guide.chord_values[:, j]
            np.testing.assert_array_equal(guide.incidence @ heads - guide.ref_div, rho)
            word = sum(1 << i for i in np.flatnonzero(heads).tolist())
            basis.append((plus, minus, word))
    assert len(basis) == len(set(basis))
    if exhaustive:
        words = np.arange(1 << len(guide.edges), dtype=np.int64)
        bits = (words[None, :] >> np.arange(len(guide.edges))[:, None]) & 1
        charge = guide.incidence @ bits - guide.ref_div[:, None]
        allowed = np.flatnonzero((np.sum(charge == 1, axis=0) == 1) &
                                 (np.sum(charge == -1, axis=0) == 1) &
                                 (np.count_nonzero(charge, axis=0) == 2))
        brute = {(guide.vertices[np.argmax(charge[:, i])],
                  guide.vertices[np.argmin(charge[:, i])], int(i)) for i in allowed}
        assert set(basis) == brute
    return basis


def pair_hamiltonian(guide, basis, local):
    ids = {state:i for i,state in enumerate(basis)}
    incident = {v:{guide.eid[tuple(sorted((v,n)))] for n in guide.graph[v]}
                for v in guide.vertices}
    row, col, data = [], [], []
    for j, (p, m, w) in enumerate(basis):
        diag = 8 * (3 * (6-guide.board.degree[p]) - (6-guide.board.degree[m]))
        loads = {p:2, m:0}
        for link in sorted(incident[p] | incident[m]):
            a, b = guide.edges[link]
            bit = 1 << link
            coin = int(bool(w & bit))
            pair = (loads.get(a, 1), loads.get(b, 1))
            for head, new_pair, element in local[coin, pair]:
                if head == coin:
                    assert new_pair == pair
                    diag += element
                else:
                    assert new_pair == pair[::-1] and 1 in pair
                    updated = (b if p == a else a if p == b else p,
                               b if m == a else a if m == b else m, w ^ bit)
                    row.append(ids[updated])
                    col.append(j)
                    data.append(element)
        for mask, direction in guide.rings:
            if w & mask in (direction, mask ^ direction):
                row.append(ids[p, m, w ^ mask])
                col.append(j)
                data.append(-guide.J)
        row.append(j)
        col.append(j)
        data.append(diag)
    h = sparse.coo_matrix((data, (row, col)), shape=(len(basis), len(basis))).tocsr()
    h.eliminate_zeros()
    assert (h != h.T).nnz == 0
    return h, ids


def spectroscopy(h, v, separations, e0):
    """Signed Bohr frequencies and oscillator strengths for a weak external local pair source."""
    energies, modes = eigh(h.toarray())
    weights = abs(modes.T @ v)**2
    starts = np.r_[0, 1+np.flatnonzero(np.diff(energies) > 1e-9)]
    lines = []
    for i, j in zip(starts, np.r_[starts[1:], len(energies)]):
        projection = modes[:, i:j] @ (modes[:, i:j].T @ v)
        weight = float(projection @ projection)
        if weight > 1e-13:
            lines.append({"omega":float(energies[i]-e0),"source_weight":weight,
                          "cross_cell_weight_in_line":float(projection[separations>=1] @ projection[separations>=1] / weight)})
    assert abs(sum(x["source_weight"] for x in lines)-1)<1e-10
    positive = [x for x in lines if x["omega"]>1e-9]
    return {"line_weight_floor":1e-13,"bright_lines":len(lines),"bottom_bright_line":lines[0],
            "first_bright_absorption_line":positive[0] if positive else None,
            "negative_frequency_weight":float(weights[energies<e0-1e-9].sum()),
            "positive_frequency_weight":float(weights[energies>e0+1e-9].sum())}


def test_guide(fixture, board, J, inst, local, exhaustive):
    guide = Guide(fixture, board, J)
    basis = physical_basis(guide, exhaustive)
    h, ids = pair_hamiltonian(guide, basis, local)
    empty_states, empty_h, full_empty = guide.sector(0, inst)
    energy, mode = eigh(empty_h, subset_by_index=[0, 0])
    e0 = float(energy[0])
    vacuum = mode[:, 0] * np.sign(np.sum(mode[:, 0]))
    assert np.all(vacuum > 0)
    assert full_empty == len(vacuum), "The selected vacuum must cover every neutral state"
    a, b = fixture["source_seam"]
    link = 1 << guide.eid[a, b]
    seed = np.zeros(len(basis))
    partners = []
    for (_, w), amp in zip(empty_states, vacuum):
        plus, minus = (b, a) if w & link else (a, b)
        partner = ids[plus, minus, w ^ link]
        partners.append(partner)
        seed[partner] = amp
    np.testing.assert_allclose(seed @ seed, 1, atol=1e-13)
    labels = connected_components(h, directed=False)[1]
    reachable = np.isin(labels, np.unique(labels[seed != 0]))
    reach_ids = np.flatnonzero(reachable)
    hr = h[reach_ids][:,reach_ids]
    sr = seed[reachable]
    pair_energy, _ = lowest(h)
    source_energy, gs = lowest(hr)
    # The field fixture specifies a stored graph distance in cell steps, defined before opening contacts.
    cell_graph = nx.Graph((i//12, j//12) for i,j in board.external)
    distances = dict(nx.all_pairs_shortest_path_length(cell_graph))
    gaps = np.array([distances[p//12][m//12] for p,m,w in basis])
    d = gaps[reachable]
    floor = []
    for k in range(int(gaps.max()) + 1):
        ids_r = np.flatnonzero(d >= k)
        active_dim = int(np.count_nonzero(gaps >= k))
        if len(ids_r):
            bottom, _ = lowest(hr[ids_r][:,ids_r])
            floor.append({"minimum_cell_distance":k,"eligible_source_connected_dimension":len(ids_r),
                          "total_eligible_dimension":active_dim,
                          "minimum_pair_energy_minus_prepared_vacuum":float(bottom-e0),
                          "probability_in_unconstrained_source_connected_ground":float(gs[ids_r] @ gs[ids_r])})
    assert np.all(np.diff([x["minimum_pair_energy_minus_prepared_vacuum"] for x in floor])>=-1e-9)
    held_times = (0., 1., 2., 4., 8., 16.)
    waves = expm_multiply(-1j*hr, sr, start=0., stop=16., num=17)
    flight = []
    for t in held_times:
        probability = abs(waves[int(t)])**2
        np.testing.assert_allclose(probability.sum(), 1, atol=2e-11)
        flight.append({"time":t,"probability_by_cell_distance":np.bincount(d, weights=probability).tolist()})
    assert np.max([sum(s["probability_by_cell_distance"][1:]) for s in flight]) > 1e-7
    mu = 1.25
    shifted = expm_multiply(-1j*2*(hr+2*mu*sparse.eye(len(sr), format="csr")), sr)
    np.testing.assert_allclose(shifted, np.exp(-4j*mu)*waves[2], atol=2e-11)
    # A pi/4 external pulse and its inverse retain a vacuum arm that can read a sector phase.
    # The final measurement accepts every uniform-load head word, so it is a material read.
    partner_ids = np.searchsorted(reach_ids, partners)
    np.testing.assert_array_equal(reach_ids[partner_ids], partners)
    ramsey = []
    for t in (1., 2., 4., 8.):
        unexcited = np.exp(-1j*t*e0)*vacuum
        returned = waves[int(t),partner_ids]
        ramsey.append({"time":t,
                       "nominal_uniform_load_probability":float(np.linalg.norm((unexcited+returned)/2)**2),
                       "mu_shifted_uniform_load_probability":float(np.linalg.norm((unexcited+np.exp(-2j*mu*t)*returned)/2)**2)})
    assert max(abs(r["nominal_uniform_load_probability"]-r["mu_shifted_uniform_load_probability"]) for r in ramsey)>1e-4
    row = {"cells":board.cells,"loops":len(guide.rings),"ports":len(guide.vertices),"active_links":len(guide.edges),
           "neutral_dimension":len(vacuum),"neutral_ground_energy":e0,
           "written_neutral_preparation_above_field_off_uniform_medium":float(8*len(guide.edges)+e0),
           "written_pair_ground_above_field_off_uniform_medium":float(8*len(guide.edges)+pair_energy),
           "pair_dimension":len(basis),"source_connected_dimension":len(sr),
           "lowest_pair_energy_minus_prepared_vacuum":float(pair_energy-e0),
           "lowest_source_connected_pair_energy_minus_prepared_vacuum":float(source_energy-e0),
           "ground_overlap_with_external_adjacent_pair_source":float(abs(gs@sr)**2),
           "separation_restricted_variational_floors":floor,"externally_pulsed_flight":flight,
           "mu_K_test":{"mu":mu,"signed_pair_frequency_shift":2*mu,
                        "max_position_and_head_probability_difference":float(np.max(abs(abs(shifted)**2-abs(waves[2])**2))),
                        "external_cross_sector_Ramsey":ramsey}}
    if exhaustive:
        row["brute_register_words_checked"] = 1 << len(guide.edges)
        row["spectroscopy"] = spectroscopy(hr, sr, d, e0)
    return row


def source_audit(inst):
    law = candidate.native_law
    allowed = [(coin, pair) for coin in (0,1) for pair in inst.pairs]
    op = np.zeros((18,18))
    for c in (0,1):
        p = (2,0) if c==0 else (0,2)
        i, j = allowed.index((c,(1,1))), allowed.index((1-c,p))
        op[i,j] = op[j,i] = 1.
    charges = [a+b-2 for c,(a,b) in allowed]
    costs = [(a-1)**2+(b-1)**2 for c,(a,b) in allowed]
    gauss = [a-c for c,(a,b) in allowed]
    def commutator(x,h):
        return (np.asarray(x)[:,None]-x)*h
    assert not np.any(commutator(charges, op)) and not np.any(commutator(gauss, op))
    assert np.max(abs(commutator(costs, op))) == 2
    # The neutral-field energy prices for the guarded extension use the absolute memory energies.
    labels = [None, *law.LABELS]
    inactive = [i for i,v in enumerate(labels) if v is None or v[1]==0]
    written = [i for i,v in enumerate(labels) if v is not None and abs(v[1])==1]
    np.testing.assert_array_equal(inst.blocks[1][:,inactive],0.)
    np.testing.assert_allclose(np.linalg.eigvalsh(inst.blocks[1][np.ix_(written,written)]),[8,8,9,9])
    # Verify native stored fuel emission in the full seam including all labels.
    echo = law.echo()
    fuel = np.zeros(11)
    for c in (0,1):
        fuel[1+law.LABELS.index((c,2))] = 1/np.sqrt(2)
    start = np.kron(fuel, np.eye(9)[:,inst.pairs.index((1,1))])
    target = np.eye(99)[:,inst.pairs.index((2,0))]
    np.testing.assert_allclose(echo @ start, target, atol=1e-13)
    k = np.tile([(a-1)**2+(b-1)**2 for a,b in inst.pairs],11)
    k += np.repeat([0]+[2*int(abs(v)==2) for _,v in law.LABELS],9)
    zero, pair = np.flatnonzero(k==0), np.flatnonzero(k==2)
    assert not np.any(inst.h8[np.ix_(pair,zero)])
    _, echo_support = exact_seam()
    assert not np.any(echo_support[np.ix_(pair,zero)])
    return {"native_free_off_block_norm_K0_to_K2":0,"native_echo_off_block_norm_K0_to_K2":0,
            "stored_double_contrast_to_blank_adjacent_pair_fidelity":float(abs(target @ echo @ start)**2),
            "fuel_input_K":2,"fuel_output_K":2,"hypothetical_written_pair_pulse_Q_commutator":0,
            "hypothetical_written_pair_pulse_endpoint_Gauss_commutator":0,"hypothetical_written_pair_pulse_K_commutator_max":2}


def run():
    previous = HERE.parent/"interval_echo_gauge_loops"/"results.json"
    receipt = json.loads(previous.read_text())
    inst = Instrument()
    local = local_columns(inst)
    rows = [test_guide(f, federation(level), receipt["loop_hopping"], inst, local, level==0 and index==0)
            for level, data in enumerate(receipt["boards"]) for index,f in enumerate(data["fixtures"][:3])]
    return {"candidate_commit":receipt["candidate_revision"],"gauge_receipt_sha256":hashlib.sha256(previous.read_bytes()).hexdigest(),
            "code_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"source":source_audit(inst),"guides":rows}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    content = json.dumps(run(), indent=2, allow_nan=False)+"\n"
    with args.output.open("x", encoding="utf-8") as file:
        file.write(content)
