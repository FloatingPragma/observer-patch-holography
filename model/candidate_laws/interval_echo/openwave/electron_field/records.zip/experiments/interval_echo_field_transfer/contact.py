"""Native source, parking operation, detector and vacuum-sector certificates."""

import numpy as np
from scipy.linalg import expm

from current_algebra import candidate, exact_seam


class Instrument:
    def __init__(self):
        law = candidate.native_law
        self.h8, echo_support = exact_seam()
        self.pairs = law.SRC
        basis = np.zeros((11,2))
        for coin in (0,1):
            for d in (-1,1):
                basis[1+law.LABELS.index((coin,d)),coin] = 1/np.sqrt(2)
        self.basis = basis
        self.ready = np.ones(2)/np.sqrt(2)
        self.full = expm(-1j*np.pi/8*(self.h8/8))
        self.blank_swap = expm(-1j*np.pi*self.h8[:9,:9]/8)

        # Complete matrix support checks. K counts singly exceptional loads and costs two for |d|=2.
        charge = np.tile([a+b-2 for a,b in self.pairs],11)
        cost = np.tile([(a-1)**2+(b-1)**2 for a,b in self.pairs],11)
        cost += np.repeat([0]+[2*int(abs(d)==2) for _,d in law.LABELS],9)
        for support in (self.h8!=0, echo_support):
            i,j = np.where(support)
            np.testing.assert_array_equal(charge[i],charge[j])
            np.testing.assert_array_equal(cost[i],cost[j])
        self.blocks = {}
        written = np.array([1+j for j,(_,d) in enumerate(law.LABELS) if abs(d)==1])
        sub = (9*written[:,None]+np.arange(9)).ravel()
        np.testing.assert_array_equal(self.h8[np.ix_(np.setdiff1d(np.arange(99),sub),sub)],0)
        gauss = np.tile([a for a,b in self.pairs],len(written))-np.repeat([law.LABELS[j-1][0] for j in written],9)
        np.testing.assert_array_equal((gauss[:,None]-gauss[None,:])*self.h8[np.ix_(sub,sub)],0)
        allowed_mem = [0]+[1+j for j,(_,d) in enumerate(law.LABELS) if abs(d)<=1]
        self.uniform_echo_columns = 3*len(allowed_mem)
        for load in range(3):
            columns = np.arange(11)*9+self.pairs.index((load,load))
            outside = np.setdiff1d(np.arange(99),columns)
            np.testing.assert_array_equal(self.h8[np.ix_(outside,columns)],0)
            self.blocks[load] = self.h8[np.ix_(columns,columns)]/8
            allowed = columns[allowed_mem]
            np.testing.assert_array_equal(echo_support[np.ix_(np.setdiff1d(np.arange(99),allowed),allowed)],False)
        np.testing.assert_allclose(self.blocks[1]@basis,8*basis,atol=1e-14)

    def evolve(self, sign, coin_basis):
        load = np.eye(9)[:,self.pairs.index((1+sign,1))]
        return self.full@np.kron(coin_basis,load[:,None])

    def source(self, sign):
        """Pool both measured load locations. Park the deviation outside the active apparatus."""
        output = self.evolve(sign,(self.basis@self.ready)[:,None]).reshape(11,9)
        expected = np.eye(2)[:,int(sign<0)] if sign else self.ready
        rho = output@output.conj().T
        np.testing.assert_allclose(rho, self.basis@np.outer(expected,expected)@self.basis.T,atol=2e-13)
        weights = []
        parked = np.zeros((11,11),complex)
        for i,(a,b) in enumerate(self.pairs):
            vector = output[:,i]
            prob = np.vdot(vector,vector).real
            if prob < 1e-24:
                continue
            if sign:
                assert sorted((a,b))==sorted((1+sign,1))
                # The occupied port opens its own blank contact to the same third port.
                final = self.blank_swap[:,self.pairs.index((1+sign,1))]
                assert abs(abs(final[self.pairs.index((1,1+sign))])**2-1)<1e-13
            else:
                assert (a,b)==(1,1)
            parked += np.outer(vector,vector.conj())
            weights.append({"endpoint_loads":[a,b],"probability":float(prob)})
        np.testing.assert_allclose(parked,rho,atol=1e-13)
        return self.basis.T@parked@self.basis, weights

    def detector(self, sign):
        """The effect of finding the fresh signed probe at the far endpoint, inclusive of all memories."""
        evolved = self.evolve(sign,self.basis).reshape(11,9,2)
        arrived = evolved[:,self.pairs.index((1,1+sign))]
        stayed = evolved[:,self.pairs.index((1+sign,1))]
        effect = arrived.conj().T@arrived
        np.testing.assert_allclose(effect+stayed.conj().T@stayed,np.eye(2),atol=1e-13)
        np.testing.assert_allclose(effect,np.diag([sign==-1,sign==1]),atol=1e-13)
        return effect

    def current_balance(self):
        """Reverse either the source sign or its launch direction and retain the complete outgoing state."""
        law = candidate.native_law
        memory = self.basis@self.ready
        heads = np.array([0]+[c for c,_ in law.LABELS])
        n_a = np.array([a for a,b in self.pairs])
        records = []
        for t in (0.,np.pi/32,np.pi/16,np.pi/8):
            u = expm(-1j*t*self.h8/8)
            for q in (-1,1):
                for reverse in (False,True):
                    pair = (1,1+q) if reverse else (1+q,1)
                    state = u@np.kron(memory,np.eye(9)[:,self.pairs.index(pair)])
                    weights = abs(state.reshape(11,9))**2
                    flux = pair[0]-weights.sum(axis=0)@n_a
                    head_change = weights.sum(axis=1)@heads-.5
                    analytic = (-1 if reverse else 1)*q*np.sin(4*t)**2/2
                    np.testing.assert_allclose([flux,-head_change],[analytic,analytic],atol=1e-13)
                    records.append({"time":float(t),"source":q,"launch_at_far_endpoint":reverse,
                                    "signed_load_transferred_near_to_far":float(flux),"mean_first_head_change":float(head_change)})
        return records

    def certificate(self):
        effects = {p:self.detector(p) for p in (-1,1)}
        states = {}
        rows = {}
        for q in (-1,0,1):
            rho,weights = self.source(q)
            states[q] = rho
            clicks = {str(p):float(np.trace(e@rho).real) for p,e in effects.items()}
            rows[str(q)] = {"source_load_locations":weights,"final_parked_load":1+q,
                            "coin_probabilities":np.diag(rho).real.tolist(),"local_probe_crossing":clicks}
        separation = np.linalg.norm(states[1]-states[-1],ord="nuc")/2
        assert abs(separation-1)<1e-13
        # All seam memories remain distinct tensor factors even when the seams share a fixed-load port.
        vacuum = self.blocks[1]
        joint = np.kron(vacuum,np.eye(11))+np.kron(np.eye(11),vacuum)
        encoded = np.kron(self.basis,self.basis)
        np.testing.assert_allclose(joint@encoded,16*encoded,atol=1e-13)
        return {"source_and_detector_exposure":float(np.pi/8),"inputs":rows,
                "stored_sign_trace_distance":float(separation),"homogeneous_loads_checked":[0,1,2],
                "local_load_minus_head_commutator_on_all_abs1_columns":0,
                "native_source_flux_and_head_direction_controls":self.current_balance(),
                "uniform_memory_columns_checked":33,"vacuum_off_block_entries_nonzero":0,
                "echo_uniform_columns_without_double_contrast_checked":self.uniform_echo_columns,
                "Q_and_K_preserved_on_full_free_and_echo_support":True,
                "one_signed_source_initial_Q_and_K":[[-1,1],[1,1]],
                "adjacent_seams_ready_subspace_generator": "16 I"}


def gauss_test():
    """On two written adjoining seams, each outer port fixes the binary head on its incident seam."""
    pairs = [(a,b) for a in (0,1) for b in (0,1)]
    swap = np.eye(4)[:,[pairs.index((b,a)) for a,b in pairs]]
    coupling = 0.5*(np.eye(4)-swap)
    left = np.diag([1-a for a,b in pairs])      # G = load - incident directed heads
    right = np.diag([1-(1-b) for a,b in pairs])
    comm = left@coupling-coupling@left
    allowed = [(i,j) for i in range(4) for j in range(4) if i!=j and
               left[i,i]==left[j,j] and right[i,i]==right[j,j]]
    assert not allowed and np.max(abs(comm))==0.5
    return {"outer_vertex_G_commutator_max_entry":float(np.max(abs(comm))),
            "off_diagonal_two_coin_updates_preserving_both_outer_G":len(allowed)}
