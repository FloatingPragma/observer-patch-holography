"""Turn an addressed parity-string endpoint round one physical port of the written cell."""
from __future__ import annotations

import argparse
from collections import Counter
from itertools import product
import json
from pathlib import Path
import sys

import numpy as np
from scipy.sparse import coo_matrix, diags
from scipy.sparse.linalg import expm_multiply

ROOT = Path(__file__).resolve().parents[2] / "reverse-engineering-reality"
sys.path.insert(0, str(ROOT))
from model.candidate_laws.interval_echo.openwave.electron_field.flux_string.search import Patch, phase
from model.executable_model import federation


def star(patch, port):
    faces = sorted(i for i, ports in enumerate(patch.faces) if port in ports)
    graph = patch.dual.subgraph(faces)
    assert len(faces) == 5 and all(d == 2 for _, d in graph.degree())
    order = [faces[0], min(graph.neighbors(faces[0]))]
    while len(order) < len(faces):
        choice, = set(graph.neighbors(order[-1])) - {order[-2]}
        assert choice not in order
        order.append(choice)
    assert graph.has_edge(order[-1], order[0])
    bits = [graph[a][b]["bit"] for a, b in zip(order, order[1:] + order[:1])]
    assert len(set(bits)) == 5
    assert sum(bits) == sum(mask for edge, mask in patch.bit.items() if port in edge)
    return order, sum(bits)


def component(patch, neutral, anchor, sign):
    states = [(anchor, word) for word in neutral]
    index = {state: i for i, state in enumerate(states)}
    lower, upper, weights = [], [], []
    directed_ring_counts = np.zeros((12, 20), dtype=int)
    for i, (port, word) in enumerate(states):
        ring_moves = list(patch.ring_moves(word))
        for face, _ in ring_moves:
            directed_ring_counts[port, face] += 1
        transitions = [((port, next_word), 0.5) for _, next_word in ring_moves]
        transitions.extend((state, 4.0) for state in patch.charge_moves(port, word, sign))
        for target, weight in transitions:
            if target not in index:
                index[target] = len(states)
                states.append(target)
            j = index[target]
            if j > i:
                lower.append(i)
                upper.append(j)
                weights.append(weight)
    graph = coo_matrix((weights, (lower, upper)), shape=(len(states), len(states))).tocsr()
    graph += graph.T
    positions = np.array([p for p, _ in states])
    potential = 8 * (6 - np.asarray(federation(0).degree)[positions])
    ham = diags(graph.sum(axis=0).A1 + potential) - graph
    return states, positions, ham, directed_ring_counts


def check_turns(patch, port, ring_counts, field_size):
    """Evaluate the energy on every triangle after each applied link parity."""
    order, cut = star(patch, port)
    pinned = field_size > 0
    if not pinned:
        return {"centre": port, "reachable": False}
    # An undirected enabled flip of a sign-modulated uniform field carries
    # 4J/N when its two word signs differ. Counts here include both directions.
    energy_if_odd = ring_counts.astype(float) / field_size
    spectators = set(range(20)) - set(order)
    tested = with_energy = 0
    lowest = 1e10
    for start, sense, spectator in product(range(5), (-1, 1), sorted(spectators)):
        field = patch.path(order[start], spectator)
        start_field = field
        seen_energies = []
        for step in range(6):
            f = order[(start+sense*step) % 5]
            odd = np.array([(field & mask).bit_count() % 2 for mask, _ in patch.rings])
            assert set(np.flatnonzero(odd)) == {f, spectator}
            energies = odd * energy_if_odd
            assert np.count_nonzero(energies) <= 2
            seen_energies.extend((energies[f], energies[spectator]))
            if step < 5:
                other = order[(start+sense*(step+1)) % 5]
                field ^= patch.dual[f][other]["bit"]
        assert field ^ start_field == cut
        tested += 1
        if min(seen_energies) > 0:
            with_energy += 1
            lowest = min(lowest, min(seen_energies))
    return {"centre": port, "reachable": True, "parked_field_words": int(field_size),
            "tested_endpoint_routes": tested, "routes_with_both_endpoints_energetic_at_every_step": with_energy,
            "minimum_nonzero_endpoint_energy_on_those_routes": lowest if with_energy else None,
            "incident_faces_in_turn_order": order}


def source(patch, neutral, anchor, sign):
    states, positions, ham, ring_counts = component(patch, neutral, anchor, sign)
    ports = [p for p in range(12) if p != anchor]
    counts = Counter(positions.tolist())
    loops, parked = [], []
    for p in ports:
        _, mask = star(patch, p)
        ref = phase(patch.seed, mask)
        assert all(ref == phase(w, mask) for w in neutral)
        loop = np.array([phase(w, mask)*ref for _, w in states])
        np.testing.assert_array_equal(loop, 1 - 2*(positions == p).astype(int))
        loops.append(loop)
        parked.append(check_turns(patch, p, ring_counts[p], counts[p]))
    loop_read = np.stack(loops)
    path = patch.path(0, patch.opposite)
    source = np.zeros((len(states), 2), dtype=complex)
    source[:len(neutral), 0] = 1 / np.sqrt(len(neutral))
    source[:len(neutral), 1] = [phase(w, path) / np.sqrt(len(neutral)) for w in neutral]
    reads = []
    max_error = 0.
    for tick, states_t in enumerate(expm_multiply(-1j*ham, source, start=0., stop=2., num=17)):
        if tick not in (0, 1, 2, 4, 8, 12, 16):
            continue
        readings = {}
        for label, vector in zip(("uniform", "endpoint_pair"), states_t.T):
            probability = np.bincount(positions, weights=abs(vector)**2, minlength=12)
            # Sum the entire vector in the dark reference arm, including charges away from p.
            dark = (abs((1-loop_read)*vector)**2 / 4).sum(axis=1)
            error = float(max(abs(dark - probability[ports])))
            max_error = max(max_error, error)
            np.testing.assert_allclose(probability.sum(), 1, atol=2e-11)
            np.testing.assert_allclose(dark, probability[ports], atol=2e-12)
            readings[label] = {"charge_probability_by_port": probability.tolist(),
                               "dark_port_probability_by_test_centre": dark.tolist()}
        reads.append({"time": tick/8, **readings})
    return {"sign": sign, "sector_words": len(states), "outside_compensation_path": patch.compensator(anchor, sign),
            "test_centres": ports, "parked": parked, "free_reads": reads,
            "exact_loop_eigenvalue_on_occupied_centre": -1,
            "exact_loop_eigenvalue_on_empty_centre": 1,
            "all_word_centre_tests": len(ports)*len(states),
            "largest_free_fringe_vs_occupation_error": max_error}


def run():
    patch = Patch()
    neutral = patch.field_component()
    anchor = patch.faces[0][0]
    return {"construction": "one physical icosahedral cell, written positive Laplacian, hopping 4 and ring weight 1/2",
            "anchor": anchor, "neutral_words": len(neutral), "unsigned_calibration": "charge-free seed loop sign",
            "trials": [source(patch, neutral, anchor, sign) for sign in (1, -1)]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    output = parser.parse_args().output
    result = run()
    with output.open("x") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")
