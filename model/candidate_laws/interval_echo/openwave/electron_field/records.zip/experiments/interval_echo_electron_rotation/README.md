# Can a localized turn identify the spin of the written charge?

A field endpoint taken once around a parked material defect has relative amplitude **−1** for both an excess and a vacancy. A charge-free control gives **+1**. The same instrument gives −1 on an occupied port even when the field was prepared without an endpoint pair. The sign therefore reads the parity of the enclosed material. It is a measurable mutual response, and an intrinsic spin assignment needs a rotation of the same freely bound object. [Protocol](PROTOCOL.md) · [Operator test and free evolution](run.py) · [Complete results](results.json)

## Five physical seams around a port

Keep the previous one-cell source with its external compensator. All 30 seams are written, all 20 native triangle ring exchanges have weight ½, and the material hopping weight is 4. Park the charge for the turn. Start one prepared string endpoint on a face incident to the test port and keep the other on an exterior face. Advancing the near endpoint across a dual edge applies the parity of its one crossed physical seam to the field word. Reading all twenty ring energies after each step checks that energetic features occur at the two selected faces. Changing which end moved and which path it took is an addressed preparation and readout. [Original field source and meaning of the parity gates](../../reverse-engineering-reality/model/candidate_laws/interval_echo/openwave/electron_field/flux_string/README.md)

Five steps encircle the selected port. Their product on a head word is the parity of the five incident head bits. Calibrate that product on the neutral ground. By the integer flux–load identity, changing the load on the enclosed port by one changes precisely the parity of the net incident head count. The sign of the unit change is immaterial modulo two. For every test port outside the fixed injection address, the calibrated turn thus acts as $I-2P_v$, where $P_v$ projects onto the mobile charge occupying that port. An equal-weight coherent comparison with an identity arm has dark probability equal to the charge occupation. This conclusion holds for arbitrary superpositions of the accessible charge and field words, including entangled ones.

| Sign | Charge-and-field words | Word and test-port combinations | Endpoint routes energetic at both ends for all five steps |
| --- | ---: | ---: | ---: |
| Excess | 1,954 | 21,494 | 500 of 1,650 |
| Vacancy | 5,790 | 63,690 | 1,500 of 1,650 |

Every starting face, sense of turn and exterior spectator was included on the eleven non-injection ports. Some spectator or orbit faces have zero eligible ring energy on a conditional charge sector. The parity instrument itself works on every word in the table. With freely evolved sources, the largest difference between the inclusive dark fraction and the independently summed material occupation was 3.1 × 10⁻¹⁶. At native time ½ the string preparation with an excess gave dark probability 0.151125 at port 8. The charge occupation there was 0.151125. The charge-free ground and the excess in a uniform field supply the controls. [Free charge and fringe by time and port](results.json)

## Turn made by moving face couplings

An independent experiment uses continuous native ring service in place of seam-parity pulses. The charge is parked at port 2. Face 5 is a fixed spectator. Five neighbouring faces are slowed successively, with linear interpolation and all twenty native field terms left on. Local unweighted ring energies determine whether an eigenstate follows the two selected faces. They also serve as a control against identifying an orbital geometric phase by its sign alone. The driving sequence and charge clamp are supplied. The changing field Hamiltonian contains only the previously declared ring operators. [Driven calculation](ring_turn.py) · [Both traversals and all 36 low levels](ring_turn.json)

The neutral reference has 458 head words, the parked excess 118 and the parked vacancy 299. None of the first twelve levels on any of the three fields gave both the moving and the spectator face at least 25% of the total field energy at all five stops. The best minimum fractions were 10.50% for the neutral state, 18.38% for the excess and 10.95% for the vacancy. The uniform ground has no field energy. This localization comparison tests a specified finite preparation and detector threshold. [Raw face fractions and geometric phases](ring_turn.json)

Six excited eigenstates have geometric phase π around this circuit in the adiabatic limit. The excess gives a minus sign on levels 10 and 11 and the vacancy on levels 6, 7, 8 and 10, counting the ground as level 0. Both charged grounds give +1. The adaptive calculation uses 878 subintervals for the excess and 1,418 for the vacancy. A bound on the change of each local Hamiltonian keeps every tracked eigenvalue isolated over each subinterval and its eigendirection within an acute angle of the initial direction there. The smallest numerical gap lower bounds over the twelve levels were 3.66 × 10⁻⁶ and 8.06 × 10⁻⁸ in native units. This second minus sign belongs to the orbital response of a nondegenerate field eigenstate around a prescribed change of couplings. The charge was stationary throughout. The result comes from spectral transport. A timed interferometer read would also require controlling the dynamical phase and measuring transitions out of the chosen level. [Adaptive gap bounds and phase products](refined.json) · [Calculation](refine.py)

From the workspace root, reproduce the addressed trial and the independent driven trial into fresh paths.

~~~sh
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
reverse-engineering-reality/.venv/bin/python -B -W error experiments/interval_echo_electron_rotation/run.py --output /tmp/echo_turn.json
reverse-engineering-reality/.venv/bin/python -B -W error experiments/interval_echo_electron_rotation/ring_turn.py --output /tmp/echo_ring_turn.json
reverse-engineering-reality/.venv/bin/python -B -W error experiments/interval_echo_electron_rotation/refine.py --output /tmp/echo_refined_turn.json
~~~
