"""Certify the charged-ring eigenline orientations by adaptive interval subdivision."""
import argparse
import json
from pathlib import Path

import numpy as np
from scipy.linalg import eigh

from ring_turn import Patch, component, face_operators


def follow(ops, order, spectator, levels=12):
    base = ops.sum(axis=0) - 0.75*ops[spectator]
    signs = np.ones(levels)
    unresolved = np.zeros(levels, dtype=int)
    minimum_bound = np.full(levels, np.inf)
    minimum_overlap = np.ones(levels)
    accepted = 0
    evaluations = 0
    deepest = 0
    for left_face, right_face in zip(order, order[1:]+order[:1]):
        def eigensystem(position):
            nonlocal evaluations
            h = base - 0.75*((1-position)*ops[left_face] + position*ops[right_face])
            energies, vectors = eigh(h, subset_by_index=(0,levels))
            adj = np.diff(energies)
            gap = np.minimum(adj, np.r_[np.inf,adj[:-1]])
            evaluations += 1
            return gap, vectors[:,:levels]

        def visit(a, b, start, end, depth):
            nonlocal accepted, deepest
            gap, first_vec = start
            size = 0.75*(b-a)
            valid = gap > 2*size + 1e-10
            if not np.all(valid) and depth < 15:
                mid = (a+b)/2
                centre = eigensystem(mid)
                visit(a,mid,start,centre,depth+1)
                visit(mid,b,centre,end,depth+1)
                return
            # Each right-hand eigenvector is in the acute cone about its left
            # neighbour throughout this segment whenever the spectral bound passes.
            ov = np.sum(first_vec*end[1],axis=0)
            signs[:] *= np.sign(ov)
            unresolved[:] += (~valid).astype(int)
            minimum_bound[:] = np.minimum(minimum_bound,gap-2*size)
            minimum_overlap[:] = np.minimum(minimum_overlap,abs(ov))
            accepted += 1
            deepest = max(deepest,depth)

        start, end = eigensystem(0.), eigensystem(1.)
        # Include the sign conventions independently chosen in the coincident
        # corner eigensystems, including the closing arm after the last face.
        if left_face == order[0]:
            launch = start[1]
        else:
            signs *= np.sign(np.sum(previous_end*start[1],axis=0))
        previous_end = end[1]
        visit(0.,1.,start,end,0)
    signs *= np.sign(np.sum(previous_end*launch,axis=0))
    return {"accepted_subintervals": accepted, "eigensystem_calls": evaluations, "deepest_bisection": deepest,
            "levels": [{"level": i, "uncertified_subintervals": int(unresolved[i]),
                        "min_gap_lower_bound": float(minimum_bound[i]),
                        "min_adjacent_abs_overlap": float(minimum_overlap[i]),
                        "geometric_sign": int(signs[i]) if unresolved[i]==0 else None}
                       for i in range(levels)]}


def run():
    prior = json.loads(Path(__file__).with_name("ring_turn.json").read_text())
    p = Patch()
    signs = {}
    for sign in (1,-1):
        states, _, _, _ = component(p,p.field_component(),prior["charge_injection_anchor"],sign)
        ops = face_operators(p,[w for pos,w in states if pos==prior["centre"]])
        signs[str(sign)] = follow(ops,prior["moving_faces"],prior["spectator"])
    return {"centre": prior["centre"], "moving_faces": prior["moving_faces"],
            "spectator": prior["spectator"], "by_charge": signs}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    path = parser.parse_args().output
    result = run()
    with path.open("x") as stream:
        json.dump(result, stream,indent=2,allow_nan=False)
        stream.write("\n")
