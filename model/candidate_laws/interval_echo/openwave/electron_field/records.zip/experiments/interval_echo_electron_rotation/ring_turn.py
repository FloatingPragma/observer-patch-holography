"""Geometric phases from a continuously moved reduction in native ring service."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import networkx as nx
import numpy as np
from scipy.linalg import eigh

from run import Patch, component, star


def face_operators(patch, words):
    lookup = {word: i for i, word in enumerate(words)}
    ring = np.zeros((20, len(words), len(words)))
    for i, word in enumerate(words):
        for face, final in patch.ring_moves(word):
            j = lookup[final]
            ring[face, i, i] += 0.5
            ring[face, i, j] -= 0.5
    np.testing.assert_array_equal(ring, ring.transpose(0,2,1))
    np.testing.assert_array_equal(ring.sum(axis=2), np.zeros((20,len(words))))
    return ring


def measure(ops, order, spectator, parts, levels=12):
    total = ops.sum(axis=0)
    base = total - 0.75*ops[spectator]
    last = first = None
    min_gap = np.full(levels, np.inf)
    min_overlap = np.ones(levels)
    sign_product = np.ones(levels)
    min_fractions = np.ones((2,levels))
    spectra = []
    for idx, here in enumerate(order):
        following = order[(idx+1) % len(order)]
        for step in range(parts):
            frac = step/parts
            h = base - 0.75*((1-frac)*ops[here] + frac*ops[following])
            energies, vectors = eigh(h, subset_by_index=(0,levels))
            adjacent = np.diff(energies)
            min_gap = np.minimum(min_gap, np.minimum(adjacent, np.r_[np.inf, adjacent[:-1]]))
            current = vectors[:,:levels]
            if first is None:
                first = current
            if last is not None:
                overlap = np.sum(last*current, axis=0)
                min_overlap = np.minimum(min_overlap, abs(overlap))
                sign_product *= np.sign(overlap)
            if step == 0:
                readings = np.array([np.sum(current*(m@current), axis=0) for m in ops])
                denominator = readings.sum(axis=0)
                assert abs(denominator[0]) < 1e-12
                fractions = np.divide(readings[[here, spectator]], denominator,
                                      out=np.zeros((2,levels)), where=denominator>1e-12)
                min_fractions = np.minimum(min_fractions, fractions)
                spectra.append(energies[:levels].tolist())
            last = current
    closing = np.sum(last*first,axis=0)
    sign_product *= np.sign(closing)
    min_overlap = np.minimum(min_overlap,abs(closing))
    # 0 <= H_f <= I and ||H_f-H_g|| <= 1. The nearest sample is within
    # half a step. Weyl's bound applies to both eigenvalues defining a gap.
    gap_floor = min_gap - 0.75/parts
    # Davis-Kahan on this one-dimensional line also assures the chosen short
    # overlap sign follows the continuous eigenvector, irrespective of local sign.
    stable_orientation = min_gap > 2*0.75/parts
    rows = []
    for i in range(levels):
        rows.append({"level": i, "min_sampled_gap": float(min_gap[i]), "gap_lower_bound": float(gap_floor[i]),
                     "min_neighbour_eigenvector_overlap": float(min_overlap[i]),
                     "sampled_geometric_sign": int(sign_product[i]),
                     "geometric_sign_certified": bool(stable_orientation[i] and min_overlap[i]>0.7),
                     "min_fraction_on_moving_face": float(min_fractions[0,i]),
                     "min_fraction_on_spectator": float(min_fractions[1,i]),
                     "two_endpoint_energy_gate": bool(min(min_fractions[:,i])>=0.25)})
    return {"subdivisions": parts, "rows": rows, "corner_spectra": spectra}


def run():
    patch = Patch()
    words = patch.field_component()
    anchor = patch.faces[0][0]
    sectors = {}
    for sign in (1,-1):
        states, _, _, nring = component(patch, words, anchor, sign)
        sectors[sign] = (states, nring)
    selected = next(p for p in range(12) if p != anchor
                    and all(np.all(nring[p,star(patch,p)[0]] > 0) for _, nring in sectors.values()))
    order, _ = star(patch, selected)
    operators = {0: face_operators(patch, words)}
    for sign,(states, _) in sectors.items():
        operators[sign] = face_operators(patch, [word for pos,word in states if pos==selected])
    eligible = [f for f in range(20) if f not in order and all(np.any(m[f]) for m in operators.values())]
    dist = dict(nx.all_pairs_shortest_path_length(patch.dual))
    spectator = min(eligible, key=lambda f: (-min(dist[f][g] for g in order), f))
    trials = []
    for sign,ops in operators.items():
        forward = [measure(ops, order, spectator, n) for n in (16,32)]
        reverse = measure(ops, [order[0], *order[:0:-1]], spectator, 32)
        for a,b in zip(forward[-1]["rows"], reverse["rows"]):
            if a["geometric_sign_certified"] or b["geometric_sign_certified"]:
                assert a["geometric_sign_certified"] and b["geometric_sign_certified"]
                assert a["sampled_geometric_sign"]==b["sampled_geometric_sign"]
        trials.append({"charge": sign, "field_words_at_park": len(ops[0]), "forward": forward, "reversed": reverse})
    return {"centre": selected, "charge_injection_anchor": anchor, "moving_faces": order, "spectator": spectator,
            "ring_weight": 0.5, "slowed_fraction":0.25, "trials":trials}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",required=True,type=Path)
    dest = parser.parse_args().output
    result = run()
    with dest.open("x") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")
