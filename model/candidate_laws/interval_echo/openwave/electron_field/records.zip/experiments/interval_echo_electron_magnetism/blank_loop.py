"""Write a circulating field from one signed load and fresh blank links."""

import argparse
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from itertools import permutations, product
import json
from pathlib import Path
import sys

import numpy as np
from scipy.linalg import expm

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE.parent/"interval_echo_current"), str(HERE.parent/"interval_echo_gauge_loops")]
from current_algebra import candidate, exact_seam, federation
from geometry import catalog, segments


def local_audit():
    law = candidate.native_law
    h8, _ = exact_seam()
    unit = np.repeat([0, *[abs(d) == 1 for _, d in law.LABELS]], 9)
    np.testing.assert_array_equal((unit[:, None]-unit[None, :])*h8, 0)
    echo = law.echo()
    for index, (a, b) in enumerate(law.SRC):
        wave = np.zeros(99)
        for c in range(2):
            outcome = law.native_event(a, b, c)
            label = law.LABELS.index((c, a-b))
            wave[9*(1+label) + law.SRC.index(outcome)] = 1 / np.sqrt(2)
        np.testing.assert_allclose(echo[:, index], wave, atol=1e-15)
    blank = expm(-1j*np.pi*h8[:9, :9]/8)
    for q in (-1, 1):
        swap = blank[law.SRC.index((1, 1+q)), law.SRC.index((1+q, 1))]
        np.testing.assert_allclose(abs(swap)**2, 1, atol=1e-13)
    # On balanced endpoints the repaired even sign has zero energy. The odd
    # sign keeps its native eigenvalue, the same for either head.
    odd = np.array([1., -1.]) / np.sqrt(2)
    for c in (0, 1):
        ids = [9*(1+law.LABELS.index((c, d)))+law.SRC.index((1, 1)) for d in (-1, 1)]
        ket = np.zeros(99)
        ket[ids] = odd
        np.testing.assert_allclose(h8 @ ket / 8, 9*ket, atol=1e-13)
    return 9*np.outer(odd, odd)


def triangle_oracle(cycle, q, sign_generator):
    """All native coin histories and all scan orders, followed by exact field flight."""
    law = candidate.native_law
    scan = list(segments(cycle))
    results = []
    for order in permutations(range(3)):
        accepted = 0
        for outcomes in product((0, 1), repeat=3):
            load = {v: 1 + q*(v == cycle[0]) for v in cycle}
            records = {}
            for index, c in zip(order, outcomes):
                a, b = sorted(scan[index])
                before = load[a], load[b]
                load[a], load[b] = law.native_event(*before, c)
                records[index] = (a if c else b, before[0]-before[1])
            circulating = any(all(records[i][0] == link[side] for i, link in enumerate(scan)) for side in (0, 1))
            if all(abs(d) == 1 for _, d in records.values()) and load[cycle[0]] == 1+q and circulating:
                accepted += 1
        results.append({"scan_order": list(order), "accepted_histories": accepted, "total_histories": 8})
    assert sorted(r["accepted_histories"] for r in results) == [0, 0, 0, 0, 1, 1]
    fluctuation = sum(np.kron(np.kron(np.eye(2**i), sign_generator), np.eye(2**(2-i))) for i in range(3))
    even = np.full(8, 1/np.sqrt(8))
    difference = np.r_[even, -even]
    repaired = np.kron(np.eye(2), fluctuation) + 0.5*np.outer(difference, difference)
    opposite = expm(-1j*np.pi*repaired)[8:, :8]
    np.testing.assert_allclose((abs(opposite)**2).sum(axis=0), 1/8, atol=1e-13)
    return results


def check_cycle(board, cycle, q):
    law = candidate.native_law
    load = Counter({cycle[0]: q})
    for x, y in segments(cycle):
        a, b = sorted((x, y))
        before = 1+load[a], 1+load[b]
        assert abs(before[0]-before[1]) == 1
        c = int(y == a) if q == 1 else int(x == a)
        out = law.native_event(*before, c)
        load[a], load[b] = out[0]-1, out[1]-1
        assert load[x] == 0 and load[y] == q
    assert load[cycle[0]] == q and all(load[v] == 0 for v in cycle[1:])
    station = cycle[0]
    parking = set(board.neighbours[station]) - set(cycle)
    assert any(v//12 == station//12 for v in parking)
    assert len(set(range(12*(station//12), 12*(station//12+1))) - set(cycle)) >= 2


def run():
    sign_h = local_audit()
    boards = []
    for level in range(3):
        board = federation(level)
        triangles, faces, _, _ = catalog(board)
        groups = Counter()
        for region, cycles in (("cell_triangle", triangles), ("cross_cell_face", faces)):
            for cycle in cycles:
                for q in (-1, 1):
                    for order in (cycle, cycle[::-1]):
                        check_cycle(board, order, q)
                groups[region, len(cycle)] += 1
        rows = []
        for (region, length), count in sorted(groups.items()):
            success = Fraction(1, 2**length)
            rows.append({"region": region, "links": length, "physical_cycles_checked": count,
                         "circulation_write_and_charge_return": str(success),
                         "reversed_receiver_head_given_success_at_t_pi": str(success),
                         "unconditional_success_and_reversal": str(success**2)})
        boards.append({"cells": board.cells, "sweeps": rows})
    return {"script_sha256": sha256(Path(__file__).read_bytes()).hexdigest(), "unit_contrast_free_commutator": 0,
            "triangle_all_orders_and_signs": {str(q): triangle_oracle(next(iter(federation(0).faces())), q, sign_h)
                                              for q in (-1, 1)}, "spheres": boards}


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--output", required=True, type=Path)
    out = cli.parse_args().output
    receipt = json.dumps(run(), indent=2, allow_nan=False) + "\n"
    with out.open("x", encoding="utf-8") as file:
        file.write(receipt)
