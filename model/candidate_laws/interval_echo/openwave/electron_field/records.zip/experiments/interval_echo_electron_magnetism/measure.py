"""Separate orbital flux sensitivity from an intrinsic moment of the signed ground state."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys

import numpy as np
from scipy.linalg import eigh, eigvalsh
from scipy.sparse.csgraph import connected_components

HERE = Path(__file__).resolve().parent
REPAIR = HERE.parent / "interval_echo_vacuum_audit" / "repair"
sys.path.insert(0, str(REPAIR))
from laplacian import Guide, Instrument, federation, graph_laplacian


def magnetic_probe(bare, matter_edges, directed_charge, angles):
    phase = np.zeros(bare.shape)
    moves = matter_edges >= 0
    phase[moves] = directed_charge[moves] * angles[matter_edges[moves]]
    return bare * np.exp(1j * phase)


def return_read(h, original, resident, times):
    energies, modes = eigh(h)
    waves = (modes * modes[original].conj()) @ np.exp(-1j * np.outer(energies, times))
    weights = abs(waves)**2
    np.testing.assert_allclose(weights.sum(axis=0), 1, atol=1e-12)
    return weights[resident].sum(axis=0)


def charge_trial(guide, instrument, q, read_flight):
    basis, previous, admissible = guide.sector(q, instrument)
    positions = np.array([pos for pos, _ in basis])
    words = [word for _, word in basis]
    diagonal = 8 * (6 - guide.board.degree[positions])
    h = graph_laplacian(previous).toarray() + np.diag(diagonal)
    dims = len(basis)
    assert connected_components(h, directed=False)[0] == 1
    site_change = positions[:, None] != positions[None, :]
    edge_ids = np.full(h.shape, -1, int)
    signed = q * np.sign(positions[:, None] - positions[None, :])
    for i, j in zip(*np.where(site_change & (h != 0))):
        index = guide.eid[tuple(sorted((positions[i], positions[j])))]
        assert words[i] ^ words[j] == 1 << index
        assert signed[i, j] == int(bool(words[j] & (1 << index))) - int(bool(words[i] & (1 << index)))
        assert h[i, j] == -4
        edge_ids[i, j] = index
    cuts = previous * site_change
    no_rings = graph_laplacian(cuts).toarray() + np.diag(diagonal)
    energies, modes = eigh(h)
    ground = modes[:, 0] * np.sign(modes[:, 0].sum())
    assert min(ground) > 0 and energies[1] - energies[0] > 1e-10
    member = basis.index((guide.anchor, guide.ref_word))
    times = np.arange(17.)
    base_returns = return_read(h, member, positions == guide.anchor, times) if read_flight else None

    # A site gradient changes only the basis phases of the charged position.
    scalar = lambda v: np.sin(v + 0.1)
    gradient = np.array([scalar(b) - scalar(a) for a, b in guide.edges])
    gauge = np.exp(1j * q * scalar(positions))
    np.testing.assert_allclose(magnetic_probe(h, edge_ids, signed, gradient),
                               gauge[:, None] * h * gauge[None, :].conj(), atol=1e-13)
    rows = []
    for link in guide.chords:
        phase = np.zeros(len(guide.edges))
        phase[link] = np.pi
        half_flux = magnetic_probe(h, edge_ids, signed, phase)
        cut_flux = magnetic_probe(no_rings, edge_ids, signed, phase)
        field_phase = np.exp(-1j * phase[link] * np.array([bool(w & (1 << link)) for w in words]))
        np.testing.assert_allclose(cut_flux, field_phase[:, None]*no_rings*field_phase[None, :].conj(), atol=1e-13)
        levels = eigvalsh(half_flux)
        current = 1j * h * signed * (edge_ids == link)
        current_ground = np.vdot(ground, current @ ground)
        np.testing.assert_allclose(current_ground, 0, atol=1e-13)
        # Matrix perturbation theory gives the quadratic susceptibility. Compare
        # against independent forward/backward eigenvalue shifts at finite twist.
        second = -h * (edge_ids == link)
        elements = modes[:, 1:].T @ current @ ground
        curvature = float(ground @ second @ ground - 2 * np.sum(abs(elements)**2 / (energies[1:] - energies[0])))
        phase[link] = 0.005
        low = lambda a: float(eigvalsh(magnetic_probe(h, edge_ids, signed, a), subset_by_index=[0, 0])[0])
        upper, lower = low(phase), low(-phase)
        np.testing.assert_allclose(upper, lower, atol=2e-12)
        finite = (upper + lower - 2*energies[0]) / phase[link]**2
        np.testing.assert_allclose(finite, curvature, rtol=5e-5, atol=2e-8)
        row = {"physical_chord": guide.edges[link], "zero_twist_current": float(current_ground.real),
               "ground_quadratic_curvature": curvature, "finite_twist_curvature": finite,
               "half_flux_ground_shift": float(levels[0]-energies[0]),
               "half_flux_maximum_level_shift": float(np.max(abs(levels-energies)))}
        if read_flight:
            remote = return_read(half_flux, member, positions == guide.anchor, times)
            row["sharp_source_return_by_time_at_half_flux"] = remote.tolist()
            row["peak_source_return_shift"] = float(np.max(abs(remote-base_returns)))
        rows.append(row)
    return {"sign": q, "component_size": dims, "full_admissible_size": admissible,
            "ground_energy_excluding_parked_reservoir": float(energies[0]), "first_gap": float(energies[1]-energies[0]),
            "all_currents_at_zero_twist": "vanish pointwise in the real ground",
            "untwisted_inclusive_launch_port_returns": None if base_returns is None else base_returns.tolist(),
            "chords": rows}


def blank_triangle_control(instrument, board):
    triangle = next(face for face in board.faces() if all(board.degree[v] == 5 for v in face))
    here = instrument.pairs.index((2, 1))
    there = instrument.pairs.index((1, 2))
    hop = -instrument.h8[there, here] / 8
    assert hop == 0.5
    def matrix(angle):
        shift = np.roll(np.eye(3), 1, axis=0) * np.exp(1j * angle / 3)
        return -hop * (shift + shift.conj().T)
    h0 = matrix(0)
    values, vectors = eigh(h0)
    np.testing.assert_allclose(values, [-2*hop, hop, hop], atol=1e-13)
    shift = np.roll(np.eye(3), 1, axis=0)
    derivative = -1j * hop * (shift-shift.T) / 3
    doublet = vectors[:, 1:]
    slopes = eigvalsh(doublet.conj().T @ derivative @ doublet)
    angle = 1e-4
    numeric = (eigvalsh(matrix(angle))[1:] - values[1:]) / angle
    np.testing.assert_allclose(numeric, slopes, atol=5e-6)
    return {"ports": list(map(int, triangle)), "blank_hop": hop, "circulating_orbital_doublet_slopes": slopes.tolist(),
            "slopes_measured_at_small_flux": numeric.tolist()}


def run():
    fixture_path = HERE.parent / "interval_echo_gauge_loops" / "results.json"
    stored = json.loads(fixture_path.read_text())
    inst = Instrument()
    runs = []
    for level in range(3):
        board = federation(level)
        for number, fixture in enumerate(stored["boards"][level]["fixtures"][:3]):
            guide = Guide(fixture, board, stored["loop_hopping"])
            runs.append({"cells": board.cells, "loops": len(guide.rings), "signs":
                         [charge_trial(guide, inst, q, level == number == 0) for q in (1, -1)]})
    return {"parent_revision": stored["candidate_revision"], "source_hashes": {
        str(p.relative_to(HERE.parent)): sha256(p.read_bytes()).hexdigest()
        for p in (Path(__file__), HERE/"PROTOCOL.md", REPAIR/"laplacian.py", fixture_path)},
        "blank_circulation_control": blank_triangle_control(inst, federation(0)), "guides": runs}


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--output", type=Path, required=True)
    output = cli.parse_args().output
    contents = json.dumps(run(), indent=2, allow_nan=False) + "\n"
    with output.open("x", encoding="utf-8") as out:
        out.write(contents)
