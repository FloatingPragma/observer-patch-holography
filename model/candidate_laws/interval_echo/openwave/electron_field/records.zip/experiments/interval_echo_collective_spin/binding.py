"""Test all-time separation on the selected four-face charge-and-doublet witness."""

import argparse
from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path

import numpy as np
from scipy.linalg import eigh

from search import JoinedSpace, fan, vacuum_code

HERE = Path(__file__).resolve().parent


def other_cell_detectors(space, field, heads):
    vacuum, code = vacuum_code(field, heads)
    both_odd = 2 * code[:, 0] * code[:, 1]
    doublet = code @ code.T
    nonvacuum = np.eye(4) - np.outer(vacuum, vacuum)
    detectors = {name: {'projector': np.zeros((len(space.basis),) * 2), 'kernel_columns': []}
                 for name in ('opposite_cell_doublet', 'opposite_cell_nonvacuum')}
    for occupied, opposite in ((0, 1), (1, 0)):
        offsets = 6 * opposite
        bits = [(space.bits[a + offsets, b + offsets], local) for (a, b), local in field.bits.items()]
        mask = sum(bit for bit, _ in bits)
        groups = defaultdict(dict)
        for i, (x, word) in enumerate(space.basis):
            if x // 6 == occupied:
                other_word = sum(local for bit, local in bits if word & bit)
                groups[x, word & ~mask][other_word] = i
        for states in groups.values():
            indices = [states[w] for w in field.words[heads]]
            for name, block, kernel in (('opposite_cell_doublet', doublet, [vacuum, both_odd]),
                                        ('opposite_cell_nonvacuum', nonvacuum, [vacuum])):
                detectors[name]['projector'][np.ix_(indices, indices)] = block
                for v in kernel:
                    column = np.zeros(len(space.basis))
                    column[indices] = v
                    detectors[name]['kernel_columns'].append(column)
    for d in detectors.values():
        kernel = np.column_stack(d.pop('kernel_columns'))
        np.testing.assert_array_equal(d['projector'] + kernel @ kernel.T, np.eye(len(space.basis)))
        np.testing.assert_array_equal(kernel.T @ kernel, np.eye(kernel.shape[1]))
        d['kernel'] = kernel
    return detectors


def rank_certificate(h, detector, kernel):
    # All three matrices have dyadic entries. A full column rank reduction modulo
    # a prime certifies full rational and complex column rank of the integer stack.
    prime = 1009
    def integers(matrix):
        rounded = np.rint(matrix).astype(np.int64)
        np.testing.assert_array_equal(rounded, matrix)
        return rounded % prime
    evolution = integers(2 * h)
    readout = integers(4 * detector)
    initial = integers(2 * kernel)
    history = []
    pivots = {}
    for power in range(1, h.shape[0] + 1):
        initial = evolution @ initial % prime
        for row in readout @ initial % prime:
            row = row.copy()
            for col in range(len(row)):
                if row[col] == 0:
                    continue
                if col in pivots:
                    row = (row - row[col] * pivots[col]) % prime
                else:
                    pivots[col] = (row * pow(int(row[col]), -1, prime)) % prime
                    break
        history.append(len(pivots))
        if len(pivots) == kernel.shape[1]:
            return {'prime': prime, 'kernel_dimension_at_launch': kernel.shape[1],
                    'stacked_derivative_ranks_mod_prime': history, 'proved_all_time_dark_dimension': 0}
    raise ValueError('The modular rank test did not certify absence of dark states')


def analyze(field, heads, degrees, sign):
    space = JoinedSpace(field, (heads, heads), sign)
    h = space.hamiltonian([6, *degrees[0], 6, *degrees[1]])
    vacuum, code = vacuum_code(field, heads)
    source = np.zeros((len(h), 2))
    source[space.portal[0]] = np.einsum('ik,j->ijk', code, vacuum)
    energy, vectors = eigh(h)
    eigenspaces = np.split(np.arange(len(h)), np.flatnonzero(np.diff(energy) > 1e-9) + 1)
    # With no mobile charge the single bridge cannot change head, and the ring
    # Laplacian on each side acts independently on its four neutral words.
    neutral_ring = field.ring_laplacian(field.words[heads])
    neutral_h = np.kron(neutral_ring, np.eye(4)) + np.kron(np.eye(4), neutral_ring)
    np.testing.assert_array_equal(neutral_h @ np.kron(vacuum, vacuum), np.zeros(16))
    neutral_levels = np.linalg.eigvalsh(neutral_h)
    assert sum(abs(neutral_levels) < 1e-9) == 1 and neutral_levels[0] > -1e-12
    launch = np.zeros((len(h), 3))
    launch[space.portal[0]] = np.einsum('ik,j->ijk', np.column_stack([vacuum, code]), vacuum)
    mean = launch.T @ h @ launch
    h_launch = h @ launch
    second = h_launch.T @ h_launch
    np.testing.assert_array_equal(mean, np.diag([16, 17, 17]))
    np.testing.assert_array_equal(second, np.diag([16**2 + 64, 17**2 + 64, 17**2 + 64]))
    bottom = vectors[:, eigenspaces[0]]
    weights = (bottom.T @ launch).T @ (bottom.T @ launch)
    assert len(eigenspaces[0]) == 1
    energy_read = {
        'neutral_empty_guide_ground_energy': 0.0, 'neutral_ground_multiplicity': 1,
        'charged_sector_ground_energy': float(energy[0]), 'charged_ground_multiplicity': len(eigenspaces[0]),
        'charged_sector_next_energy': float(energy[eigenspaces[1][0]]),
        'fixed_compensator_energy_included': False,
        'launch_order': ['ring_vacuum', 'first_outer_ring_odd', 'last_outer_ring_odd'],
        'mean_energy': np.diag(mean).tolist(), 'energy_standard_deviation': np.sqrt(np.diag(second) - np.diag(mean)**2).tolist(),
        'ground_weights': np.diag(weights).tolist(), 'logical_ground_weight_range': [0.0, float(np.trace(weights[1:, 1:]))],
        'logical_energy_mean_matrix': mean[1:, 1:].tolist(), 'logical_second_moment_matrix': second[1:, 1:].tolist()}
    result = {}
    for name, description in other_cell_detectors(space, field, heads).items():
        detector, kernel = description['projector'], description['kernel']
        np.testing.assert_array_equal(detector @ source, np.zeros_like(source))
        derivative = detector @ h @ source
        np.testing.assert_array_equal(derivative.T @ derivative, 16 * np.eye(2))
        # Infinite Cesaro mean: each distinct-energy projector is kept whole.
        gram = np.zeros_like(h)
        for sub in eigenspaces:
            v = vectors[:, sub]
            gram += v @ (v.T @ detector @ v) @ v.T
        on_source = source.T @ gram @ source
        result[name] = {'rank_certificate': rank_certificate(h, detector, kernel),
                        'first_derivative_gram_on_source': (derivative.T @ derivative).tolist(),
                        'infinite_time_mean_gram_on_source': on_source.tolist(),
                        'min_max_mean_probability_on_source': np.linalg.eigvalsh(on_source).tolist(),
                        'min_max_mean_probability_in_full_sector': np.linalg.eigvalsh(gram)[[0, -1]].tolist()}
    return {'sign': sign, 'heads_each_side': heads, 'dimension': len(h),
            'distinct_energy_clusters': len(eigenspaces),
            'smallest_gap_between_distinct_cluster_means': float(min(np.diff([energy[s].mean() for s in eigenspaces]))),
            'reads': result, 'energy': energy_read}


def run():
    existing = HERE / 'results.json'
    best = json.loads(existing.read_text())['headline']['best_worst_qubit_success']
    source_heads = tuple(best['release']['head_sectors'][0])
    assert best['release']['sign'] == 1 and source_heads == tuple(best['release']['head_sectors'][1])
    field = fan(4)
    degrees = [sum(i in e for e in field.edges) for i in range(6)]
    conjugate = tuple(deg - h for deg, h in zip(degrees, source_heads))
    positive = analyze(field, source_heads, best['degrees'], 1)
    negative = analyze(field, conjugate, best['degrees'], -1)
    for name in positive['reads']:
        np.testing.assert_allclose(positive['reads'][name]['min_max_mean_probability_on_source'],
                                   negative['reads'][name]['min_max_mean_probability_on_source'], atol=2e-11)
        assert positive['reads'][name]['rank_certificate'] == negative['reads'][name]['rank_certificate']
    return {'physical_ports': best['actual_ports'], 'rim_degrees': best['degrees'],
            'sectors': [positive, negative], 'sha256': {p.name: sha256(p.read_bytes()).hexdigest()
                    for p in (Path(__file__), HERE / 'search.py', existing)}}


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--output', required=True, type=Path)
    output = cli.parse_args().output
    with output.open('x') as dst:
        json.dump(run(), dst, indent=2, allow_nan=False)
        dst.write('\n')
