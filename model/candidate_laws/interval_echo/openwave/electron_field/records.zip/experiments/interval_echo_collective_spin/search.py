"""Search parked multi-ring doublets and release them with a signed material load."""

import argparse
from collections import Counter, defaultdict
from hashlib import sha256
from itertools import combinations, product
import json
from pathlib import Path
import sys

import networkx as nx
import numpy as np
from scipy.linalg import eigh
from scipy.sparse.csgraph import connected_components

HERE = Path(__file__).resolve().parent
PREVIOUS = HERE.parent / 'interval_echo_electron_spin'
sys.path.insert(0, str(PREVIOUS))
from winding import ChargeSpace, edge, federation, segments


class LocalField:
    def __init__(self, rings, n_vertices):
        self.rings = rings
        self.edges = sorted({edge(a, b) for ring in rings for a, b in segments(ring)})
        self.bits = {ab: 1 << i for i, ab in enumerate(self.edges)}
        self.masks = [sum(self.bits[edge(a, b)] for a, b in segments(r)) for r in rings]
        self.clockwise = [sum(self.bits[edge(a, b)] for a, b in segments(r) if a < b) for r in rings]
        self.words = defaultdict(list)
        for word in range(1 << len(self.edges)):
            heads = [0] * n_vertices
            for ab, bit in self.bits.items():
                heads[ab[0] if word & bit else ab[1]] += 1
            self.words[tuple(heads)].append(word)

    def ring_laplacian(self, words):
        ids = {word: i for i, word in enumerate(words)}
        h = np.zeros((len(words), len(words)))
        for i, word in enumerate(words):
            for mask, cw in zip(self.masks, self.clockwise):
                if word & mask in (cw, mask ^ cw):
                    h[i, i] += .5
                    h[i, ids[word ^ mask]] -= .5
        np.testing.assert_array_equal(h, h.T)
        return h


def fan(n):
    spokes = 5 if n == 5 else n + 1
    return LocalField([(0, j + 1, (j + 1) % spokes + 1) for j in range(n)], spokes + 1)


def screen_fans():
    records, doublets = [], []
    for n in range(1, 6):
        field = fan(n)
        repeats, dimensions = [], Counter()
        for heads, words in field.words.items():
            h = field.ring_laplacian(words)
            count, labels = connected_components(h, directed=False)
            for k in range(count):
                idx = np.flatnonzero(labels == k)
                energy = np.linalg.eigvalsh(h[np.ix_(idx, idx)])
                dimensions[len(idx)] += 1
                for level, mult in Counter(np.round(energy, 10)).items():
                    if mult > 1:
                        repeats.append({'heads': heads, 'words': [words[i] for i in idx],
                                        'level': float(level), 'multiplicity': mult})
                        assert n == 4 and len(idx) == len(words) == 4 and (level, mult) == (1, 2)
                        np.testing.assert_allclose(energy, [0, 1, 1, 2], atol=1e-13)
                        doublets.append(heads)
        records.append({'faces': n, 'neutral_head_sectors': len(field.words),
                        'connected_component_dimension_counts': dict(sorted(dimensions.items())),
                        'degenerate_connected_levels': repeats})
    assert len(doublets) == 2
    return records, sorted(doublets)


def geometry_census():
    boards, examples = [], {}
    for level in range(3):
        board = federation(level)
        incident = defaultdict(list)
        for r in board.faces():
            for p in r:
                incident[p].append(tuple(r))
        petals, fans = {}, {}
        for p in {v for bridge in board.external for v in bridge}:
            petals[p] = []
            fans[p] = []
            for r, s in combinations(incident[p], 2):
                if len(set(r) & set(s)) == 1:
                    petals[p].append(tuple(sorted(tuple(sorted(int(board.degree[v]) for v in t if v != p))
                                                      for t in (r, s))))
            rim = nx.Graph(sorted(set(t) - {p}) for t in incident[p])
            assert len(rim) == 5 and len(rim.edges) == 5
            for missing in list(rim.edges):
                missing = edge(*missing)
                rim.remove_edge(*missing)
                path = nx.shortest_path(rim, *missing)
                rim.add_edge(*missing)
                degree = tuple(int(board.degree[x]) for x in path)
                if degree[::-1] < degree:
                    path, degree = path[::-1], degree[::-1]
                fans[p].append((degree, tuple([p] + path)))
        separate, joined = Counter(), Counter()
        for a, b in board.external:
            separate.update(product(petals[a], petals[b]))
            for (left, av), (right, bv) in product(fans[a], fans[b]):
                joined[left, right] += 1
                examples.setdefault((left, right), {'cells': board.cells, 'left': av, 'right': bv})
        assert all(any(x == y for x, y in left) and any(x == y for x, y in right) for left, right in separate)
        boards.append({'cells': board.cells, 'separate_loop_fixtures': sum(separate.values()),
                       'separate_loop_degree_classes': [{'left': a, 'right': b, 'count': count}
                                                        for (a, b), count in sorted(separate.items())],
                       'four_face_fixtures': sum(joined.values()),
                       'four_face_degree_classes': [{'left': a, 'right': b, 'count': count}
                                                    for (a, b), count in sorted(joined.items())]})
    assert len(examples) == 16
    return boards, examples


class JoinedSpace(ChargeSpace):
    """Factor Gauss enumeration at the bridge, keeping the existing full-contact Hamiltonian."""
    def __init__(self, field, backgrounds, sign):
        offsets = (0, 6)
        bridge = (0, 6)
        self.sign = sign
        self.edges = sorted([bridge] + [(a + off, b + off) for off in offsets for a, b in field.edges])
        self.bits = {ab: 1 << i for i, ab in enumerate(self.edges)}
        self.rings = [self.orient(tuple(v + off for v in r)) for off in offsets for r in field.rings]
        lifted = [{w: sum(self.bits[a + off, b + off] for (a, b), bit in field.bits.items() if w & bit)
                   for words in field.words.values() for w in words} for off in offsets]
        self.basis, self.portal = [], []
        for side, home in enumerate(offsets):
            portal = np.zeros((4, 4), int)
            bridge_word = self.bits[bridge] if (side == 0) == (sign == 1) else 0
            for x in range(6):
                sectors = list(backgrounds)
                sectors[side] = tuple(n + sign * (int(v == x) - int(v == 0))
                                      for v, n in enumerate(backgrounds[side]))
                for i, u in enumerate(field.words.get(sectors[0], [])):
                    for j, v in enumerate(field.words.get(sectors[1], [])):
                        if x == 0:
                            portal[i, j] = len(self.basis)
                        self.basis.append((home + x, lifted[0][u] | lifted[1][v] | bridge_word))
            self.portal.append(portal)
        self.ids = {s: i for i, s in enumerate(self.basis)}
        assert len(self.ids) == len(self.basis)


def vacuum_code(field, background):
    words = field.words[background]
    # The two outer face flips independently exchange opposite circulations.
    # The four words form a square. These coordinates fix the same qubit at both ends.
    first, last = field.masks[0], field.masks[-1]
    base = min(words)
    sign_bits = {base ^ (u * first) ^ (v * last): (u, v) for u, v in product((0, 1), repeat=2)}
    assert set(sign_bits) == set(words)
    vacuum = np.full(4, .5)
    code = np.array([[(-1) ** u / 2, (-1) ** v / 2] for u, v in map(sign_bits.get, words)])
    h = field.ring_laplacian(words)
    np.testing.assert_array_equal(h @ code, code)
    np.testing.assert_array_equal(h @ vacuum, np.zeros(4))
    np.testing.assert_array_equal(code.T @ code, np.eye(2))
    return vacuum, code


def release(field, backgrounds, degrees, sign, times, verify_direct=False):
    space = JoinedSpace(field, backgrounds, sign)
    degree = [6, *degrees[0], 6, *degrees[1]]
    h = space.hamiltonian(degree)
    if verify_direct:
        a, word = space.basis[space.portal[0][0, 0]]
        ref = dict(zip(space.edges, space.heads(word)))
        rings = [tuple(v + off for v in r) for off in (0, 6) for r in field.rings]
        direct = ChargeSpace(set(space.edges), rings, a, ref, sign)
        order = [direct.ids[s] for s in space.basis]
        assert len(order) == len(direct.basis)
        np.testing.assert_array_equal(direct.hamiltonian(degree)[np.ix_(order, order)], h)
    va, ca = vacuum_code(field, backgrounds[0])
    vb, cb = vacuum_code(field, backgrounds[1])
    src = np.zeros((len(h), 2))
    dst = np.zeros_like(src)
    src[space.portal[0]] = np.einsum('ik,j->ijk', ca, vb)
    dst[space.portal[1]] = np.einsum('i,jk->ijk', va, cb)
    levels, modes = eigh(h)
    source_modes = modes.T @ src
    amp = np.einsum('an,nb->nab', dst.T @ modes, source_modes)
    phase = np.exp(-1j * np.outer(times, levels))
    transfer = (phase @ amp.reshape(len(h), 4)).reshape(-1, 2, 2)
    singular = np.linalg.svd(transfer, compute_uv=False)
    # Unresolved channels have zero reported weight and no meaningful fitted peak.
    # Rounding probabilities for peak selection also breaks conjugate-sector ties reproducibly.
    probabilities = singular ** 2
    strong = int(np.argmax(np.round(probabilities[:, 0], 12)))
    weak_resolved = max(probabilities[:, 1]) > 1e-12
    weak = int(np.argmax(np.round(probabilities[:, 1], 12))) if weak_resolved else strong
    # Receiver-only read: leave source field unmeasured. Report a joint success probability
    # and entanglement negativity of its trace-normalized, locally heralded Choi state.
    # The four source words give four Kraus operators for the receiver doublet.
    remote = np.zeros((len(h), 4, 2))
    remote[space.portal[1]] = np.einsum('ia,jk->ijak', np.eye(4), cb)
    k_spectrum = np.einsum('ain,nj->naij', remote.reshape(len(h), 8).T.reshape(4, 2, len(h)) @ modes,
                           source_modes)
    kraus = (phase @ k_spectrum.reshape(len(h), 16)).reshape(-1, 4, 2, 2)
    vec = kraus.reshape(-1, 4, 4)
    choi = np.einsum('tai,taj->tij', vec, vec.conj()) / 2
    weight = np.trace(choi, axis1=1, axis2=2).real
    partial = choi.reshape(-1, 2, 2, 2, 2).transpose(0, 1, 4, 3, 2).reshape(-1, 4, 4)
    # Keep absolute negative weight too, so almost-impossible heralds cannot win on normalization.
    negative_weight = -np.minimum(np.linalg.eigvalsh(partial), 0).sum(axis=1)
    ent = int(np.argmax(np.round(negative_weight, 12)))
    ent_resolved = max(negative_weight) > 1e-12
    charge_mask = [x >= 6 for x, _ in space.basis]
    best_state = modes @ (phase[weak, :, None] * source_modes)
    worst = float(probabilities[weak, 1]) if weak_resolved else 0.0
    charge_worst = float(np.linalg.svd(best_state[charge_mask], compute_uv=False)[-1] ** 2)
    def mats(m):
        return {'real': np.where(abs(m.real) > 1e-12, m.real, 0.0).tolist(),
                'imag': np.where(abs(m.imag) > 1e-12, m.imag, 0.0).tolist()}
    return {'head_sectors': backgrounds, 'sign': sign, 'dimension': len(h),
            'best_worst_qubit_success': worst, 'best_worst_time': float(times[weak]),
            'best_worst_transfer_matrix': mats(transfer[weak]),
            'better_input_success_at_same_time': float(probabilities[weak, 0]) if probabilities[weak, 0] > 1e-12 else 0.0,
            'worst_charge_crossing_at_same_time': charge_worst if charge_worst > 1e-12 else 0.0,
            'best_single_input_success': float(probabilities[strong, 0]) if probabilities[strong, 0] > 1e-12 else 0.0,
            'best_single_input_time': float(times[strong]),
            'best_receiver_only_negative_weight': float(negative_weight[ent]) if ent_resolved else 0.0,
            'receiver_only_mean_joint_success_at_that_time': float(weight[ent]) if ent_resolved else None,
            'receiver_only_conditional_negativity_at_that_time': (
                float(negative_weight[ent] / weight[ent]) if ent_resolved else None),
            'best_receiver_only_time': float(times[ent]) if ent_resolved else None}


def witness_controls(field, best, times):
    bg = tuple(map(tuple, best['release']['head_sectors']))
    grades = best['degrees']
    sign = best['release']['sign']
    space = JoinedSpace(field, bg, sign)
    h = space.hamiltonian([6, *grades[0], 6, *grades[1]])
    va, ca = vacuum_code(field, bg[0])
    vb, cb = vacuum_code(field, bg[1])
    src = np.zeros((len(h), 2))
    src[space.portal[0]] = np.einsum('ik,j->ijk', ca, vb)
    levels, modes = eigh(h)
    ew = np.exp(-1j * np.outer(times, levels))
    spectra = modes.T @ src
    history = (ew[:, :, None] * spectra).transpose(0, 2, 1) @ modes.T
    history = history.transpose(0, 2, 1)
    mask_b = np.array([x >= 6 for x, w in space.basis])
    rb = history[:, mask_b, :]
    arrivals = np.einsum('tai,taj->tij', rb.conj(), rb)
    charge_range = np.linalg.eigvalsh(arrivals)
    ordinary_contrast = (arrivals[:, 1, 1] - arrivals[:, 0, 0]).real
    # Equal-weight conjugate superpositions. A sign is meaningful only for the specified code axes.
    chiral_contrast = 2 * arrivals[:, 0, 1].imag
    groups = []
    for source, other in [(0, 1), (1, 0)]:
        code = (ca, cb)[other]
        local_words = field.words[bg[other]]
        lifted_bits = [(space.bits[a + 6*other, b + 6*other], bit) for (a, b), bit in field.bits.items()]
        groups_by_residue = defaultdict(dict)
        local_mask = sum(bit for bit, _ in lifted_bits)
        for i, (x, w) in enumerate(space.basis):
            if x // 6 == source:
                word = sum(bit for lifted, bit in lifted_bits if w & lifted)
                groups_by_residue[x, w & ~local_mask][word] = i
        groups.append([(list(g[w] for w in local_words), code) for g in groups_by_residue.values()])
    sep = []
    for group in groups:
        prob = np.zeros(len(times))
        for indices, code in group:
            reduced = np.einsum('ai,taj->tij', code, history[:, indices, :])
            prob += np.sum(abs(reduced)**2, axis=(1, 2))/2
        sep.append(prob)
    t = best['release']['best_worst_time']
    i = int(np.flatnonzero(times == t)[0])
    np.testing.assert_allclose(charge_range[i, 0], best['release']['worst_charge_crossing_at_same_time'], atol=1e-12)
    im = int(np.argmax(charge_range[:, 1] - charge_range[:, 0]))
    parked = field.ring_laplacian(field.words[bg[0]])
    words = field.words[bg[0]]
    first = field.masks[0]
    perturb = np.zeros_like(parked)
    for j, w in enumerate(words):
        perturb[j, j], perturb[j, words.index(w ^ first)] = .01, -.01
    np.testing.assert_allclose(np.linalg.eigvalsh(parked + perturb), [0, 1, 1.02, 2.02], atol=1e-13)
    # Stabilizer of the selected fan graph, including its measured native grades and fixed portal.
    graph = nx.Graph(field.edges)
    for u in graph:
        graph.nodes[u]['label'] = ('gate', 6) if u == 0 else ('rim', grades[0][u-1])
    auto = nx.algorithms.isomorphism.GraphMatcher(graph, graph, node_match=lambda a, b: a == b)
    n_auto = sum(1 for _ in auto.isomorphisms_iter())
    assert n_auto == 1
    return {'gateway_14_24_selected_sign': sign, 'selected_time': float(t),
            'charge_in_receiver_min_max_over_input': charge_range[i].tolist(),
            'charge_in_receiver_for_fixed_odd_first_second_inputs': np.diag(arrivals[i]).real.tolist(),
            'charge_arrival_max_contrast_over_all_inputs': float(charge_range[im, 1] - charge_range[im, 0]),
            'charge_arrival_max_contrast_time': float(times[im]),
            'maximum_absolute_charge_contrast_of_fixed_orbital_inputs': float(max(abs(ordinary_contrast))),
            'maximum_absolute_charge_contrast_of_conjugate_orbital_inputs': float(max(abs(chiral_contrast))),
            'receiving_ring_doublet_charge_in_source_at_selected_time': float(sep[0][i]),
            'source_ring_doublet_charge_in_receiver_at_selected_time': float(sep[1][i]),
            'maximum_separation_probability_mixed_input': float(max(sep[0] + sep[1])),
            'maximum_separation_time': float(times[np.argmax(sep[0] + sep[1])]),
            'parked_energies': np.linalg.eigvalsh(parked).tolist(),
            'parked_energies_first_face_rate_times_1_02': np.linalg.eigvalsh(parked + perturb).tolist(),
            'graded_fixed_gateway_geometric_automorphisms': n_auto}


def run():
    screened, backgrounds = screen_fans()
    counts, examples = geometry_census()
    field = fan(4)
    times = np.arange(1025) / 16
    releases = []
    for degrees, witness in sorted(examples.items()):
        records = []
        for trial, (a, b, sign) in enumerate(product(backgrounds, backgrounds, (-1, 1))):
            records.append(release(field, (a, b), degrees, sign, times, verify_direct=not releases and trial == 0))
        # Charge conjugation complements every field head and reverses the material sign.
        for k in range(4):
            for key in ('best_worst_qubit_success', 'best_single_input_success', 'best_receiver_only_negative_weight'):
                np.testing.assert_allclose(records[k][key], records[7-k][key], rtol=1e-8, atol=1e-11)
        releases.append({'rim_degrees': degrees, 'actual_ports': witness, 'releases': records})
    ranked = [(r, batch) for batch in releases for r in batch['releases']]
    headline = {}
    for key in ('best_worst_qubit_success', 'best_single_input_success', 'best_receiver_only_negative_weight'):
        r, batch = max(ranked, key=lambda item: (round(item[0][key], 12), item[0]['sign']))
        headline[key] = {'value': r[key], 'degrees': batch['rim_degrees'], 'actual_ports': batch['actual_ports'],
                         'release': r}
    return {'parked_neutral_screens': screened, 'geometry_census': counts, 'time_grid': [0, 64, 1/16],
            'headline': headline, 'selected_witness_controls': witness_controls(field, headline['best_worst_qubit_success'], times),
            'released_degree_classes': releases,
            'sha256': {str(p.relative_to(HERE.parent)): sha256(p.read_bytes()).hexdigest() for p in
                       (Path(__file__), PREVIOUS/'winding.py', HERE.parent/'interval_echo_vacuum_audit/repair/laplacian.py')}}


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--output', required=True, type=Path)
    args = cli.parse_args()
    result = run()
    with args.output.open('x') as out:
        json.dump(result, out, indent=2, allow_nan=False)
        out.write('\n')
