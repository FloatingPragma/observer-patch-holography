# Transport of a two-state ring excitation with a signed load

An independently chosen ring state changes the motion of a signed material load and can be recovered coherently one cell away. The example uses four adjacent native triangles on each end of gateway 14–24. Both local states have the same parked energy. The field and load frequently occupy different cells after release. These data support conditional transfer of an orbital doublet. An electron assignment would also require a physical spin transformation, exchange statistics and an independently calibrated rest energy.

## Native configurations and independent preparation

We retained a contiguous fan of one through five triangles around a degree-six cell gateway. At fixed signed load position we enumerated every assignment of head orientations on the retained links, sorted by the local head counts that enter Gauss's law, and diagonalized each connected neutral ring-flip component. Distinct frozen components were screened separately because the ring dynamics cannot coherently interconvert them. The native ring flip rate was `J = 1/2`. All energies and times below are dimensionless model units.

| Contiguous faces | Head-count sectors | Connected levels with multiplicity greater than one |
|---:|---:|---|
| 1 | 7 | None |
| 2 | 24 | None |
| 3 | 82 | None |
| 4 | 280 | Two complementary sectors, each with a doublet at 1 |
| 5 | 462 | None |

Each qualifying sector contains four field words. The two outer rings flip independently with the charge parked. Their spectra combine to give energies `0, 1, 1, 2`. Choose the vacuum as the equal superposition of all four words. The first logical state is odd under reversal of the first outer ring and even under reversal of the last. The second state has these parities interchanged. Any superposition is an independent preparation at the same energy and signed load. The two inner triangles become relevant when the load enters the fan.

As a control we also enumerated pairs of native triangles that meet only at the gateway, retaining just their edges. There are 750, 3,000 and 12,000 choices of two such triangles at each end of a gateway on the 20-, 80- and 320-cell boards, counting each registered undirected gateway in its listed orientation. Every source pair contains a triangle whose two tip sites have identical full-board degree. Exchanging those tips is a symmetry of the retained full-contact dynamics. An input odd on that triangle remains odd under this symmetry. Every remote read that resets the source to its even vacuum has zero amplitude for that input for all times. A single functioning input would therefore give a false doublet-transport identification on this support.

## Release and readout

At both gateways we retained all four native triangles of the selected fan and their nine links, joined by the original gateway seam. Other board links were inactive. The Hamiltonian used the existing repaired contact Laplacian with matter-hop rate 4, ring-flip rate 1/2, and native grade potential `8*(6−degree)`. The full signed Gauss sector contains 96, 128 or 160 joint position/head configurations. We independently checked one factorized enumeration against a direct sweep of all 524,288 binary configurations on the 19 links. The direct Hamiltonian matched exactly after reordering its basis.

For each board, each gateway has five choices of its four-triangle fan at either end, again giving 750, 3,000 and 12,000 ordered-by-listed-gateway fixtures. The union has 16 ordered pairs of physical rim-degree patterns up to relabeling. For each pattern we released both head sectors at each end for each sign, giving 128 exact finite-matrix evolutions. We sampled times from 0 through 64 at intervals of 1/16. The time and fixture reported below were selected from that search. The observed maximum is specific to that grid and active support.

The incoming state is `charge at A × chosen logical state at A × vacuum at B`. The outgoing matrix element reads `charge at B × vacuum at A × chosen logical state at B`. Its two squared singular values give the minimum and maximum joint success probabilities over every normalized input. Eight releases cleared `10⁻¹²` on the smaller probability. A single state could reach joint success `0.383084` in a different configuration whose other input never cleared the resolution of `10⁻¹²`. The receipt reports sub-resolution channels as zero. Peak selection rounds probabilities to twelve decimals, retains the first tied time and favors the positive sign between equally scoring conjugate releases. When the smaller channel is unresolved the receipt records the time of the stronger channel.

| Observable on the 160-state gateway 14–24 witness | Model time | Value |
|---|---:|---:|
| Joint transfer probability, minimum and maximum over input | 30.8125 | 0.120866 to 0.142314 |
| Charge anywhere in receiving cell, first ring odd | 30.8125 | 0.660695 |
| Charge anywhere in receiving cell, last ring odd | 30.8125 | 0.475632 |
| Mean gateway and doublet success with source wholly unobserved | 27.0625 | 0.201402 |
| Reference–receiver negativity conditioned on that receiver read | 27.0625 | 0.322302 |
| Sender doublet retained with charge in receiving cell, equal input mixture | 30.8125 | 0.225148 |
| Receiver doublet present with charge in sending cell, equal input mixture | 30.8125 | 0.150199 |
| Largest probability of doublet in the opposite cell to charge, equal input mixture | 53.3125 | 0.536893 |

The witness source is `[14,18,15,16,23,22]` and the destination is `[24,31,25,29,35,34]`, with the gateway first and the five rim sites in path order. The positive-load run has head counts `(3,1,2,0,2,1)` on each fan. Complementing all field heads and reversing the load gives the same transfer probabilities. For the receiver-only test we prepared half of a maximally entangled input in the doublet, projected the load onto the receiving gateway and the receiving rings onto their doublet, then traced out all source field words. The quoted negativity is the absolute sum of negative eigenvalues of the normalized Choi state's partial transpose. A maximally entangled two-qubit state has value `0.5`. At the reported time the success-weighted negativity was `0.064912`. The receiver retained coherence without a source measurement.

## Spin and binding

The graded four-face witness admits only the identity as a geometric symmetry fixing its gateway. A 2% increase in one outer ring-flip rate keeps all terms real and preserves Gauss's law while splitting the parked doublet to `1` and `1.02`. In the unperturbed launch, the orbital choice changes the probability of the charge crossing the seam. At the optimum joint-transfer time, the equal input mixture places the charge in the opposite cell to a local doublet with total probability `0.375347`. A successful remote read alone cannot establish a permanently bound composite. The search did not measure a spinorial spatial rotation, two-composite exchange or a scattering threshold for binding. The parked spacing `1` has no independent keV calibration.

## Exact test of whether the rings can stay with the charge

On gateway 14–24 we tested two projectors on the rings in the cell opposite the charge. One detects the energy-1 doublet. The other detects any state orthogonal to the local ring vacuum. For either projector `Q`, Hamiltonian `H` and the two-column source preparation `S`, the exact initial response satisfies `QS = 0` and `(QHS)†(QHS) = 16 I`. Thus at short times every normalized source superposition gives separation probability `16 t²` to leading order.

We also allowed arbitrary preparations across all 160 joint configurations. An initial state with an identically zero separation probability must be in the kernel of `Q`. If `K` contains an orthonormal basis for this kernel, it must additionally lie in the kernel of every stacked matrix `Q Hʲ K` in kernel coordinates. After clearing powers of two from the matrices, a reduction modulo the prime 1009 attained full column rank. For the doublet detector the rank grew from 8 to 80 over the first ten powers. For the nonvacuum detector it grew from 6 to 40 over the first seven powers. Full rank modulo this prime implies full rank over the rationals and complex numbers. Both conjugate load sectors therefore have zero-dimensional all-time kernels for either separation readout on this fixture.

We calculated the infinite-time mean via the full projectors onto the distinct energy eigenspaces. Across all independently prepared source qubits, the mean probability for the opposite-cell doublet ranges from `0.402877` to `0.447835`. The corresponding mean probability for any opposite-cell nonvacuum is `0.481769` to `0.556456`. These bounds concern strict confinement to the charge's cell on this finite patch. An excitation spread over several cells would need a separate binding-energy and size measurement.

### Energy on the same gateway

The empty neutral guide has ground energy zero. With the fixed compensator excluded, the lowest one-load energy is `3.54801145`, has multiplicity one, and is followed by `4.65410892`. A load placed at the source gateway with both ring systems in their vacuum has mean energy `16` and standard deviation `8`. Each independently chosen odd-ring state and every superposition of the two have mean `17` and standard deviation `8`. The two individual source states have probabilities `0.00009509` and `0.01097653` of occupying the charged ground. Across arbitrary qubit inputs the ground weight ranges from zero to `0.01107162`. The charged-sector bottom is a finite-guide formation energy. The transferred preparation has a broad distribution across excited levels, and the calculation uses dimensionless model units throughout.

[Binding and energy calculation](binding.py) · [Binding and energy receipt](binding.json)

## Replay

From the outer project root, run the archived calculation with a fresh destination file. The receipt contains the geometric multiplicities, neutral sectors, representative port labels, all 128 sampled-release summaries, source-blind tests and selected-witness controls.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
  reverse-engineering-reality/.venv/bin/python -B -W error \
  experiments/interval_echo_collective_spin/search.py \
  --output /tmp/interval_echo_collective_spin_replay.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
  reverse-engineering-reality/.venv/bin/python -B -W error \
  experiments/interval_echo_collective_spin/binding.py \
  --output /tmp/interval_echo_collective_binding_replay.json
```

[Search executable](search.py) · [Archived receipt](results.json) · [Earlier single-ring transport experiment](../interval_echo_electron_spin/WINDING.md)
