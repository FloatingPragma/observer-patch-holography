"""Independent exhaustive Pauli-link simulation on the smallest experimental patch."""

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import expm_multiply

from geometry import edge,segments,support
from experiment import J


def local_matrices(inst):
    # Resolve the two endpoint locations after the complete 99-state pulse, keeping both coin amplitudes.
    tables = {}
    for q in (-1,1):
        for reverse in (False,True):
            start = (1,1+q) if reverse else (1+q,1)
            launch = np.kron(inst.basis,np.eye(9)[:,[inst.pairs.index(start)]])
            wave = (inst.full@launch).reshape(11,9,2)
            kraus = [inst.basis.T@wave[:,inst.pairs.index(pair),:] for pair in (start,start[::-1])]
            coin = int((q==1)!=reverse)
            idle = np.diag([-1.,-1.])
            idle[coin,coin] = 0
            moved = np.zeros((2,2))
            moved[1-coin,coin] = 1
            np.testing.assert_allclose(kraus,[idle,moved],atol=1e-13)
            if not reverse:
                tables[q] = kraus
    return tables


def replay(device,inst,record):
    edges = sorted(set().union(*(support(tile) for tile in device.tiles)))
    bits = {e:1<<i for i,e in enumerate(edges)}
    words = np.arange(1<<len(edges),dtype=np.int64)
    left,right = [],[]
    for tile in device.tiles:
        active = np.ones(len(words),dtype=bool)
        flip = 0
        for a,b in segments(tile):
            bit = bits[edge(a,b)]
            active &= ((words&bit)!=0)==(a<b)
            flip |= bit
        one = words[active]
        other = one^flip
        left.extend((one,other))
        right.extend((other,one))
    row,col = np.concatenate(left),np.concatenate(right)
    h = sparse.csr_matrix((-J*np.ones(len(row)),(row,col)),shape=(len(words),len(words)))
    assert (h-h.T).nnz==0
    # The commutator is inspected on EVERY basis transition in every Gauss sector of this patch.
    for v in sorted({v for e in edges for v in e}):
        g = np.zeros(len(words),dtype=int)
        for e,bit in bits.items():
            if v in e:
                g += (1 if v==e[0] else -1)*((words&bit)!=0)
        np.testing.assert_array_equal(g[row],g[col])
    def encode(word):
        return sum(bit for e,bit in bits.items() if word&device.bit[e])
    source = bits[device.source]
    dest = bits[device.det]
    low = words[words&source==0]
    high = low|source
    tables = local_matrices(inst)
    success = {}
    for q in (-1,0,1):
        before = []
        for root in (device.reference,device.reference^device.reverse):
            state,energy = device.ground(root)
            vacuum = np.zeros(len(words))
            for word,z in state.items():
                vacuum[encode(word)] = z
            np.testing.assert_allclose(h@vacuum,energy*vacuum,atol=1e-13)
            for op in tables[q] if q else [np.eye(2)]:
                wave = np.zeros(len(words),complex)
                wave[low],wave[high] = op@np.stack([vacuum[low],vacuum[high]])
                before.append(wave/np.sqrt(2))
        finals = expm_multiply(-4j*h,np.column_stack(before))
        weights = np.sum(abs(finals)**2,axis=1)
        assert abs(weights.sum()-1)<1e-13
        sign_measure = np.array([weights[words&dest!=0].sum(),weights[words&dest==0].sum()])
        expected = record["positive_then_negative_probe_by_time"][str(q)][3]
        np.testing.assert_allclose(sign_measure,expected,atol=1e-12)
        success[str(q)] = sign_measure.tolist()
    return {"full_link_basis_dimension":len(words),"nonzero_directed_hamiltonian_entries":h.nnz,
            "local_Gauss_commutator_nonzero_entries":0,"time":4.,"probe_crossings":success}
