"""Exact source, field and independent detector evolution in a common vertex Gauss sector."""

from collections import Counter
from functools import cache

import numpy as np
from scipy.linalg import eigh

from geometry import edge,segments,support

J = .5
TIMES = (0.,1.,2.,4.,8.,12.,16.)


class Circuit:
    def __init__(self,design,all_loops,detectors):
        tiles,bits,spare,self.source,self.det,self.arms = design
        self.detectors = detectors
        link_data = bits|spare
        assert len(link_data)==len(bits)+len(spare)
        self.tiles = tiles
        # Seen from the departing signed load, its head is present for an excess and absent for a vacancy.
        def prepare_edge(a,b,first_head):
            key = edge(a,b)
            assert key not in link_data
            link_data[key] = int(first_head if a<b else not first_head)
        for (purpose,q),(v,r,mate) in self.arms.items():
            if purpose=="outlet":
                prepare_edge(v,r,q==1)
            else:
                prepare_edge(r,v,q==1)
                prepare_edge(r,mate,q==-1)
        self.links = sorted(link_data)
        self.bit = {e:1<<i for i,e in enumerate(self.links)}
        self.reference = sum(self.bit[e]*v for e,v in link_data.items())
        self.external = [e for e in self.links if e[0]//12!=e[1]//12]
        self.reverse = sum(self.bit[e] for e in bits|spare) if spare else None
        self.checked_words = set()
        active = set(bits)
        eligible = {frozenset(support(r)) for r in all_loops if support(r)<=active}
        assert eligible=={frozenset(support(r)) for r in tiles}
        self.rings = []
        for tile in tiles:
            orbit = segments(tile)
            mask = sum(self.bit[edge(a,b)] for a,b in orbit)
            forward = sum(self.bit[edge(a,b)] for a,b in orbit if a<b)
            self.rings.append((mask,forward))
        # Compare to a fixed neutral reference, including every idle return link and battery arm.
        self.check(self.reference,{})
        if self.reverse is not None:
            self.check(self.reference^self.reverse,{})
        self.emask = self.bit[self.source]
        self.dmask = self.bit[self.det]
        assert not any((m&self.emask and m&self.dmask) for m,_ in self.rings)

    @cache
    def divergence(self,w):
        value = Counter()
        for (a,b),bit in self.bit.items():
            d = int(bool(w&bit))-int(bool(self.reference&bit))
            value[a] += d
            value[b] -= d
        return {v:x for v,x in value.items() if x}

    def check(self,w,loads):
        rho = {v:n for v,n in loads.items() if n}
        assert all(abs(n)==1 for n in rho.values())
        assert self.divergence(w)==rho
        if w not in self.checked_words:
            boundary = Counter()
            for (a,b) in self.external:
                bit = self.bit[a,b]
                flux = int(bool(w&bit))-int(bool(self.reference&bit))
                boundary[a//12] += flux
                boundary[b//12] -= flux
            cell_load = Counter()
            for v,n in rho.items():
                cell_load[v//12] += n
            assert boundary==cell_load
        self.checked_words.add(w)

    def hop(self,w,loads,q,a,b):
        bit = self.bit[edge(a,b)]
        head = bool(w&bit) if a<b else not bool(w&bit)
        assert head==(q==1) and loads.get(a,0)==q and loads.get(b,0)==0
        moved = loads.copy()
        moved[a],moved[b] = 0,q
        self.check(w^bit,moved)
        return w^bit,moved

    def battery(self,w,loads,kind,q):
        """Prepare a local physical dipole, then inject its mobile charge with a native written contact."""
        v,r,mate = self.arms[kind,q]
        assert loads.get(r,0)==loads.get(mate,0)==0
        loaded = loads.copy()
        loaded[r],loaded[mate] = q,-q
        ready = w^self.bit[edge(r,mate)]
        self.check(ready,loaded)
        return self.hop(ready,loaded,q,r,v)

    @cache
    def component(self,origin,enabled):
        states = [origin]
        ids = {origin:0}
        links = []
        for i,w in enumerate(states):
            for k in enabled:
                mask,forward = self.rings[k]
                if (w&mask) not in (forward,mask^forward):
                    continue
                target = w^mask
                assert self.divergence(w)==self.divergence(target)
                if target not in ids:
                    ids[target] = len(states)
                    states.append(target)
                j = ids[target]
                if i<j:
                    links.append((i,j))
        h = np.zeros((len(states),len(states)))
        for i,j in links:
            h[i,j] = h[j,i] = -J
        return tuple(states),h

    def ground(self,w):
        states,h = self.component(w,tuple(range(len(self.rings))))
        assert len(states)==len(self.rings)+1
        energies,modes = eigh(h)
        coeff = modes[:,0]*np.sign(modes[0,0])
        np.testing.assert_allclose(h@coeff, energies[0]*coeff,atol=1e-13)
        return dict(zip(states,coeff)),float(energies[0])

    def emit(self,initial,q,on):
        parked = {}
        for w,z in initial.items():
            loads = {}
            self.check(w,loads)
            if not q:
                parked.setdefault((),{})[w] = z
                continue
            a,b = self.source
            w,loads = self.battery(w,loads,"source",q)
            moved = on and bool(w&self.emask)==(q==1)
            if moved:
                w,loads = self.hop(w,loads,q,a,b)
                exit_port = self.arms["outlet",q][1]
                w,loads = self.hop(w,loads,q,b,exit_port)
            else:
                w,loads = self.hop(w,loads,q,a,self.arms["source",q][1])
            assert loads.get(a,0)==loads.get(b,0)==0
            # The complete native pulse has a common phase within each measured location branch.
            key = tuple(sorted((v,n) for v,n in loads.items() if n))
            branch = parked.setdefault(key,{})
            assert w not in branch
            branch[w] = z
        assert abs(sum(abs(z)**2 for state in parked.values() for z in state.values())-1)<1e-13
        return parked

    def read(self,w,loads,p):
        a,b = self.det
        self.check(w,loads)
        w,loads = self.battery(w,loads,"probe",p)
        coin = int(bool(w&self.dmask))
        result = self.detectors[p][coin,coin].real
        if coin==(p==1):
            self.hop(w,loads,p,a,b)
            assert abs(result-1)<1e-13
        else:
            self.check(w,loads)
            assert abs(result)<1e-13
        return result

    def histories(self,q,on,enabled,preparation,diagonal=0.,field_read=False):
        crossings = np.zeros((len(TIMES),2))
        flux = np.zeros((len(TIMES),len(self.external))) if field_read else None
        branch_masses = []
        if preparation=="balanced ground states":
            preparations = [self.ground(root)[0] for root in (self.reference,self.reference^self.reverse)]
        else:
            roots,_ = self.component(self.reference,tuple(range(len(self.rings))))
            assert len(roots)==len(self.rings)+1
            preparations = [{w:1.} for w in roots]  # maximally mixed on one exactly closed component
        for initial in preparations:
            for key,state in self.emit(initial,q,on).items():
                branch_masses.append(sum(abs(z)**2 for z in state.values())/len(preparations))
                unvisited = set(state)
                while unvisited:
                    words,h = self.component(min(unvisited),enabled)
                    unvisited.difference_update(words)
                    energy,modes = eigh(h+diagonal*np.diag(np.sum(h!=0,axis=1)))
                    coeff = modes.T@np.array([state.get(w,0.) for w in words])
                    wave = (np.exp(-1j*np.outer(TIMES,energy))*coeff)@modes.T
                    weights = abs(wave)**2
                    reads = np.array([[self.read(w,dict(key),p) for p in (1,-1)] for w in words])
                    crossings += weights@reads/len(preparations)
                    if field_read:
                        values = [[int(bool(w&self.bit[e]))-int(bool(self.reference&self.bit[e]))
                                   for e in self.external] for w in words]
                        flux += weights@np.array(values)/len(preparations)
        assert abs(sum(branch_masses)-1)<1e-13
        np.testing.assert_allclose(crossings.sum(axis=1),1,atol=2e-12,rtol=0)
        return (crossings,flux) if field_read else crossings

    def test(self,preparation,diagonal=0.):
        enabled = tuple(range(len(self.rings)))
        measured = {q:self.histories(q,True,enabled,preparation,diagonal,True) for q in (1,0,-1)}
        data = {q:row[0] for q,row in measured.items()}
        signal = measured[1][1]-measured[0][1]
        np.testing.assert_allclose(signal,measured[0][1]-measured[-1][1],atol=1e-13)
        np.testing.assert_allclose(signal[0],0,atol=1e-13)
        assert np.max(abs(signal))>1e-4
        np.testing.assert_allclose(data[0]-data[0][0],0,atol=1e-13)
        np.testing.assert_allclose(data[1][0],data[0][0],atol=1e-13)
        np.testing.assert_allclose(data[1]-data[0],data[0]-data[-1],atol=1e-13)
        assert max(abs(data[1][:,0]-data[0][:,0]))>1e-4
        prediction = None
        if preparation=="mixed component":
            dim = len(enabled)+1
            path = -J*(np.eye(dim,k=1)+np.eye(dim,k=-1))
            path += diagonal*np.diag([1]+[2]*(dim-2)+[1])
            energy,modes = eigh(path)
            transfer = np.exp(-1j*np.outer(TIMES,energy))@(modes[-1]*modes[0])
            prediction = abs(transfer)**2/dim
            np.testing.assert_allclose(abs(data[1][:,0]-data[0][:,0]),prediction,atol=1e-13)
            if diagonal==0:
                np.testing.assert_allclose(energy,-2*J*np.cos(np.pi*np.arange(1,dim+1)/(dim+1)),atol=1e-13)
        cuts = []
        for skip in enabled:
            cut = tuple(k for k in enabled if k!=skip)
            sham = self.histories(0,True,cut,preparation,diagonal)
            delta = max(float(np.max(abs(self.histories(q,True,cut,preparation,diagonal)-sham))) for q in (-1,1))
            # Removing the source ring can leave its neighbouring ring aware of shared flux
            # through the initially correlated ground state, but an unconditioned intervention
            # on its private source edge cannot alter that remote marginal.
            assert delta<1e-12
            cuts.append(delta)
        closed = max(float(np.max(abs(self.histories(q,False,enabled,preparation,diagonal)-data[0]))) for q in (-1,1))
        assert closed<1e-12
        return {"preparation":preparation,"flippable_ring_diagonal_energy":diagonal,
                "initial_component_dimension":len(enabled)+1,
                "positive_then_negative_probe_by_time":{str(q):v.tolist() for q,v in data.items()},
                "independent_path_prediction_absolute_probe_shift":None if prediction is None else prediction.tolist(),
                "excess_minus_sham_oriented_external_flux_by_time":signal.tolist(),
                "cut_each_ring_max_response_from_sham":cuts,"blocked_source_max_response_from_sham":closed,
                "absolute_Gauss_residual_every_reached_configuration":0,
                "audited_distinct_field_and_instrument_words_cumulative":len(self.checked_words)}
