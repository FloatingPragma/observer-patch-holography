"""Construct gauge-preserving loops from the registered port and cell graphs."""

from collections import Counter

import networkx as nx

from model.executable_model import cell


def canonical(cycle):
    start = min(cycle)
    versions = []
    for seq in (list(cycle),list(reversed(cycle))):
        i = seq.index(start)
        versions.append(tuple(seq[i:]+seq[:i]))
    return min(versions)


def segments(cycle):
    return list(zip(cycle,(*cycle[1:],cycle[0])))


def edge(a,b):
    return tuple(sorted((a,b)))


def support(cycle):
    return {edge(a,b) for a,b in segments(cycle)}


def catalog(board):
    gates = {}
    for a,b in board.external:
        gates[a//12,b//12],gates[b//12,a//12] = a,b
    dual = nx.Graph(sorted(gates))
    ok,embedding = nx.check_planarity(dual)
    assert ok
    seen = set()
    faces = []
    for a in sorted(dual):
        for b in embedding.neighbors_cw_order(a):
            if (a,b) not in seen:
                faces.append(canonical(embedding.traverse_face(a,b,seen)))
    local = nx.Graph(cell().seams)
    def lift(face):
        result = []
        for i,home in enumerate(face):
            start = gates[home,face[i-1]]%12
            end = gates[home,face[(i+1)%len(face)]]%12
            # Use one undirected shortest route for this gateway pair in both incident faces.
            path = min(nx.all_shortest_paths(local,min(start,end),max(start,end)))
            if path[0]!=start:
                path = path[::-1]
            result.extend(12*home+x for x in path)
        return canonical(result)
    rings = [lift(f) for f in sorted(faces)]
    triangles = list(map(tuple,board.faces()))
    all_edges = set(board.seams)
    for loop in [*triangles,*rings]:
        assert len(loop)==len(set(loop)) and support(loop)<=all_edges
    external_count = Counter(e for r in rings for e in support(r) if e[0]//12!=e[1]//12)
    assert set(external_count)==set(board.external) and set(external_count.values())=={2}
    # No shorter cross-cell simple cycle can traverse a single external edge twice.
    # Exhaustively get the length of the shortest simple cycle through every external seam.
    graph = nx.Graph(board.seams)
    lengths = Counter()
    for a,b in board.external:
        graph.remove_edge(a,b)
        lengths[1+nx.shortest_path_length(graph,a,b)] += 1
        graph.add_edge(a,b)
    return triangles,rings,dual,{"internal_triangles":len(triangles),"lifted_cell_faces":len(rings),
            "cells_per_lift_histogram":dict(sorted(Counter(map(len,faces)).items())),
            "links_per_lift_histogram":dict(sorted(Counter(map(len,rings)).items())),
            "shortest_cycle_through_each_external_link_histogram":dict(sorted(lengths.items())),
            "external_seams_covered_twice":len(external_count)}


def oriented_band(tiles):
    """Adjacent face orientations disagree on their common edge. Orient that edge for the earlier face."""
    result = [tuple(tiles[0])]
    for tile in tiles[1:]:
        overlap = support(result[-1])&support(tile)
        shared = min(overlap)
        tail,head = shared
        if (tail,head) not in segments(result[-1]):
            tail,head = head,tail
        if (tail,head) in segments(tile):
            tile = tuple(reversed(tile))
        assert (head,tail) in segments(tile)
        assert all((v,u) in segments(tile) for u,v in segments(result[-1]) if edge(u,v) in overlap)
        result.append(tile)
    bits = {}
    for tile in result:
        for a,b in segments(tile):
            bits.setdefault(edge(a,b),int(a<b))   # head at the tail; both conventions work for a closed curl
    return result,bits


def complete_circulation(board,bits,banned):
    """Extend the prepared directed arrows to a divergence-free circulation using idle spectator links."""
    imbalance = Counter()
    for (a,b),c in bits.items():
        tail,head = (a,b) if c else (b,a)
        imbalance[tail] += 1
        imbalance[head] -= 1
    allowed = sorted(set(board.seams)-bits.keys()-set(banned))
    # An integral min-cost unit flow on unused undirected links closes the orientation. Positive
    # costs eliminate two opposed uses of a link. Only the cells touched by the band are needed.
    homes = {v//12 for e in bits for v in e}
    graph = nx.DiGraph()
    for a,b in allowed:
        if a//12 in homes and b//12 in homes:
            graph.add_edge(a,b,capacity=1,weight=1)
            graph.add_edge(b,a,capacity=1,weight=1)
    for v,amount in imbalance.items():
        graph.add_node(v,demand=amount)
    flow = nx.min_cost_flow(graph)
    extra = {edge(a,b):int(a<b) for a,neighbors in flow.items() for b,k in neighbors.items() if k}
    all_bits = bits|extra
    difference = Counter()
    for (a,b),c in all_bits.items():
        difference[a] += 2*c-1
        difference[b] -= 2*c-1
    assert all(v==0 for v in difference.values())
    return extra


def stations(board,band,src,det):
    """Reserve distinct native marked arms for each input sign and for source evacuation."""
    used = {v for r in band for v in r}
    reserved = set()
    def options(v):
        return [x for x in board.neighbours[v] if x//12==v//12 and x not in used|reserved]
    demands = [(src[0],"source"),(src[1],"outlet"),(det[0],"probe")]
    # Search the small local inventory, including a spectator for each oppositely charged reservoir.
    def assign(tasks,entries):
        if not tasks:
            return entries
        v,label,q = tasks[0]
        for r in options(v):
            reserved.add(r)
            mates = options(r) if label!="outlet" else [None]
            for mate in mates:
                if mate is not None:
                    reserved.add(mate)
                result = assign(tasks[1:],{**entries,(label,q):(v,r,mate)})
                if result is not None:
                    return result
                if mate is not None:
                    reserved.remove(mate)
            reserved.remove(r)
        return None
    return assign([(v,label,q) for v,label in demands for q in (-1,1)],{})


def fixtures(board,triangles,rings,dual,home,bridge_count=1):
    local = {}
    for t in triangles:
        local.setdefault(t[0]//12,[]).append(t)
    possible = [r for r in rings if any(v//12==home for v in r)]
    ring_edges = {r:support(r) for r in rings}
    def extend(path):
        if len(path)==bridge_count:
            yield path
            return
        previous = set().union(*(ring_edges[r] for r in path[:-1]))
        for nxt in sorted(rings,key=lambda r:(len(r),r)):
            if nxt in path or previous&ring_edges[nxt]:
                continue
            if ring_edges[nxt]&ring_edges[path[-1]] and home not in {v//12 for v in nxt}:
                yield from extend(path+[nxt])
    paths = (p for r in sorted(possible,key=lambda r:(len(r),r)) for p in extend([r]))
    for path in paths:
        rim = set.union(*(ring_edges[r] for r in path))
        past_cells = {v//12 for r in path[:-1] for v in r}
        receivers = sorted({v//12 for v in path[-1]}-past_cells-{home},
                           key=lambda h:(-nx.shortest_path_length(dual,home,h),h))
        for dest in receivers:
            for first in local[home]:
                if len(support(first)&rim)!=1:
                    continue
                for last in local[dest]:
                    if len(support(last)&rim)!=1:
                        continue
                    band,bits = oriented_band([first,*path,last])
                    for src in sorted(support(first)-rim):
                        for det in sorted(support(last)-rim):
                            arms = stations(board,band,src,det)
                            if arms is None:
                                continue
                            banned = {edge(v,r) for v,r,m in arms.values()}|{edge(r,m) for v,r,m in arms.values() if m is not None}
                            spare = {}
                            if bridge_count==1:
                                try:
                                    spare = complete_circulation(board,bits,banned)
                                except nx.NetworkXUnfeasible:
                                    continue
                            return band,bits,spare,src,det,arms
    raise ValueError(f"No closed prepared band found from cell {home}")
