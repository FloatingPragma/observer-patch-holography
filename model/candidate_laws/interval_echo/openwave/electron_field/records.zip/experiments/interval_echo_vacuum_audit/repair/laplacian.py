"""Test positive local Laplacians with the previously measured hop amplitudes."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys

import networkx as nx
import numpy as np
from scipy import sparse
from scipy.sparse.csgraph import connected_components

HERE = Path(__file__).resolve().parent
EXPERIMENTS = HERE.parents[1]
sys.path.insert(0, str(EXPERIMENTS / "interval_echo_pair_threshold"))
from threshold import Guide, Instrument, federation, local_columns, lowest, pair_hamiltonian, physical_basis
from geometry import catalog, edge, support


def graph_laplacian(h):
    off = sparse.csr_matrix(h, dtype=float).copy()
    off.setdiag(0)
    off.eliminate_zeros()
    assert not np.any(off.data >= 0) and (off != off.T).nnz == 0
    lap = off + sparse.diags(-np.asarray(off.sum(axis=1)).ravel(), format="csr")
    np.testing.assert_array_equal(lap @ np.ones(lap.shape[0]), 0)
    return lap


def energy_result(matrix, distances):
    energy, mode = lowest(matrix)
    distance = int(max(distances))
    separated = np.flatnonzero(distances == distance)
    restricted, _ = lowest(matrix[separated][:, separated])
    return {"formation_energy": energy, "maximum_minimum_cell_steps": distance,
            "separation_restricted_formation_energy_at_maximum": restricted,
            "ground_weight_at_maximum_separation": float(mode[separated] @ mode[separated])}


def snapshot(board, fixture, coupling, instrument, coefficients):
    guide = Guide(fixture, board, coupling)
    _neutral_basis, neutral, _ = guide.sector(0, instrument)
    basis = physical_basis(guide, exhaustive=False)
    original, _ = pair_hamiltonian(guide, basis, coefficients)
    p, m, _ = zip(*basis)
    gp, gm = 6-board.degree[list(p)], 6-board.degree[list(m)]
    assert set(original.data[original.data < 0]) >= {-coupling, -4.0}
    neutral_lap = graph_laplacian(neutral)
    kinetic = graph_laplacian(original)
    assert connected_components(kinetic, directed=False)[0] == 1
    assert connected_components(neutral_lap, directed=False)[0] == 1
    # Connection differences of signed heads determine every allowed matter/field move.
    cell_graph = nx.Graph((i//12, j//12) for i,j in board.external)
    lengths = dict(nx.all_pairs_shortest_path_length(cell_graph))
    distances = np.array([lengths[x//12][y//12] for x, y in zip(p, m)])
    refs = {}
    for r in (0, 1):
        potential = 8*((3-2*r)*gp + (-1+2*r)*gm)
        matrix = kinetic + sparse.diags(potential, dtype=float, format="csr")
        refs[str(r)] = energy_result(matrix, distances)
    far = np.flatnonzero(distances == max(distances))
    kin_floor, _ = lowest(kinetic[far][:,far])
    return {"cells":board.cells, "active_links":len(guide.edges), "field_loops":len(guide.rings),
            "neutral_states":neutral_lap.shape[0], "pair_states":len(basis), "neutral_ground":0,
            "retaining_original_written_link_offset_neutral_energy_above_cleared":8*len(guide.edges),
            "kinetic_only_pair_ground":0, "kinetic_only_separated_floor":kin_floor,
            "reference_comparisons":refs}


def separated_string(board, instrument, contact):
    """Give an exact separated-pair energy ceiling on the full graph for both reference settings."""
    graph = nx.Graph(board.seams)
    gateway = int(np.flatnonzero(board.degree == 6)[0])
    distances = nx.single_source_shortest_path_length(graph, gateway)
    other = max((i for i in distances if board.degree[i] == 6), key=lambda i: (distances[i], -i))
    path = nx.shortest_path(graph, gateway, other)
    links = {edge(a, b) for a, b in zip(path, path[1:])}
    triangles, rings, _, _ = catalog(board)
    assert not any(support(loop) <= links for loop in [*triangles, *rings])
    delta = np.zeros(board.n, dtype=int)
    load = np.ones(board.n, dtype=int)
    load[gateway], load[other] = 2, 0
    sharp_energy = 0
    for before, after in zip(path, path[1:]):
        a, b = edge(before, after)
        # Head moves from successor to predecessor relative to the neutral oriented string.
        delta[before] += 1
        delta[after] -= 1
        head = int(before == a)
        index = 9*head + instrument.pairs.index((load[a], load[b]))
        sharp_energy += int(contact[index, index])
    np.testing.assert_array_equal(delta, load-1)
    assert sharp_energy == 8 and set(board.degree[[gateway, other]]) == {6}
    return {"cells":board.cells, "two_gateway_addresses": [gateway, other], "port_steps":len(links),
            "neutral_energy_above_cleared":0, "all_eligible_field_loops_within_string":0,
            "sharp_pair_rayleigh_quotient_above_K0_ground_both_references":sharp_energy}


def run():
    fixture_file = EXPERIMENTS / "interval_echo_gauge_loops" / "results.json"
    stored = json.loads(fixture_file.read_text())
    inst = Instrument()
    coefficients = local_columns(inst)
    # The original absolute written contact already is a Laplacian on enabled swaps.
    # Every idle state stays eight units higher than its repaired diagonal.
    embed = np.kron(inst.basis, np.eye(9))
    absolute = np.rint(embed.T @ (inst.h8/8) @ embed).astype(int)
    lap = graph_laplacian(absolute).toarray()
    np.testing.assert_array_equal(np.triu(absolute,1), np.triu(lap,1))
    enabled = np.any(absolute < 0, axis=1)
    np.testing.assert_array_equal(np.diag(absolute-lap), 8*(~enabled))
    boards, strings = [], []
    for level, fixtures in enumerate(stored["boards"]):
        board = federation(level)
        boards.extend(snapshot(board, f, stored["loop_hopping"], inst, coefficients)
                      for f in fixtures["fixtures"][:3])
        strings.append(separated_string(board, inst, lap))
    return {"candidate_revision": stored["candidate_revision"], "signed_contact_hop":-4,
            "signed_ring_hop":-stored["loop_hopping"], "local_written_contact_states": len(enabled),
            "native_diagonal_retained_on_enabled_states":int(np.sum(enabled)),
            "native_eight_unit_diagonal_removed_on_idle_states":int(np.sum(~enabled)),
            "repair_code_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
            "gauge_fixture_sha256": sha256(fixture_file.read_bytes()).hexdigest(), "guides": boards,
            "simple_string_trials": strings}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    content = json.dumps(run(), indent=2, allow_nan=False) + "\n"
    with args.output.open("x", encoding="utf-8") as out:
        out.write(content)
