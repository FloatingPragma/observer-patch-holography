"""Field-only release under the repaired contact pulse and repaired unshielded loop Hamiltonian."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys

import numpy as np
from scipy.linalg import expm

HERE = Path(__file__).resolve().parent
EXPERIMENTS = HERE.parents[1]
WHOLE = EXPERIMENTS / "interval_echo_independent_transport"
sys.path.insert(0, str(WHOLE))
from laplacian import Instrument, federation, graph_laplacian
from oracle import local_matrices
from release import measure
from sphere import Sector, Sphere


class LaplacianSector:
    """Retain the physical state labels and cuts, adding each enabled ring's local diagonal."""
    def __init__(self, original):
        self.original = original
        self.words = original.words
        self.flipped = original.flipped
        self.h = self.hamiltonian()

    def hamiltonian(self, cut=()):
        return graph_laplacian(self.original.hamiltonian(cut))


def pulse_oracle(original):
    """Compare both post-contact instruments on all inputs within the measured head subspace."""
    embed = np.kron(original.basis, np.eye(9))
    h_native = original.h8/8
    block = np.rint(embed.T @ h_native @ embed).astype(int)
    np.testing.assert_allclose(h_native @ embed, embed @ block, atol=2e-13)
    lap = graph_laplacian(block).toarray()
    h_new = h_native + embed @ (lap-block) @ embed.T
    full = expm(-1j*np.pi/8*h_new)
    original_tables = local_matrices(original)
    rows = []
    for q in (-1, 0, 1):
        for reverse in (False, True):
            start = (1, 1+q) if reverse else (1+q, 1)
            launch = np.kron(original.basis, np.eye(9)[:, [original.pairs.index(start)]])
            native = (original.full @ launch).reshape(11,9,2)
            repair = (full @ launch).reshape(11,9,2)
            target_loads = (start, start[::-1]) if q else (start,)
            effects = []
            residual = 0.
            for i, pair in enumerate(target_loads):
                pos = original.pairs.index(pair)
                left = original.basis.T @ native[:, pos, :]
                right = original.basis.T @ repair[:, pos, :]
                np.testing.assert_allclose(repair[:, pos, :], original.basis @ right, atol=2e-13)
                if q and not reverse:
                    np.testing.assert_allclose(left, original_tables[q][i], atol=2e-13)
                # The entire stay Kraus operator reverses sign. A move keeps its amplitude.
                np.testing.assert_allclose(right, left if i else -left, atol=2e-13)
                effects.append(right.conj().T @ right)
                delta = np.kron(right.conj(), right) - np.kron(left.conj(), left)
                residual = max(residual, float(np.max(abs(delta))))
            np.testing.assert_allclose(sum(effects), np.eye(2), atol=2e-13)
            rows.append({"source_sign":q, "launch_far_endpoint":reverse, "stay_phase_relative_to_original":-1,
                         "move_phase_relative_to_original":1 if q else None,
                         "complete_position_resolved_coin_channel_residual":residual})
    return rows


def run():
    previous = json.loads((WHOLE / "results.json").read_text())
    instrument = Instrument()
    pulse = pulse_oracle(instrument)
    cases = []
    for level in (1, 2):
        order = "depth-first within shell"
        sphere = Sphere(federation(level), order)
        original = Sector(sphere)
        legal_transitions = original.verify_native_moves(sphere)
        sector = LaplacianSector(original)
        np.testing.assert_array_equal(sector.h.diagonal(), -np.asarray(original.h.sum(axis=1)).ravel())
        # The pulse oracle proves equality of each resolved CP map for all input heads.
        # This allows the established independent source/parking/probe protocol to be reused intact.
        results = measure(sphere, sector, instrument)
        old = next(row for row in previous["cases"] if row["cells"] == sphere.board.cells
                   and row["orientation_order"] == order)
        assert old["state_count"] == results["state_count"]
        assert [row["detector"] for row in results["station_records"]] == [
            tuple(row["detector"]) for row in old["station_records"]]
        cases.append({"cells":sphere.board.cells, "legal_directed_offdiagonal_moves":legal_transitions,
                      "unmasked_cross_cell_faces":sphere.n, "exterior":sphere.exterior_check(),
                      "largest_previous_above_threshold_distance":old["maximum_above_threshold_cell_distance"],
                      "previous_stations_at_threshold": old["faces_reaching_sample_threshold"], **results})
    return {"candidate_revision":previous["candidate_revision"],
            "original_field_receipt_sha256":sha256((WHOLE / "results.json").read_bytes()).hexdigest(),
            "repair_sha256":sha256((HERE / "laplacian.py").read_bytes()).hexdigest(),
            "flight_sha256":sha256(Path(__file__).read_bytes()).hexdigest(),
            "position_resolved_pulse_comparisons":pulse, "cases":cases}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    content = json.dumps(run(), indent=2, allow_nan=False) + "\n"
    with args.output.open("x", encoding="utf-8") as out:
        out.write(content)
