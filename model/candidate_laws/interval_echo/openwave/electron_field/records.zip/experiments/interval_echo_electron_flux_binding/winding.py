"""Measure controlled winding and field proximity on the same stationary charged modes."""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path

import networkx as nx
import numpy as np

from search import Patch, charged_sector, lowest
from model.candidate_laws.interval_echo.openwave.electron_field.flux_string.search import around


def perimeters(patch):
    for face_index, root in enumerate(patch.faces):
        disk = [f for f in patch.faces if set(f) & set(root)]
        edges = Counter(tuple(sorted(e)) for f in disk for e in around(f))
        cycle, = nx.cycle_basis(nx.Graph(sorted(e for e, n in edges.items() if n == 1)))
        assert len(disk) == 10 and len(cycle) == 6
        yield face_index, min(tuple(seq[i:]+seq[:i]) for seq in (cycle, cycle[::-1]) for i in range(6))


def winding_records(patch, states, positions, vectors, sign):
    index = {state: i for i, state in enumerate(states)}
    for face, perimeter in perimeters(patch):
        mask, oriented = patch.orientation(perimeter)
        for cycle in (perimeter, perimeter[::-1]):
            for k in range(len(cycle)):
                path = cycle[k:] + cycle[:k]
                start = path[0]
                steps = [tuple(sorted(edge)) for edge in around(path)]
                launch = np.flatnonzero(positions == start)
                end = []
                categories = []
                for i in launch:
                    p, w = states[i]
                    for e in steps + steps[-2::-1]:
                        p, w = patch.move(p, w, e, sign)
                    if p != start:
                        categories.append('away')
                    elif w == states[i][1]:
                        categories.append('idle')
                    else:
                        assert (w ^ states[i][1]) == mask and w & mask in (oriented, oriented ^ mask)
                        categories.append('wind')
                    end.append(index[p,w])
                categories = np.array(categories)
                start_wave = vectors[launch]
                end_wave = vectors[np.array(end)]
                wind = categories == 'wind'
                if not np.any(wind):
                    continue
                source_weight = np.sum(start_wave**2, axis=0)
                winding_weight = np.sum(start_wave[wind]**2, axis=0)
                winding_overlap = np.sum(start_wave[wind] * end_wave[wind], axis=0)
                idle_weight = np.sum(start_wave[categories == 'idle']**2, axis=0)
                assert np.all(abs(winding_overlap) <= winding_weight + 1e-11)
                # The heralded input occupies one port only. Away endpoints have no overlap with the reference.
                inclusive_bright = 1 - source_weight/2 + (idle_weight + winding_overlap)/2
                ratios = np.divide(winding_overlap, winding_weight, out=np.zeros_like(winding_weight),
                                   where=winding_weight > 1e-14)
                for i in range(vectors.shape[1]):
                    yield i, {'root_face': face, 'ordered_tour': list(path),
                              'source_port_weight': float(source_weight[i]),
                              'unconditional_winding_weight': float(winding_weight[i]),
                              'winding_signed_overlap': float(winding_overlap[i]),
                              'winding_conditional_amplitude': float(ratios[i]) if winding_weight[i] > 1e-14 else None,
                              'inclusive_bright_with_quiet_nonlaunch': float(inclusive_bright[i])}


def run():
    patch = Patch()
    report = []
    for sign in (-1, 1):
        h, states, positions = charged_sector(patch, sign)
        levels, vec, groups, residual = lowest(h)
        assert all(len(g) == 1 for g in groups)
        assert np.min(vec[:,0] * np.sign(vec[0,0])) > 0
        modes = [[] for level in levels]
        for i, record in winding_records(patch, states, positions, vec, sign):
            modes[i].append(record)
        grouped = []
        for level, reads in zip(levels, modes):
            reads = [r for r in reads if r['winding_conditional_amplitude'] is not None]
            negative = [r for r in reads if r['winding_conditional_amplitude'] < -1e-8]
            grouped.append({'native_energy': float(level), 'settings_with_resolved_winding': len(reads),
                            'settings_with_negative_winding': len(negative),
                            'minimum_conditional_amplitude': min(reads, key=lambda r: r['winding_conditional_amplitude']),
                            'most_negative_absolute_overlap': min(reads, key=lambda r: r['winding_signed_overlap']),
                            'largest_negative_branch_weight': max(negative, key=lambda r: r['unconditional_winding_weight']) if negative else None})
        assert grouped[0]['settings_with_negative_winding'] == 0
        report.append({'sign': sign, 'states': len(states), 'max_residual': residual, 'modes': grouped})
    return {'seed': patch.seed, 'charge_sectors': report}


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    target = p.parse_args().output
    result = run()
    with target.open('x') as f:
        json.dump(result, f, indent=2, allow_nan=False)
        f.write('\n')
