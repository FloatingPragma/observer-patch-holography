"""Stationary proximity of ring energy and charge, including an independent-marginal control."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from energy_locality import field_flips
from search import Patch, charged_sector, lowest


def run():
    patch = Patch()
    sectors = []
    for sign in (-1, 1):
        h, states, positions = charged_sector(patch, sign)
        levels, vectors, groups, residual = lowest(h)
        left, right, faces, incident = field_flips(patch, states)
        entries = []
        for indices in groups:
            v = vectors[:, indices]
            weights = 0.5*np.mean(abs(v[left]-v[right])**2, axis=1)
            by_face = np.bincount(faces, weights=weights, minlength=len(patch.faces))
            probability = np.bincount(positions, weights=np.mean(abs(v)**2, axis=1), minlength=12)
            np.testing.assert_allclose(probability.sum(), 1., atol=1e-12)
            total = by_face.sum()
            assert total > 1e-10
            actual = np.sum(weights*incident)/total
            independent = sum(energy * probability[list(face)].sum() for energy, face in zip(by_face, patch.faces))/total
            entries.append({'native_energy': float(levels[indices[0]]), 'multiplicity': len(indices),
                            'total_ring_energy': float(total), 'charge_port_probabilities': probability.tolist(),
                            'effective_number_of_charge_ports': float(1/(probability @ probability)),
                            'ring_energy_by_face': by_face.tolist(), 'incident_fraction': float(actual),
                            'independent_marginal_fraction': float(independent),
                            'correlated_excess_fraction': float(actual - independent)})
        sectors.append({'sign': sign, 'states': len(states), 'max_eigenpair_residual': residual, 'levels': entries})
    return {'seed': patch.seed, 'face_ports': patch.faces, 'charge_sectors': sectors}


if __name__ == '__main__':
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument('--output', type=Path, required=True)
    path = args.parse_args().output
    record = run()
    with path.open('x') as stream:
        json.dump(record, stream, indent=2, allow_nan=False)
        stream.write('\n')
