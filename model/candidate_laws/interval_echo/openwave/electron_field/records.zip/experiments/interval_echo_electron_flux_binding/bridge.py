"""Exchange over an actual cell seam with an independently prepared neutral field."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.sparse import csgraph

from search import Patch, charged_sector, lowest
from model.executable_model import federation, rotations


def matched_bridge():
    board = federation(0)
    routes = []
    for a,b in board.external:
        if a >= 12:
            continue
        for perm in rotations():
            start = (b//12)*12
            if perm[a] == b % 12 and np.array_equal(board.degree[start + np.array(perm)], board.degree[:12]):
                routes.append((a,b,perm))
    assert len(routes) == 1
    return routes[0]


def rigid_map(patch, perm):
    edges = []
    for (a,b), bit in patch.bit.items():
        x,y = perm[a], perm[b]
        edges.append((bit, patch.bit[tuple(sorted((x,y)))], x>y))
    def transform(w):
        return sum(dest for src,dest,reverse in edges if bool(w & src) != reverse)
    return transform


def gauss_checks(patch, states, gateway, perm, sign):
    trans = rigid_map(patch, perm)
    # Check every active destination move in physical port coordinates; this gives an exact permutation conjugacy.
    words = {w for _,w in states}
    mapped = {w:trans(w) for w in words}
    assert len(set(mapped.values())) == len(words)
    for w in words:
        assert {mapped[x] for _,x in patch.ring_moves(w)} == {x for _,x in patch.ring_moves(mapped[w])}
    for p,w in states:
        assert {(perm[x], mapped[v]) for x,v in patch.charge_moves(p,w,sign)} == set(patch.charge_moves(perm[p], mapped[w], sign))
    def div(w):
        values = np.zeros(12, dtype=int)
        for (a,b), bit in patch.bit.items():
            values[a if w & bit else b] += 1
        return values
    divergence = {w:div(w) for w in words}
    anchor = patch.faces[0][0]
    unit = np.eye(12, dtype=int)
    reference = divergence[patch.seed]
    neutral, = {tuple(divergence[w]) for p,w in states if p == gateway}
    for p,w in states:
        np.testing.assert_array_equal(divergence[w]-reference, sign * (unit[p]-unit[anchor]))
        np.testing.assert_array_equal(divergence[w]-neutral, sign * (unit[p]-unit[gateway]))
    # The transmitting bridge loses one signed head on the sending side and gains one on the receiving side.
    # The injected source and distant compensation leave +sign at the original anchor.
    assert np.array_equal(np.asarray(neutral)-reference + sign*unit[anchor]-sign*unit[gateway], np.zeros(12))
    compensation = patch.compensator(anchor, sign)
    assert compensation[-1]//12 not in (0, 4)
    return {'states_checked':len(states), 'distinct_field_words_rotated':len(words),
            'sending_compensator_ports': list(compensation), 'local_seed_port': anchor,
            'charged_divergence_relative_to_neutral_at_same_gateway_verified': True,
            'exact_rotated_material_and_ring_transition_conjugacy': True}


def setups():
    patch = Patch()
    g, receiving_port, perm = matched_bridge()
    for sign in (-1,1):
        h, states, ports = charged_sector(patch, sign)
        levels, vectors, groups, residual = lowest(h)
        vectors = vectors[:,:2]
        # Fix the otherwise arbitrary eigenvector sign for the real projected matrix element.
        vectors *= np.sign(vectors[np.argmax(abs(vectors),axis=0),np.arange(2)])
        idx = np.flatnonzero(ports==g)
        assert np.array_equal(ports[idx], np.full(len(idx),g))
        neutral_h = h[idx][:,idx].copy()
        neutral_h.setdiag(0)
        neutral_h.eliminate_zeros()
        assert np.all(neutral_h.data == -1)
        neutral_h = csgraph.laplacian(-neutral_h, normed=False).tocsr()
        n = np.ones(len(idx))/np.sqrt(len(idx))
        assert np.max(abs(neutral_h@n)) < 1e-13
        yield patch, sign, g, receiving_port, perm, h, states, ports, idx, neutral_h, levels, vectors, n


def run():
    out = []
    for patch, s, g, b, perm, h, states, ports, idx, nh, energies, vec, n in setups():
        checks = gauss_checks(patch, states, g, perm, s)
        weights = (vec[idx]**2).sum(axis=0)
        overlaps = n @ vec[idx]
        rows = []
        for i in range(2):
            # After a full isolated hop, the right charged register is a fresh load at g and its original field n.
            # The sending cell holds the port-g slice of the source field.
            transferred = np.outer(n, vec[idx,i])
            arrival = np.sum(transferred**2)
            left_failed_probability = np.sum(vec[ports != g,i]**2)
            np.testing.assert_allclose(arrival+left_failed_probability, 1, atol=1e-12)
            targets = []
            for j in range(2):
                recovered = vec[idx,j] @ transferred
                all_right = float(recovered @ recovered)
                full = float((n @ recovered)**2)
                np.testing.assert_allclose([all_right, full],
                    [weights[i]*overlaps[j]**2, (overlaps[i]*overlaps[j])**2], atol=1e-14)
                targets.append({'destination_level': j, 'right_whole_eigenmode_probability_left_unread': all_right,
                                'full_exchanged_product_probability': full,
                                'right_mode_probability_given_charge_arrival': all_right/arrival,
                                'full_product_probability_given_charge_arrival': full/arrival,
                                'projected_bridge_hamiltonian_native': float(-4*overlaps[i]*overlaps[j]),
                                'upper_bound_with_arbitrary_separate_prepared_and_read_field_states': float(weights[i]*weights[j])})
            returned = transferred.T
            np.testing.assert_allclose(returned, np.outer(vec[idx,i],n), atol=0)
            rows.append({'source_level':i,'native_energy':float(energies[i]),'charge_arrival':float(arrival),
                         'initial_gateway_weight':float(weights[i]),'uniform_field_gateway_overlap':float(overlaps[i]),
                         'receiver_targets':targets,'two_full_pulses_recover_input_probability':1.,
                         'bridge_off_arrival_and_product_probabilities':0.})
        out.append({'sign':s, 'physical_gateway_ports':[g,b], 'proper_port_permutation':list(perm),
                    'charged_sector_dimension':len(states), 'neutral_sector_dimension':len(idx),
                    'exact_source_destination_isospectrality':True, 'gauss_checks':checks, 'transfers':rows})
    return {'neutral_field': 'uniform conditional head state at the matched portal', 'native_contact_time':'pi/8',
            'conditioned_right_state_after_single_bridge_pulse':'fixed load at gateway times independently prepared right field',
            'charge_sectors':out}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    target=parser.parse_args().output
    result=run()
    with target.open('x') as f:
        json.dump(result,f,indent=2,allow_nan=False)
        f.write('\n')
