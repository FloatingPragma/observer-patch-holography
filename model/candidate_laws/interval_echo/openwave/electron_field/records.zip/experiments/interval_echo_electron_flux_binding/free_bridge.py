"""Free two-cell transport with all internal contacts, all internal faces and one bridge open."""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from scipy.special import jv

from bridge import setups


def hamiltonian_action(h, nh, gateway, left, right):
    # Arrays put the charged cell first and the neutral one second on both sides.
    diff = 4 * (left[gateway] - right[gateway].T)
    a = (h @ left + (nh @ left.T).T)/2.
    b = (h @ right + (nh @ right.T).T)/2.
    a[gateway] += diff
    b[gateway] -= diff.T
    return a, b


def free_flight(h, nh, gateway, source, times):
    # The spectrum is nonnegative. Absolute row sums bound each cell term, and the bridge norm is eight.
    scale = (float(abs(h).sum(axis=1).max() + abs(nh).sum(axis=1).max())/2 + 8)/2
    z = scale * np.array(times)
    k = 1
    majorant = float(z.max())/2
    while k <= z.max() or 2*majorant/(1-z.max()/(2*(k+1))) > 1e-13:
        k += 1
        majorant *= z.max()/(2*k)
    tail = float(2*majorant/(1-z.max()/(2*(k+1))))
    old_left = source
    old_right = np.zeros_like(source)
    cur_left, cur_right = hamiltonian_action(h, nh, gateway, old_left, old_right)
    cur_left = cur_left/scale - old_left
    cur_right = cur_right/scale
    outputs = [(jv(0,t)*source.astype(complex), np.zeros_like(source,dtype=complex)) for t in z]
    for n in range(1,k):
        for t, (out_l, out_r) in zip(z, outputs):
            coefficient = 2*(-1j)**n*jv(n,t)
            out_l += coefficient*cur_left
            out_r += coefficient*cur_right
        if n == k-1:
            break
        new_l, new_r = hamiltonian_action(h, nh, gateway, cur_left, cur_right)
        new_l = 2/scale*new_l - 2*cur_left - old_left
        new_r = 2/scale*new_r - 2*cur_right - old_right
        old_left, old_right, cur_left, cur_right = cur_left, cur_right, new_l, new_r
    return outputs, {'upper_spectrum_bound_native':2*scale,'chebyshev_highest_degree':k-1,
                     'operator_norm_series_tail_bound':tail}


def run():
    sectors = []
    times = [np.pi/8, np.pi/4]
    for patch, sign, g, b, perm, h, states, ports, idx, nh, energies, vec, neutral in setups():
        entries = []
        for i, source_mode in enumerate(vec.T):
            source = np.outer(source_mode, neutral)
            _, right_derivative = hamiltonian_action(h, nh, idx, source, np.zeros_like(source))
            gateway_overlaps = neutral @ vec[idx]
            np.testing.assert_allclose(vec.T @ right_derivative @ neutral,
                                       -4*gateway_overlaps[i]*gateway_overlaps, atol=1e-12)
            del right_derivative
            outputs, precision = free_flight(h, nh, idx, source, times)
            obs = []
            for t,(left,right) in zip(times,outputs):
                pr = float(np.vdot(right,right).real)
                pl = float(np.vdot(left,left).real)
                assert abs(pr+pl-1) < 2e-12
                start_energy = energies[i] + 4*float(np.sum(source_mode[idx]**2))
                # The scalar phase common to both sectors drops out of the probabilities and energy.
                ah, bh = hamiltonian_action(h,nh,idx,left,right)
                end_energy = float((np.vdot(left,ah)+np.vdot(right,bh)).real)
                assert abs(start_energy-end_energy) < 2e-10
                targets = []
                for j, dest in enumerate(vec.T):
                    matched = dest @ right
                    held = float(np.vdot(matched,matched).real)
                    whole = float(abs(neutral @ matched)**2)
                    targets.append({'destination_level':j,'right_whole_charged_mode_probability_left_unread':held,
                                    'whole_swapped_product_probability':whole,
                                    'right_mode_probability_given_charge_arrival':held/pr,
                                    'full_product_probability_given_charge_arrival':whole/pr})
                obs.append({'time':float(t),'charge_arrival_probability':pr,
                            'complete_norm':pl + pr,'energy_change_native':end_energy-start_energy,
                            'destination_targets':targets})
            entries.append({'input_level':i,'energy_native':float(energies[i]),'times':obs})
            del source, outputs, left, right, ah, bh
        sectors.append({'sign':sign,'native_gateway_ports':[g,b], 'joint_dimension':2*len(states)*len(idx),
                        'charged_dimension':len(states), 'neutral_dimension':len(idx),
                        'bridge_off_arrival':0,'series_precision':precision,'inputs':entries})
    return {'construction':'two completely active written cells joined by one active material contact',
            'charge_sectors':sectors}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    target=parser.parse_args().output
    result=run()
    with target.open('x') as f:
        json.dump(result,f,indent=2,allow_nan=False)
        f.write('\n')
