"""Free charged eigenstates with field energy confined near a charge and a second face."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.linalg import eigvalsh
from scipy.sparse import coo_matrix, csr_matrix, diags
from scipy.sparse.csgraph import connected_components

from search import PRIME, Patch, charged_sector, derivative_ranks, lowest
from model.executable_model import federation


def field_flips(patch, states):
    index = {state: i for i, state in enumerate(states)}
    records = []
    for i, (p, w) in enumerate(states):
        for face, other in patch.ring_moves(w):
            j = index[p, other]
            if i < j:
                records.append((i, j, face, int(p in patch.faces[face])))
    return np.array(records, dtype=np.int64).T


def observed_space(n, left, right, keep):
    adjacency = coo_matrix((np.ones(int(keep.sum())), (left[keep], right[keep])), shape=(n, n)).tocsr()
    dimension, labels = connected_components(adjacency, directed=False)
    # A positive edge has zero energy exactly when its two amplitudes agree.
    np.testing.assert_array_equal(labels[left[keep]], labels[right[keep]])
    rows = np.arange(n)
    basis = csr_matrix((np.ones(n, dtype=np.int64), (rows, labels)), shape=(n, dimension))
    pivot = np.unique(labels, return_index=True)[1]
    return labels, basis, pivot


def invariant_bound(h, labels, basis, pivot):
    image = (h @ basis).toarray()
    motion = image[pivot] % PRIME
    leakage = (image - motion[labels]) % PRIME
    return derivative_ranks(leakage, motion)


def energy_tails(groups, differences, away):
    data = []
    for g in groups:
        all_field = differences[:, g]
        tail_field = all_field[away]
        overall = 0.5 * all_field.T @ all_field
        tail = 0.5 * tail_field.T @ tail_field
        # Each of the sampled blocks has positive field energy above solver roundoff.
        assert np.linalg.eigvalsh(overall)[0] > 1e-10
        fraction = eigvalsh(tail, overall)
        assert min(fraction) > -1e-10 and max(fraction) < 1+1e-10
        data.append({'minimum_outside_ring_energy_fraction': float(fraction[0]),
                     'maximum_outside_ring_energy_fraction': float(fraction[-1]),
                     'minimum_total_ring_energy': float(np.linalg.eigvalsh(overall)[0])})
    return data


def run():
    patch = Patch()
    sectors = []
    for sign in (-1, 1):
        h, states, pos = charged_sector(patch, sign)
        levels, vec, groups, residual = lowest(h)
        left, right, faces, incident = field_flips(patch, states)
        assert np.all(pos[left] == pos[right])
        differences = vec[left] - vec[right]
        partners = []
        stationary_h = diags(16*(6 - federation(0).degree[pos]), dtype=np.int64)
        for partner in range(len(patch.faces)):
            away = (faces != partner) & (incident == 0)
            labels, basis, pivot = observed_space(len(states), left, right, away)
            result = invariant_bound(h, labels, basis, pivot)
            # A control with all material and field contacts off retains the same degree reference.
            image = (stationary_h @ basis).toarray()
            np.testing.assert_array_equal(image, image[pivot][labels])
            result.update({'partner_face': partner, 'number_of_forbidden_energy_edges': int(away.sum()),
                           'diagonal_control_invariant_dimension': basis.shape[1],
                           'low_eigenspace_ring_energy_tails': energy_tails(groups, differences, away)})
            partners.append(result)
        sectors.append({'sign': sign, 'states': len(states), 'low_energies': levels.tolist(),
                        'eigenspace_multiplicities': list(map(len, groups)),
                        'maximum_eigenpair_residual': residual, 'partners': partners})
    return {'prime': PRIME, 'seed': patch.seed, 'face_ports': patch.faces, 'charge_sectors': sectors}


if __name__ == '__main__':
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument('--output', type=Path, required=True)
    out = args.parse_args().output
    record = run()
    with out.open('x') as f:
        json.dump(record, f, indent=2, allow_nan=False)
        f.write('\n')
