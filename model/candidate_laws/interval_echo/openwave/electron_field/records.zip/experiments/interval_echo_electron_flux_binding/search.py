"""Invariant-subspace and low-energy tests of a mobile load dressed with a flux endpoint."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
from scipy.linalg import orth
from scipy.sparse import coo_matrix, diags
from scipy.sparse.csgraph import connected_components
from scipy.sparse.linalg import eigsh
from sympy import Matrix

WORK = Path(__file__).resolve().parents[2]
REPO = WORK / 'reverse-engineering-reality'
sys.path.insert(0, str(REPO))
from model.candidate_laws.interval_echo.openwave.electron_field.flux_string.search import Patch, phase
from model.executable_model import federation

PRIME = 65521
LEVELS = 24


def charged_sector(patch, sign):
    anchor = patch.faces[0][0]
    states = [(anchor, w) for w in patch.field_component()]
    index = {s: i for i, s in enumerate(states)}
    rows, cols, values = [], [], []
    for i, (port, word) in enumerate(states):
        destinations = [((port, w), 1) for _, w in patch.ring_moves(word)]
        destinations.extend((state, 8) for state in patch.charge_moves(port, word, sign))
        for state, weight in destinations:
            if state not in index:
                index[state] = len(states)
                states.append(state)
            rows.append(i)
            cols.append(index[state])
            values.append(weight)
    adj = coo_matrix((values, (rows, cols)), shape=(len(states), len(states)), dtype=np.int64).tocsr()
    assert (adj != adj.T).nnz == 0
    assert connected_components(adj, directed=False, return_labels=False) == 1
    p = np.array([p for p, _ in states])
    degree = federation(0).degree[:12]
    doubled = diags(np.asarray(adj.sum(axis=1)).ravel() + 16 * (6 - degree[p]), dtype=np.int64) - adj
    return doubled.tocsr(), states, p


def basis_blocks(patch, states, positions, partner):
    blocks = []
    for port in sorted(set(positions)):
        ids = np.flatnonzero(positions == port)
        words = [states[i][1] for i in ids]
        masks = [0] + [patch.path(f, partner) for f, face in enumerate(patch.faces)
                         if f != partner and port in face]
        templates = np.array([[phase(w, mask) for mask in masks] for w in words], dtype=np.int64)
        # The small matrix of distinct local sign patterns has exactly the same dependencies.
        unique, first = np.unique(templates, axis=0, return_index=True)
        basis_cols = list(Matrix(unique.tolist()).rref()[1])
        u = unique[:, basis_cols]
        row_indices = list(Matrix(u.T.tolist()).rref()[1])
        minor = Matrix(u[row_indices].tolist())
        determinant = int(minor.det())
        assert determinant % PRIME
        inv = np.array(minor.adjugate(), dtype=np.int64) * pow(determinant % PRIME, -1, PRIME) % PRIME
        selected = templates[:, basis_cols]
        np.testing.assert_array_equal((selected @ inv % PRIME) @ templates[first[row_indices]] % PRIME, templates % PRIME)
        excited = selected[:, 1:].astype(float)
        excited -= excited.mean(axis=0)
        q = orth(excited)
        assert q.shape[1] == len(basis_cols) - 1
        blocks.append((ids, selected, first[row_indices], inv, q))
    return blocks


def basis_rows(matrix):
    """Return an independent row basis over the prime field via vectorized elimination."""
    work = np.asarray(matrix, dtype=np.int64).copy() % PRIME
    k = 0
    for col in range(work.shape[1]):
        keep = np.flatnonzero(work[k:, col])
        if not len(keep):
            continue
        other = k + keep[0]
        work[[k, other]] = work[[other, k]]
        work[k] = work[k] * pow(int(work[k, col]), -1, PRIME) % PRIME
        active = np.flatnonzero(work[k+1:, col]) + k + 1
        if len(active):
            work[active] = (work[active] - work[active, col, None] * work[k]) % PRIME
        k += 1
        if k == work.shape[0]:
            break
    return work[:k]


def invariant_check(h, blocks):
    dim = sum(b.shape[1] for _, b, _, _, _ in blocks)
    basis = np.zeros((h.shape[0], dim), dtype=np.int64)
    offset = 0
    for idx, b, pivot, inv, q in blocks:
        basis[idx, offset:offset + b.shape[1]] = b
        offset += b.shape[1]
    advanced = h @ basis
    representation = np.vstack([inv @ advanced[idx[piv]] % PRIME for idx, b, piv, inv, q in blocks])
    defect = (advanced - basis @ representation) % PRIME
    return derivative_ranks(defect, representation)


def derivative_ranks(defect, representation):
    dim = representation.shape[0]
    # Work in short batches. Every accumulated row is a linear consequence of the observed leakage.
    selected = basis_rows(np.zeros((0, dim), dtype=np.int64))
    rng = np.random.default_rng(9147)
    for batch in np.array_split(rng.permutation(len(defect)), max(1, len(defect) // 150)):
        selected = basis_rows(np.vstack([selected, defect[batch]]))
        if len(selected) == dim:
            break
    ranks = [len(selected)]
    while len(selected) < dim:
        selected = basis_rows(np.vstack([selected, selected @ representation % PRIME]))
        ranks.append(len(selected))
        if ranks[-1] == ranks[-2]:
            break
    return {'span_dimension': dim, 'leakage_derivative_ranks_mod_prime': ranks,
            'invariant_dimension_upper_bound': dim - ranks[-1]}


def lowest(h):
    # Request extra levels so the twenty-fourth level cannot truncate a degeneracy unnoticed.
    levels, vectors = eigsh(h.astype(float)/2., k=LEVELS + 4, which='SA', tol=1e-12,
                            v0=np.random.default_rng(46391).normal(size=h.shape[0]))
    order = np.argsort(levels)
    levels, vectors = levels[order], vectors[:, order]
    keep = levels <= levels[LEVELS-1] + 1e-8
    assert not keep[-1]
    levels, vectors = levels[keep], vectors[:, keep]
    residual = np.max(np.linalg.norm(h @ vectors/2. - vectors * levels, axis=0))
    assert residual < 1e-9
    groups = np.split(np.arange(len(levels)), np.flatnonzero(np.diff(levels) > 1e-8) + 1)
    return levels, vectors, groups, float(residual)


def run():
    patch = Patch()
    report = {'prime': PRIME, 'seed': patch.seed, 'faces': patch.faces, 'charge_sectors': []}
    for sign in (-1, 1):
        h, states, positions = charged_sector(patch, sign)
        levels, vectors, groups, residual = lowest(h)
        sector = {'sign': sign, 'states': len(states), 'ports': np.unique(positions).tolist(),
                  'low_energies': levels.tolist(), 'low_energy_blocks': [len(g) for g in groups],
                  'max_eigenpair_residual': residual, 'partners': []}
        for partner in range(len(patch.faces)):
            blocks = basis_blocks(patch, states, positions, partner)
            result = invariant_check(h, blocks)
            projections = np.vstack([q.T @ vectors[idx] for idx, b, piv, inv, q in blocks])
            overlaps = [float(np.linalg.norm(projections[:, g], ord=2)**2) for g in groups]
            result.update({'remote_face': partner, 'dressed_low_eigenspace_max_probabilities': overlaps})
            sector['partners'].append(result)
        report['charge_sectors'].append(sector)
    return report


if __name__ == '__main__':
    arg = argparse.ArgumentParser(description=__doc__)
    arg.add_argument('--output', type=Path, required=True)
    path = arg.parse_args().output
    result = run()
    with path.open('x') as f:
        json.dump(result, f, indent=2, allow_nan=False)
        f.write('\n')
