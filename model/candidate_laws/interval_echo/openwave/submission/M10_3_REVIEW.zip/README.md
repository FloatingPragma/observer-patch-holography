# M10.3 free-pair author review

The proposed filing text is [M10_3_PR.md](M10_3_PR.md). The [completed checklist](CHECKLIST.md) and [independent review](ROW_04_PLATFORM_AUDIT.md) record the unsigned package's disposition. The exact source bundle, platform bundle and patch are included. The owning RER source hosts author data under the terms in LICENSE.

With Python 3.12, NumPy 2.3.5 and SciPy 1.18.1 run the following from this directory.

```sh
python -B row_04_check.py --board FEDERATION_LEVEL0.npz
python -B row_04_window.py --board FEDERATION_LEVEL0.npz
python -B row_04_formation.py --board FEDERATION_LEVEL0.npz
```

SHA256SUMS covers every other file.
