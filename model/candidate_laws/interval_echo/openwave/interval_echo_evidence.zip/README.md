# Interval Echo evidence archive

The [research note and proposed table entries](model/candidate_laws/interval_echo/openwave/README.md) give the experiments, results, limits and reproduction commands.

From this directory, install the pinned dependencies and replay with Python 3.12.

```sh
python -m pip install -r model/requirements.txt
python -B -m model.candidate_laws.interval_echo.openwave.replay
```

SHA256SUMS lists every other source and evidence file. Licensing is described in LICENSE.
